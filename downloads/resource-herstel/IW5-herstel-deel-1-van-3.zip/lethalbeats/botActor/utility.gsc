/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : utility          |
|Creator : LastDemon99	   |
|Type : Utility            |
============================
*/

#include lethalbeats\botActor\navigation;
#include lethalbeats\botactor\targeting;
#include lethalbeats\botactor\movement;
#include lethalbeats\botactor\behavior;

#define LOCK 0
#define SPRINT_STATE 1
#define HOLD_SPRINT 2
#define SCRIPT_MOVE 3
#define PATH_LOCK 4
#define TARGET_MONITOR 5
#define HEARTBEAT_TARGET 6
#define HEARTBEAT_NAV 7
#define HEARTBEAT_MOVE 8

// --- NAVIGATION STATE (20-39) ---
#define PATROL_ACTIVE 20            // bool
#define PATROL_LOOP 21              // bool
#define CHASE_TARGET 22             // entity
#define CHASE_NEXT_MOVE_TIME 23     // int
#define CHASE_LAST_GOAL 24          // vector
#define CHASE_NEXT_HANDOVER 25      // int
#define CACHED_PATH_DIST_SQ 26      // float
#define NEXT_PATH_DIST_UPDATE 27    // int
#define AVOID_ZONES 28              // array
#define AVOID_WP 29                 // array
#define LAST_WALL_FLANK_WP 30       // int
#define LAST_WAYPOINT_BYPASS_WP 31  // int
#define NEGATIVE_MODE 32            // bool
#define MELEE_CHARGE 33             // bool: true=melee, false=shoot
#define CHASE_HANDOVER_ACTIVE 34    // bool

// --- TARGETING & SCALING (40-59) ---
#define ENABLED_TARGETS 40          // array
#define AIM_POS 41                  // vector
#define AIM_OFFSET_VEC 42           // vector
#define AIM_OFFSET_START 43         // int
#define AIM_OFFSET_END 44           // int
#define MOVE_LOOK_DIR 45            // vector
#define MOVE_LOOK_MODE 46           // int: 0=move, 1=aim
#define VALID_TARGETS 47            // callback
#define BEST_TARGET 48              // callback
#define BEST_TARGET_UPDATE_INTERVAL 49 // float
#define BEST_TARGET_LAST_UPDATE 50  // int
#define BEST_TARGET_CURRENT 51      // entity
#define TARGET_FILTER 52            // callback

// --- SKILL & CONFIG (60-99) ---
#define SKILL_AIM_TIME 60
#define SKILL_INIT_REACT_TIME 61
#define SKILL_REACTION_TIME 62
#define SKILL_NO_TRACE_ADS_TIME 63
#define SKILL_NO_TRACE_LOOK_TIME 64
#define SKILL_REMEMBER_TIME 65
#define SKILL_LOCATION_REMEMBER_TIME 66
#define SKILL_FOV 67
#define SKILL_DIST_MAX 68
#define SKILL_SHOOT_AFTER_TIME 69
#define SKILL_AIM_OFFSET_TIME 70
#define SKILL_AIM_OFFSET_AMOUNT 71
#define SKILL_BONE_UPDATE_INTERVAL 72
#define SKILL_BONES 73
#define SKILL_ADS_FOV_MULTI 74
#define SKILL_ADS_AIMSPEED_MULTI 75
#define SKILL_CHASE_DIST_MIN 76
#define SKILL_CHASE_DIST_MAX 77
#define SKILL_MELEE_DIST 78
#define SKILL_SEMI_TIME 79

// --- COMBAT BEHAVIOR (100-119) ---
#define BEHAVIOR_STRAFE 100
#define BEHAVIOR_NADE 101
#define BEHAVIOR_SPRINT 102
#define BEHAVIOR_CROUCH 103
#define BEHAVIOR_JUMP 104
#define BEHAVIOR_QUICKSCOPE 105
#define BEHAVIOR_DROPSHOT 118
#define BEHAVIOR_COVER_SNAP 106
#define BEHAVIOR_COVER_MIN_TIME 107
#define BEHAVIOR_COVER_MAX_TIME 108
#define COVER_HOLDING_END_TIME 109
#define COVER_CURRENT_NODE 117
#define FIRE_TIME 110
#define MIN_SHOTS 111
#define MAX_SHOTS 112
#define MIN_PAUSE 113
#define MAX_PAUSE 114
#define WIND_UP_TIME 115
#define LAST_FIRE_TIME 116

// --- SQUAD-RELATED (120-139) ---
#define SQUAD_REFERENCE 120
#define SQUAD_MOVE_GOAL 121
#define SQUAD_NEXT_MOVE_TIME 122
#define SQUAD_IS_STOPPED 123
#define SQUAD_CHASE_TARGET 124
#define SQUAD_CHASE_MIN_SQ 125
#define SQUAD_CHASE_MAX_SQ 126
#define SQUAD_CHASE_NEXT_ISSUE 127
#define SQUAD_CHASE_NEXT_HANDOVER 128
#define DISABLED_NODES 129
#define QUADRUPED_MODE 130          // bool: true=forward-only locomotion (dogs)
#define GRENADE_FLEE_OFF 131        // bool: per-bot opt-out of the grenade reaction
#define GRENADE_NEXT_REACT 132      // int: cooldown stamp
#define REACTING_UNTIL 133          // int: reaction expiry stamp
#define ROUTE_SPRINT 135            // bool: routes started from now on sprint
#define CLAYMORE_NEXT 136           // int: next allowed plant
#define CLAYMORE_USED 137           // int: plants this life

#define CLAYMORE_WEAPON "claymore_mp"
#define CLAYMORE_PLANT_MS 2200

#define GRENADE_FLEE_MAX_MS 4000

// --- SURVIVAL METADATA (160-179) ---
#define SURVIVOR_DAMAGE_SCALE 160
#define BOT_HEALTH_MULTIPLIER 161
#define BOT_SPEED_MULTIPLIER 162
#define BOT_RESPAWN_DELAY_MIN 163
#define BOT_RESPAWN_DELAY_MAX 164
#define SKILL_DIST_START 170
#define SKILL_HELP_DIST 171

/*
///DocStringBegin
detail: bot_init(): <Void>
summary: Boots actor runtime, adapter builtins, safety patches, and minimal spawn/runtime state.
///DocStringEnd
*/
bot_init()
{
	if (isDefined(level.bot_init) && level.bot_init)
		return;

	level.bot_init = 1;
	level.rankedmatch = 0;
	setDynamicDvar("disable_challenges", 1);

	lethalbeats\botactor\stuckzones::stuckzone_init();
	replacefunc(maps\mp\gametypes\_playerlogic::waitAndSpawnClient, ::_waitAndSpawnClient);
}

_waitAndSpawnClient()
{
    self endon("disconnect");
    self endon("end_respawn");
    level endon("game_ended");
    self notify("attempted_spawn");
    spawnedAsSpectator = 0;

	if (isDefined(self.pers["spawn_time"]))
	{
		self notify("bot_wait_respawn");
		if (self.pers["spawn_time"]) wait self.pers["spawn_time"];
		else self waittill("bot_spawn");
		self notify("bot_respawn");
	}

    if (isdefined(self.pers["teamKillPunish"]) && self.pers["teamKillPunish"])
    {
        teamKillDelay = maps\mp\gametypes\_playerlogic::teamKillDelay();

        if (teamKillDelay > 0)
        {
            maps\mp\_utility::setlowermessage("friendly_fire", &"MP_FRIENDLY_FIRE_WILL_NOT", teamKillDelay, 1, 1);
            thread maps\mp\gametypes\_playerlogic::respawn_asSpectator(self.origin + (0, 0, 60), self.angles);
            spawnedAsSpectator = 1;
            wait(teamKillDelay);
            maps\mp\_utility::clearlowermessage("friendly_fire");
            self.respawntimerstarttime = gettime();
        }

        self.pers["teamKillPunish"] = 0;
    }
    else if (maps\mp\gametypes\_playerlogic::teamKillDelay())
        self.pers["teamkills"] = max(self.pers["teamkills"] - 1, 0);

    if (maps\mp\_utility::isUsingRemote())
    {
        self.spawningafterremotedeath = 1;
        self waittill("stopped_using_remote");
    }

    if (!isdefined(self.wavespawnindex) && isdefined(level.waveplayerspawnindex[self.team]))
    {
        self.wavespawnindex = level.waveplayerspawnindex[self.team];
        level.waveplayerspawnindex[self.team]++;
    }

    timeUntilSpawn = maps\mp\gametypes\_playerlogic::timeUntilSpawn(0);
    thread maps\mp\gametypes\_playerlogic::predictAboutToSpawnPlayerOverTime(timeUntilSpawn);

    if (timeUntilSpawn > 0)
    {
        maps\mp\_utility::setlowermessage("spawn_info", game["strings"]["waiting_to_spawn"], timeUntilSpawn, 1, 1);

        if (!spawnedAsSpectator)
            thread maps\mp\gametypes\_playerlogic::respawn_asSpectator(self.origin + (0, 0, 60), self.angles);

        spawnedAsSpectator = 1;
        maps\mp\_utility::waitForTimeOrNotify(timeUntilSpawn, "force_spawn");
        self notify("stop_wait_safe_spawn_button");
    }

    waveBased = getdvarint("scr_" + level.gametype + "_waverespawndelay") > 0;

    if (maps\mp\gametypes\_tweakables::getTweakableValue("player", "forcerespawn") == 0 && self.hasspawned && !waveBased && !self.wantsafespawn)
    {
        maps\mp\_utility::setlowermessage("spawn_info", game["strings"]["press_to_spawn"], undefined, undefined, undefined, undefined, undefined, undefined, 1);

        if (!spawnedAsSpectator)
            thread maps\mp\gametypes\_playerlogic::respawn_asSpectator(self.origin + (0, 0, 60), self.angles);

        spawnedAsSpectator = 1;
        maps\mp\gametypes\_playerlogic::waitRespawnButton();
    }

    self.waitingtospawn = 0;
    maps\mp\_utility::clearlowermessage("spawn_info");
    self.wavespawnindex = undefined;
    thread maps\mp\gametypes\_playerlogic::spawnPlayer();
}

/*
///DocStringBegin
detail: bot_add(team: <String>): <Entity>
summary: Adds a testclient bot, initializes actor state, applies team, and returns the bot entity without spawning.
///DocStringEnd
*/
bot_add(team)
{
	bot = addTestClient();
	bot.pers["score"] = 0;

	waittillframeend;
	if (!isDefined(bot)) return undefined;

	bot setplayerdata("experience", 0);
	bot setplayerdata("prestige", 0);
	bot setplayerdata("cardTitle", 0);
	bot setplayerdata("cardIcon", 0);

	bot.pers["gamemodeLoadout"] = lethalbeats\utility::get_loadout_blank();
	bot.pers["class"] = "gamemode";
	bot.pers["lastClass"] = "";
	bot.class = bot.pers["class"];
	bot.lastClass = bot.pers["lastClass"];

	bot.pers["team"] = isDefined(team) ? team : "spectator";
	bot maps\mp\gametypes\_menus::addToTeam(bot.pers["team"], 1);

	// Spawn time and point are engine-related vars, kept in pers.
	bot.pers["spawn_time"] = 0;
	bot.pers["spawn_point"] = undefined;

	// Initialize the optimized actor state array with safe defaults
	bot.actor = [];

	// Core Behaviors --- CORE STATE ---
	bot.actor[LOCK] = true;
	bot.actor[SPRINT_STATE] = false;
	bot.actor[HOLD_SPRINT] = false;
	bot.actor[SCRIPT_MOVE] = false;
	bot.actor[PATH_LOCK] = false;

	// --- NAVIGATION STATE ---
	bot.actor[PATROL_ACTIVE] = false;
	bot.actor[PATROL_LOOP] = true;
	bot.actor[CHASE_TARGET] = undefined;
	bot.actor[CHASE_NEXT_MOVE_TIME] = 0;
	bot.actor[CHASE_LAST_GOAL] = undefined;
	bot.actor[CHASE_NEXT_HANDOVER] = 0;
	bot.actor[CACHED_PATH_DIST_SQ] = undefined;
	bot.actor[NEXT_PATH_DIST_UPDATE] = 0;
	bot.actor[AVOID_ZONES] = [];
	bot.actor[AVOID_WP] = [];
	bot.botactor_bad_edges = [];
	bot.actor[LAST_WALL_FLANK_WP] = undefined;
	bot.actor[LAST_WAYPOINT_BYPASS_WP] = undefined;
	bot.actor[NEGATIVE_MODE] = false;
	bot.actor[MELEE_CHARGE] = true;

	// --- TARGETING & AIMING ---
	bot.actor[ENABLED_TARGETS] = [];
	bot.actor[AIM_POS] = undefined;
	bot.actor[AIM_OFFSET_VEC] = undefined;
	bot.actor[AIM_OFFSET_START] = 0;
	bot.actor[AIM_OFFSET_END] = 0;
	bot.actor[MOVE_LOOK_DIR] = undefined;
	bot.actor[MOVE_LOOK_MODE] = 1; // 1 = look at target while moving
	bot.actor[VALID_TARGETS] = ::bot_default_valid_targets;
	bot.actor[BEST_TARGET] = ::bot_default_best_target;
	bot.actor[BEST_TARGET_UPDATE_INTERVAL] = 0;
	bot.actor[BEST_TARGET_LAST_UPDATE] = 0;
	bot.actor[BEST_TARGET_CURRENT] = undefined;

	// --- SKILLS ---
	bot.actor[SKILL_AIM_TIME] = 0.05;
	bot.actor[SKILL_INIT_REACT_TIME] = 0;
	bot.actor[SKILL_REACTION_TIME] = 0;
	bot.actor[SKILL_NO_TRACE_ADS_TIME] = 2.5;
	bot.actor[SKILL_NO_TRACE_LOOK_TIME] = 10;
	bot.actor[SKILL_REMEMBER_TIME] = undefined;
	bot.actor[SKILL_LOCATION_REMEMBER_TIME] = undefined;
	bot.actor[SKILL_FOV] = -1;
	bot.actor[SKILL_DIST_MAX] = 200000;
	bot.actor[SKILL_SHOOT_AFTER_TIME] = 1;
	bot.actor[SKILL_AIM_OFFSET_TIME] = 1;
	bot.actor[SKILL_AIM_OFFSET_AMOUNT] = 1;
	bot.actor[SKILL_BONE_UPDATE_INTERVAL] = 1;
	bot.actor[SKILL_BONES] = "j_head,j_spineupper,j_ankle_le,j_ankle_ri";
	bot.actor[SKILL_ADS_FOV_MULTI] = 0.5;
	bot.actor[SKILL_ADS_AIMSPEED_MULTI] = 0.5;
	bot.actor[SKILL_CHASE_DIST_MIN] = 192;
	bot.actor[SKILL_CHASE_DIST_MAX] = 700;
	bot.actor[SKILL_MELEE_DIST] = 120;
	bot.actor[SKILL_SEMI_TIME] = 0.05;

	// --- COMBAT ---
	bot.actor[BEHAVIOR_STRAFE] = 0;
	bot.actor[BEHAVIOR_NADE] = 0;
	bot.actor[BEHAVIOR_SPRINT] = 0;
	bot.actor[BEHAVIOR_CROUCH] = 0;
	bot.actor[BEHAVIOR_JUMP] = 0;
	bot.actor[BEHAVIOR_QUICKSCOPE] = 0;
	bot.actor[BEHAVIOR_DROPSHOT] = 0;
	bot.actor[BEHAVIOR_COVER_SNAP] = 50;
	bot.actor[BEHAVIOR_COVER_MIN_TIME] = 2.0;
	bot.actor[BEHAVIOR_COVER_MAX_TIME] = 6.0;
	bot.actor[COVER_HOLDING_END_TIME] = 0;
	bot.actor[COVER_CURRENT_NODE] = undefined;
	bot.actor[FIRE_TIME] = 0.05;
	bot.actor[MIN_SHOTS] = 1;
	bot.actor[MAX_SHOTS] = 1;
	bot.actor[MIN_PAUSE] = 0.05;
	bot.actor[MAX_PAUSE] = 0.15;
	bot.actor[WIND_UP_TIME] = 0.0;
	bot.actor[LAST_FIRE_TIME] = -1;

	// --- SQUAD ---
	bot.actor[SQUAD_REFERENCE] = undefined;
	bot.actor[SQUAD_MOVE_GOAL] = undefined;
	bot.actor[SQUAD_NEXT_MOVE_TIME] = 0;
	bot.actor[SQUAD_IS_STOPPED] = false;
	bot.actor[SQUAD_CHASE_TARGET] = undefined;
	bot.actor[SQUAD_CHASE_MIN_SQ] = 0;
	bot.actor[SQUAD_CHASE_MAX_SQ] = 0;
	bot.actor[SQUAD_CHASE_NEXT_ISSUE] = 0;

	bot.perks = [];
	bot.challengedata = [];

	return bot;
}

/*
///DocStringBegin
detail: <Player> bot_kick(): <Void>
summary: Frees this testclient slot through the engine kick call.
///DocStringEnd
*/
bot_kick()
{
	if (!isDefined(self)) return;
	if (!isPlayer(self)) return;
	if (!self isTestClient()) return;

	kick(self getEntityNumber());
}

/*
///DocStringBegin
detail: <Player> bot_find_cover(radius: <Float>, centerPos?: <Vector3>, targetPos?: <Vector3>, checkSight?: <Bool>): <Struct | Undefined>
summary: Finds a free cover waypoint through botActor navigation, preferring covers facing targetPos when supplied.
///DocStringEnd
*/
bot_find_cover(radius, centerPos, targetPos, checkSight)
{
	if (!isDefined(radius)) radius = 1000;
	if (!isDefined(centerPos)) centerPos = self.origin;

	return self lethalbeats\botactor\navigation::_findFreeCover(radius, centerPos, targetPos, checkSight);
}

bot_spawn(origin, angles, weapon)
{
	if (isDefined(origin))
	{
		spawnpoint = spawn("script_origin", origin);
		spawnpoint hide();
		if (isDefined(angles)) spawnpoint.angles = angles;
		spawnpoint.notti = 0;
		spawnpoint.playerspawnpos = origin;
		self.setspawnpoint = spawnpoint;
	}

	if (isDefined(weapon)) weapon = lethalbeats\weapon::weapon_get_baseName(weapon);

	if (!isDefined(self.pers["class"]) || self.pers["class"] != "gamemode" || !isDefined(self.pers["gamemodeLoadout"]))
	{
		self.pers["gamemodeLoadout"] = lethalbeats\utility::get_loadout_blank(weapon);
		self.pers["class"] = "gamemode";
		self.pers["lastClass"] = "";
		self.class = self.pers["class"];
		self.lastClass = self.pers["lastClass"];
	}
	else
	{
		if (!isDefined(self.pers["gamemodeLoadout"]["loadoutJuggernaut"]))
			self.pers["gamemodeLoadout"]["loadoutJuggernaut"] = false;

		if (isDefined(weapon))
			self.pers["gamemodeLoadout"]["loadoutPrimary"] = weapon;
	}

	self thread maps\mp\gametypes\_playerlogic::spawnClient();
	self notify("bot_spawn");

	self waittill("spawned_player");

	if (!isDefined(self.actor)) self.actor = [];

	// --- CORE STATE ---
	self.actor[LOCK] = true;
	self.actor[SPRINT_STATE] = false;
	self.actor[HOLD_SPRINT] = false;
	self.actor[SCRIPT_MOVE] = false;
	self.actor[PATH_LOCK] = false;

	// --- NAVIGATION STATE ---
	self.actor[PATROL_ACTIVE] = false;
	self.actor[PATROL_LOOP] = true;
	self.actor[CHASE_TARGET] = undefined;
	self.actor[CHASE_NEXT_MOVE_TIME] = 0;
	self.actor[CHASE_LAST_GOAL] = undefined;
	self.actor[CHASE_NEXT_HANDOVER] = 0;
	self.actor[CACHED_PATH_DIST_SQ] = undefined;
	self.actor[NEXT_PATH_DIST_UPDATE] = 0;
	self.actor[AVOID_ZONES] = [];
	self.actor[AVOID_WP] = [];
	self.botactor_bad_edges = [];
	self.actor[LAST_WALL_FLANK_WP] = undefined;
	self.actor[LAST_WAYPOINT_BYPASS_WP] = undefined;
	self.actor[NEGATIVE_MODE] = false;
	self.actor[MELEE_CHARGE] = false;

	// --- TARGETING & AIMING ---
	if (!isDefined(self.actor[ENABLED_TARGETS])) self.actor[ENABLED_TARGETS] = [];
	self.actor[AIM_POS] = undefined;
	self.actor[AIM_OFFSET_VEC] = undefined;
	self.actor[AIM_OFFSET_START] = 0;
	self.actor[AIM_OFFSET_END] = 0;
	self.actor[MOVE_LOOK_DIR] = undefined;
	self.actor[MOVE_LOOK_MODE] = 1;
	if (!isDefined(self.actor[VALID_TARGETS])) self.actor[VALID_TARGETS] = ::bot_default_valid_targets;
	if (!isDefined(self.actor[BEST_TARGET])) self.actor[BEST_TARGET] = ::bot_default_best_target;
	if (!isDefined(self.actor[BEST_TARGET_UPDATE_INTERVAL])) self.actor[BEST_TARGET_UPDATE_INTERVAL] = 0;
	if (!isDefined(self.actor[BEST_TARGET_LAST_UPDATE])) self.actor[BEST_TARGET_LAST_UPDATE] = 0;
	if (!isDefined(self.actor[BEST_TARGET_CURRENT])) self.actor[BEST_TARGET_CURRENT] = undefined;
	if (!isDefined(self.actor[SKILL_FOV])) self.actor[SKILL_FOV] = -1;

	// --- COMBAT BEHAVIOR ---
	if (!isDefined(self.actor[BEHAVIOR_STRAFE])) self.actor[BEHAVIOR_STRAFE] = 0;
	if (!isDefined(self.actor[BEHAVIOR_NADE])) self.actor[BEHAVIOR_NADE] = 0;
	if (!isDefined(self.actor[BEHAVIOR_SPRINT])) self.actor[BEHAVIOR_SPRINT] = 0;
	if (!isDefined(self.actor[BEHAVIOR_CROUCH])) self.actor[BEHAVIOR_CROUCH] = 0;
	if (!isDefined(self.actor[BEHAVIOR_JUMP])) self.actor[BEHAVIOR_JUMP] = 0;
	if (!isDefined(self.actor[BEHAVIOR_QUICKSCOPE])) self.actor[BEHAVIOR_QUICKSCOPE] = 0;
	if (!isDefined(self.actor[BEHAVIOR_COVER_SNAP])) self.actor[BEHAVIOR_COVER_SNAP] = 20;
	if (!isDefined(self.actor[BEHAVIOR_COVER_MIN_TIME])) self.actor[BEHAVIOR_COVER_MIN_TIME] = 2.0;
	if (!isDefined(self.actor[BEHAVIOR_COVER_MAX_TIME])) self.actor[BEHAVIOR_COVER_MAX_TIME] = 6.0;
	self.actor[COVER_HOLDING_END_TIME] = 0;
	self.actor[COVER_CURRENT_NODE] = undefined;

	if (!isDefined(self.actor[FIRE_TIME])) self.actor[FIRE_TIME] = 0.05;
	if (!isDefined(self.actor[MIN_SHOTS])) self.actor[MIN_SHOTS] = 1;
	if (!isDefined(self.actor[MAX_SHOTS])) self.actor[MAX_SHOTS] = 1;
	if (!isDefined(self.actor[MIN_PAUSE])) self.actor[MIN_PAUSE] = 0.05;
	if (!isDefined(self.actor[MAX_PAUSE])) self.actor[MAX_PAUSE] = 0.15;
	if (!isDefined(self.actor[WIND_UP_TIME])) self.actor[WIND_UP_TIME] = 0.0;
	self.actor[LAST_FIRE_TIME] = -1;

	// --- SQUAD ---
	self.actor[SQUAD_REFERENCE] = undefined;
	self.actor[SQUAD_MOVE_GOAL] = undefined;
	self.actor[SQUAD_NEXT_MOVE_TIME] = 0;
	self.actor[SQUAD_IS_STOPPED] = false;
	self.actor[SQUAD_CHASE_TARGET] = undefined;
	self.actor[SQUAD_CHASE_MIN_SQ] = 0;
	self.actor[SQUAD_CHASE_MAX_SQ] = 0;
	self.actor[SQUAD_CHASE_NEXT_ISSUE] = 0;

	if (!isDefined(self.actor[MELEE_CHARGE])) self.actor[MELEE_CHARGE] = false;
	if (!isDefined(self.actor[SKILL_LOCATION_REMEMBER_TIME])) self.actor[SKILL_LOCATION_REMEMBER_TIME] = 5.0;
	if (!isDefined(self.actor[SKILL_CHASE_DIST_MIN])) self.actor[SKILL_CHASE_DIST_MIN] = 192;
	if (!isDefined(self.actor[SKILL_CHASE_DIST_MAX])) self.actor[SKILL_CHASE_DIST_MAX] = 700;

	self lethalbeats\botactor\movement::bot_drive_init();
	self lethalbeats\botactor\behavior::bot_behavior_init();

	self.actor[GRENADE_NEXT_REACT] = 0;
	if (!isDefined(self.actor[GRENADE_FLEE_OFF])) self.actor[GRENADE_FLEE_OFF] = false;

	// After bot_behavior_init, because it puts the engagement back and self.ba has to exist for that.
	self _botGrenadeSpawnReset();

	self bot_stop_all();
	self thread lethalbeats\botactor\targeting::_botTargetLoop();
	self thread lethalbeats\botactor\movement::_botMovementLoop();
	self thread _botSprintMonitor();
	self thread _botGrenadeWatch();
	self thread _botClaymoreWatch();
}

_botClaymoreWatch()
{
	self endon("disconnect");
	self endon("death");
	level endon("game_ended");

	for (;;)
	{
		wait (lethalbeats\botactor\config::bot_config_get("claymore_tick_ms") / 1000);

		if (!isAlive(self)) continue;
		if (!lethalbeats\botactor\config::bot_config_get("claymore_enabled")) continue;

		if (self bot_is_reacting()) continue;

		if (!isDefined(self.actor[CLAYMORE_USED])) self.actor[CLAYMORE_USED] = 0;
		if (self.actor[CLAYMORE_USED] >= lethalbeats\botactor\config::bot_config_get("claymore_max_per_life")) continue;

		if (isDefined(self.actor[CLAYMORE_NEXT]) && gettime() < self.actor[CLAYMORE_NEXT]) continue;

		if (self getAmmoCount(CLAYMORE_WEAPON) <= 0) continue;

		node = self _botClaymoreNode();
		if (!isDefined(node)) continue;

		self.actor[CLAYMORE_NEXT] = gettime() + lethalbeats\botactor\config::bot_config_get("claymore_cooldown_ms");
		self.actor[REACTING_UNTIL] = gettime() + CLAYMORE_PLANT_MS;

		plant = lethalbeats\botactor\behavior::bot_task_custom(::_botClaymorePlantTask, node);
		self lethalbeats\botactor\behavior::bot_do_now(plant);
	}
}

/*
///DocStringBegin
detail: bot_claymore_nodes(): <Struct[]>
summary: Every waypoint of type "claymore", cached until the graph changes. Public because the IMS placement wants the same nodes with a different radius, and scanning the whole graph twice for the same answer is waste.
///DocStringEnd
*/
bot_claymore_nodes()
{
	lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return [];

	if (!isDefined(level.botactor_claymore_wps) || !isDefined(level.botactor_claymore_count) || level.botactor_claymore_count != level.waypoints.size)
	{
		list = [];
		for (i = 0; i < level.waypoints.size; i++)
		{
			wp = level.waypoints[i];
			if (!isDefined(wp) || !isDefined(wp.type) || !isDefined(wp.origin))
				continue;

			if (wp.type != "claymore")
				continue;

			list[list.size] = wp;
		}

		level.botactor_claymore_wps = list;
		level.botactor_claymore_count = level.waypoints.size;
	}

	return level.botactor_claymore_wps;
}

/*
///DocStringBegin
detail: <Player> bot_claymore_nearest_node(maxDist: <Float>): <Struct | Undefined>
summary: Nearest "claymore" node within maxDist, or undefined.
///DocStringEnd
*/
bot_claymore_nearest_node(maxDist)
{
	nodes = bot_claymore_nodes();
	if (!nodes.size)
		return undefined;

	best = undefined;
	bestSq = maxDist * maxDist;

	for (i = 0; i < nodes.size; i++)
	{
		wp = nodes[i];
		if (!isDefined(wp)) continue;

		distSq = distanceSquared(self.origin, wp.origin);
		if (distSq > bestSq) continue;

		best = wp;
		bestSq = distSq;
	}

	return best;
}

_botClaymoreNode()
{
	return self bot_claymore_nearest_node(lethalbeats\botactor\config::bot_config_get("claymore_node_dist"));
}

_botClaymorePlantTask(node)
{
	self.actor[REACTING_UNTIL] = gettime() + CLAYMORE_PLANT_MS;

	self.bot.moveto = undefined;
	self.bot.stop_move = true;

	if (isDefined(node) && isDefined(node.angles))
		self lethalbeats\botactor\movement::bot_look_at_angles((0, node.angles[1], 0), CLAYMORE_PLANT_MS);

	previous = self getCurrentWeapon();

	self switchToWeapon(CLAYMORE_WEAPON);
	wait 0.7;

	if (isAlive(self))
	{
		self bot_press_fire(0.15);
		wait 0.6;
		self.actor[CLAYMORE_USED] = self.actor[CLAYMORE_USED] + 1;
	}

	if (isAlive(self) && isDefined(previous) && previous != "none")
		self switchToWeapon(previous);

	self.bot.stop_move = false;
	self.actor[REACTING_UNTIL] = 0;
	return true;
}

// Reaction state does NOT survive death
_botGrenadeSpawnReset()
{
	self.actor[REACTING_UNTIL] = 0;
	self.actor[GRENADE_NEXT_REACT] = 0;
	self.actor[CLAYMORE_NEXT] = 0;
	self.actor[CLAYMORE_USED] = 0;
	self.botactor_last_threat = undefined;
	self.botactor_route_tag = undefined;

	self bot_set_route_sprint(false);
	self _botGrenadeRestoreEngagement();
}

/*
///DocStringBegin
detail: <Player> bot_set_grenade_flee(enabled: <Bool>): <Void>
summary: Per-bot switch for the grenade reaction, on top of the global "grenade_flee" option. Use it to exempt bots that should never break formation - juggernauts, riotshield squads, scripted set pieces.
///DocStringEnd
*/
bot_set_grenade_flee(enabled)
{
	if (!isDefined(self.actor)) return;
	if (!isDefined(enabled)) enabled = true;

	self.actor[GRENADE_FLEE_OFF] = !enabled;
}

/*
///DocStringBegin
detail: <Player> bot_set_route_sprint(enabled: <Bool>): <Void>
summary: Makes routes started from now on run instead of walk. bot_go_to reads it when it sets up the route, so it must be set BEFORE the call - setting HOLD_SPRINT directly does not survive, bot_go_to resets it.
///DocStringEnd
*/
bot_set_route_sprint(enabled)
{
	if (!isDefined(self.actor)) return;
	if (!isDefined(enabled)) enabled = true;

	self.actor[ROUTE_SPRINT] = enabled;
}

/*
///DocStringBegin
detail: <Player> bot_is_stunned(): <Bool>
summary: Returns true if the bot is currently affected by a flashbang, concussion grenade, or heavy damage stun.
///DocStringEnd
*/
bot_is_stunned()
{
	if (!lethalbeats\botactor\config::bot_config_get("stun_reaction_enabled"))
		return false;

	if (isDefined(self.stuned) && self.stuned)
		return true;

	if (isDefined(self.stunEndTime) && getTime() < self.stunEndTime)
		return true;

	if (isDefined(self.concussionendtime) && getTime() < self.concussionendtime)
		return true;

	if (self maps\mp\_flashgrenades::isflashbanged())
		return true;

	return false;
}

/*
///DocStringBegin
detail: <Player> bot_is_reloading(): <Bool>
summary: Returns true if the bot is currently in a weapon reload animation.
///DocStringEnd
*/
bot_is_reloading()
{
	return isDefined(self.bot) && isDefined(self.bot.isreloading) && self.bot.isreloading;
}

/*
///DocStringBegin
detail: <Player> bot_is_reacting(): <Bool>
summary: True while a self-preservation reaction owns this bot. Any code that steers bots from OUTSIDE the task system must check this and leave the bot alone, or it will drag it back into the danger it is escaping.
///DocStringEnd
*/
bot_is_reacting()
{
	if (self bot_is_stunned())
		return true;

	if (!isDefined(self.actor) || !isDefined(self.actor[REACTING_UNTIL]))
		return false;

	return gettime() < self.actor[REACTING_UNTIL];
}

/*
///DocStringBegin
detail: <Player> bot_get_grenade_flee(): <Bool>
summary: True when this bot would react to grenades right now, taking both the global option and its own opt-out into account.
///DocStringEnd
*/
bot_get_grenade_flee()
{
	if (!lethalbeats\botactor\config::bot_config_get("grenade_flee"))
		return false;

	if (!isDefined(self.actor))
		return false;

	return !(isDefined(self.actor[GRENADE_FLEE_OFF]) && self.actor[GRENADE_FLEE_OFF]);
}

// Watches for live grenades/projectiles and pulls the bot away from them
_botGrenadeWatch()
{
	self endon("disconnect");
	self endon("death");
	level endon("game_ended");

	for (;;)
	{
		wait (lethalbeats\botactor\config::bot_config_get("grenade_tick_ms") / 1000);

		if (!isAlive(self)) continue;

		// Safety net
		if (isDefined(self.botactor_engage_saved) && !self bot_is_reacting())
		{
			self _botGrenadeRestoreEngagement();
			self bot_set_route_sprint(false);
		}

		// Re-read every tick so the option is a live switch, not a spawn-time one.
		if (!self bot_get_grenade_flee()) continue;

		// Already escaping: do not stack a second reaction on top.
		if (self bot_is_reacting()) continue;

		threat = self _botGrenadeNearestThreat();
		if (!isDefined(threat)) continue;

		// A blast is dealt with ONCE
		if (self _botGrenadeSameThreat(threat.origin))
			continue;

		// Global throttle, so a shower of grenades cannot monopolise the bot.
		if (isDefined(self.actor[GRENADE_NEXT_REACT]) && gettime() < self.actor[GRENADE_NEXT_REACT])
			continue;

		// Probabilistic flee check: high percentage flees (~75%), but others stand ground or fight
		fleePct = lethalbeats\botactor\config::bot_config_get("grenade_flee_pct");
		if (!isDefined(fleePct)) fleePct = 75;
		if (fleePct < 100 && randomInt(100) >= fleePct)
		{
			self.botactor_last_threat = threat.origin;
			self.actor[GRENADE_NEXT_REACT] = gettime() + randomIntRange(3500, 5000);
			continue;
		}

		self _botGrenadeReact(threat);
	}
}

_botGrenadeDebug()
{
	return lethalbeats\botactor\config::bot_config_get("grenade_debug") != 0;
}

// Whether this blast is the one already reacted to, so the cooldown applies
_botGrenadeSameThreat(pos)
{
	if (!isDefined(self.botactor_last_threat) || !isDefined(pos))
		return false;

	near = lethalbeats\botactor\config::bot_config_get("grenade_same_threat_dist");
	return distanceSquared(pos, self.botactor_last_threat) <= near * near;
}

// Nearest live threat within the danger radius, or undefined
_botGrenadeNearestThreat()
{
	radius = lethalbeats\botactor\config::bot_config_get("grenade_radius");
	radiusSq = radius * radius;
	debug = self _botGrenadeDebug();

	best = undefined;
	bestDistSq = radiusSq;

	seen = 0;
	rejTeam = 0;
	rejFar = 0;
	rejTrace = 0;

	list = [];
	if (isDefined(level.grenades))
		foreach (ent in level.grenades) list[list.size] = ent;
	if (isDefined(level.missiles))
		foreach (ent in level.missiles) list[list.size] = ent;

	foreach (ent in list)
	{
		if (!isDefined(ent) || !isDefined(ent.origin)) continue;
		seen++;

		if (!self _botGrenadeIsThreat(ent)) { rejTeam++; continue; }

		distSq = distanceSquared(self.origin, ent.origin);
		if (distSq > bestDistSq) { rejFar++; continue; }

		// Last, because a trace is the expensive part. Nothing to run from if a wall is already doing the job.
		if (!bulletTracePassed(ent.origin, self getEye(), false, ent)) { rejTrace++; continue; }

		best = ent;
		bestDistSq = distSq;
	}

	if (debug && seen)
		print("BT_NADE scan bot=" + self.name + " projectiles=" + seen + " rejected(team=" + rejTeam + " far=" + rejFar + " wall=" + rejTrace + ") picked=" + (isDefined(best) ? "YES" : "no"));

	return best;
}

// Whether a projectile is worth running from
_botGrenadeIsThreat(ent)
{
	if (isDefined(ent.weaponname) && ent.weaponname == "claymore_mp")
		return false;

	if (isDefined(ent.model))
	{
		switch (ent.model)
		{
			case "weapon_parabolic_knife":
			case "weapon_jammer":
			case "weapon_radar":
			case "mp_trophy_system":
				return false;
		}
	}

	owner = ent.owner;
	if (!isDefined(owner))
		owner = getMissileOwner(ent);

	// Do not stampede over our own team's grenades.
	if (isDefined(owner) && isDefined(owner.team) && isDefined(self.team) && owner.team == self.team)
		return false;

	return true;
}

// The reaction itself
_botGrenadeReact(threat)
{
	// THE DANGER IS THE POSITION, NOT THE ENTITY
	threatPos = threat.origin;
	self.botactor_last_threat = threatPos;

	windupMin = lethalbeats\botactor\config::bot_config_get("grenade_windup_min_ms");
	windupMax = lethalbeats\botactor\config::bot_config_get("grenade_windup_max_ms");
	if (windupMax < windupMin) windupMax = windupMin;

	// Claim the cooldown BEFORE sleeping, or every tick of the watcher during the windup would start another reaction to the same grenade.
	cooldown = lethalbeats\botactor\config::bot_config_get("grenade_cooldown_ms");
	self.actor[GRENADE_NEXT_REACT] = gettime() + windupMax + cooldown;

	if (windupMax > 0)
		wait (randomIntRange(windupMin, windupMax + 1) / 1000);

	if (!isAlive(self)) return;
	if (!self bot_get_grenade_flee()) return;

	// The grenade may already be gone. Irrelevant - we are leaving the spot it was reported at, which is where the blast is.
	if (isDefined(threat) && isDefined(threat.origin))
		threatPos = threat.origin;

	goal = self _botGrenadeFleeGoal(threatPos);

	if (self _botGrenadeDebug())
	{
		alive = (isDefined(threat) && isDefined(threat.origin)) ? "live" : "ALREADY GONE";
		if (!isDefined(goal))
			print("BT_NADE goal bot=" + self.name + " NONE - no waypoint, no cover, no fallback (threat " + alive + ")");
		else
			print("BT_NADE goal bot=" + self.name + " src=" + self.botactor_flee_src + " gain=" + int(distance(goal, threatPos) - distance(self.origin, threatPos)) + "u run=" + int(distance(self.origin, goal)) + "u (threat " + alive + ")");
	}

	if (!isDefined(goal)) return;

	flee = lethalbeats\botactor\behavior::bot_task_custom(::_botGrenadeFleeTask, goal);

	// A newer threat replaces this one; escaping a grenade that already went off is worse than useless.
	flee.resume = false;

	fleeMs = randomIntRange(1200, 2200);
	self.actor[REACTING_UNTIL] = gettime() + fleeMs;

	self lethalbeats\botactor\behavior::bot_do_now(flee);
}

_botGrenadeSuppressEngagement()
{
	if (isDefined(self.botactor_engage_saved))
		return;

	self.botactor_engage_saved = self lethalbeats\botactor\behavior::bot_get_engagement();
	self lethalbeats\botactor\behavior::bot_set_engagement("none");
}

// Puts the bot back to war
_botGrenadeRestoreEngagement()
{
	if (!isDefined(self.botactor_engage_saved))
		return;

	saved = self.botactor_engage_saved;
	self.botactor_engage_saved = undefined;
	self lethalbeats\botactor\behavior::bot_set_engagement(saved);
}

/*
///DocStringBegin
detail: <Player> bot_grenade_force_flee(threatPos: <Vector3>): <Bool>
summary: Test hook. Runs the flee against a position you supply, skipping detection entirely, so the movement half can be exercised on its own. Returns false when no goal could be found.
///DocStringEnd
*/
bot_grenade_force_flee(threatPos)
{
	if (!isDefined(threatPos) || !isDefined(self.actor))
		return false;

	goal = self _botGrenadeFleeGoal(threatPos);
	if (!isDefined(goal))
	{
		if (self _botGrenadeDebug())
			print("BT_NADE force bot=" + self.name + " NO GOAL");
		return false;
	}

	if (self _botGrenadeDebug())
		print("BT_NADE force bot=" + self.name + " src=" + self.botactor_flee_src + " run=" + int(distance(self.origin, goal)) + "u gain=" + int(distance(goal, threatPos) - distance(self.origin, threatPos)) + "u");

	flee = lethalbeats\botactor\behavior::bot_task_custom(::_botGrenadeFleeTask, goal);
	flee.resume = false;

	// Same order as the real reaction: claim, break off, then queue.
	self.actor[REACTING_UNTIL] = gettime() + GRENADE_FLEE_MAX_MS;
	self _botGrenadeSuppressEngagement();

	self lethalbeats\botactor\behavior::bot_do_now(flee);
	return true;
}

/*
///DocStringBegin
detail: <Player> bot_grenade_report(threatPos?: <Vector3>): <Void>
summary: Test hook. Prints why this bot would or would not react right now: option state, cooldown, live projectiles, and what goal it would pick for threatPos.
///DocStringEnd
*/
bot_grenade_report(threatPos)
{
	name = self.name;

	nades = 0;
	if (isDefined(level.grenades)) nades = level.grenades.size;
	missiles = 0;
	if (isDefined(level.missiles)) missiles = level.missiles.size;

	wps = 0;
	if (isDefined(level.waypoints)) wps = level.waypoints.size;

	cooldown = 0;
	if (isDefined(self.actor[GRENADE_NEXT_REACT]))
		cooldown = self.actor[GRENADE_NEXT_REACT] - gettime();
	if (cooldown < 0) cooldown = 0;

	print("BT_NADE report " + name
		+ " | flee=" + (self bot_get_grenade_flee() ? "on" : "OFF")
		+ " reacting=" + (self bot_is_reacting() ? "YES" : "no")
		+ " cooldown=" + cooldown + "ms"
		+ " | level.grenades=" + nades + " level.missiles=" + missiles + " waypoints=" + wps);

	threat = self _botGrenadeNearestThreat();
	if (isDefined(threat))
		print("BT_NADE report " + name + " | live threat at " + int(distance(self.origin, threat.origin)) + "u");
	else
		print("BT_NADE report " + name + " | no live threat in radius");

	if (!isDefined(threatPos))
		return;

	goal = self _botGrenadeFleeGoal(threatPos);
	if (!isDefined(goal))
		print("BT_NADE report " + name + " | would pick NO GOAL for that position");
	else
		print("BT_NADE report " + name + " | would pick src=" + self.botactor_flee_src + " run=" + int(distance(self.origin, goal)) + "u gain=" + int(distance(goal, threatPos) - distance(self.origin, threatPos)) + "u");
}

_botGrenadeFleeTask(goal)
{
	fleeMs = self.actor[REACTING_UNTIL] - gettime();
	if (fleeMs <= 0) fleeMs = randomIntRange(1200, 2200);
	self.actor[MOVE_LOOK_MODE] = 0;
	self bot_set_route_sprint(true);
	self bot_stop_attack();
	self bot_release_ads();

	debug = self _botGrenadeDebug();
	startPos = self.origin;
	startTime = gettime();

	self.botactor_route_tag = "flee";
	fleeTimeout = float(fleeMs) * 0.001;
	ok = self lethalbeats\botactor\navigation::bot_go_to(goal, 48, 1.5, fleeTimeout, false, false);

	if (debug)
	{
		reached = "NO";
		if (isDefined(ok) && ok)
			reached = "YES";

		print("BT_NADE run bot=" + self.name + " reached=" + reached + " moved=" + int(distance(startPos, self.origin)) + "u of " + int(distance(startPos, goal)) + "u in " + (gettime() - startTime) + "ms");
	}

	self bot_set_route_sprint(false);
	self.actor[MOVE_LOOK_MODE] = 1;
	self.actor[REACTING_UNTIL] = 0;
	return true;
}

// A real WAYPOINT out of the blast, not a point in space
_botGrenadeFleeGoal(threatPos)
{
	self.botactor_flee_src = "waypoint";
	wp = self _botGrenadeFleeWaypoint(threatPos);
	if (isDefined(wp))
		return wp;

	fleeDist = lethalbeats\botactor\config::bot_config_get("grenade_flee_dist");

	away = (self.origin[0] - threatPos[0], self.origin[1] - threatPos[1], 0);
	if (lengthSquared(away) < 1)
		away = anglesToForward((0, randomInt(360), 0));

	away = vectorNormalize(away);
	awayPos = self.origin + (away * fleeDist);

	cover = self bot_find_cover(fleeDist, awayPos, undefined, false);
	if (isDefined(cover) && isDefined(cover.origin))
	{
		if (distanceSquared(cover.origin, threatPos) > distanceSquared(self.origin, threatPos))
		{
			self.botactor_flee_src = "cover";
			return cover.origin;
		}
	}

	self.botactor_flee_src = "raw";
	return awayPos;
}

// Prefers the CLOSEST waypoint that is clear of the blast radius - shortest run
_botGrenadeFleeWaypoint(threatPos)
{
	self lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	fleeDist = lethalbeats\botactor\config::bot_config_get("grenade_flee_dist");
	radius = lethalbeats\botactor\config::bot_config_get("grenade_radius");

	travelSq = (fleeDist * 1.5) * (fleeDist * 1.5);
	safeSq = radius * radius;
	myDistSq = distanceSquared(self.origin, threatPos);

	bestSafe = undefined;
	bestSafeRun = travelSq + 1;
	bestFar = undefined;
	bestFarThreat = myDistSq;

	for (i = 0; i < level.waypoints.size; i++)
	{
		wpNode = level.waypoints[i];
		if (!isDefined(wpNode) || !isDefined(wpNode.origin)) continue;
		if (isDefined(wpNode.type) && (wpNode.type == "climb" || wpNode.type == "prone")) continue;

		runSq = distanceSquared(self.origin, wpNode.origin);
		if (runSq > travelSq) continue;

		threatSq = distanceSquared(wpNode.origin, threatPos);

		// Must improve on where we already stand, or it is not an escape.
		if (threatSq <= myDistSq) continue;

		if (threatSq >= safeSq)
		{
			if (runSq < bestSafeRun)
			{
				bestSafeRun = runSq;
				bestSafe = wpNode;
			}
			continue;
		}

		if (threatSq > bestFarThreat)
		{
			bestFarThreat = threatSq;
			bestFar = wpNode;
		}
	}

	if (isDefined(bestSafe)) return bestSafe.origin;
	if (isDefined(bestFar)) return bestFar.origin;
	return undefined;
}

bot_go_to(goal, stop_dist, wp_timeout, goal_timeout, keep_patrol, keep_chase)
{
	return self lethalbeats\botactor\navigation::bot_go_to(goal, stop_dist, wp_timeout, goal_timeout, keep_patrol, keep_chase);
}

bot_go_to_node(node, stop_dist, wp_timeout, goal_timeout, keep_patrol, keep_chase)
{
	if (!isDefined(node) || !isDefined(node.origin))
		return false;

	self.bot_goto_goal_node = node;
	if (isDefined(self.actor[CHASE_TARGET]))
		self.bot_goto_goal_target = self.actor[CHASE_TARGET];
	else
		self.bot_goto_goal_target = undefined;
	return self lethalbeats\botactor\navigation::bot_go_to(node.origin, stop_dist, wp_timeout, goal_timeout, keep_patrol, keep_chase);
}

/*
///DocStringBegin
detail: bot_find_radial_waypoint(center?: <Vector|Entity>, minRadius?: <Float>, maxRadius?: <Float>, minAngle?: <Float>, maxAngle?: <Float>, baseAngle?: <Float>, checkSight?: <Bool>, targetEntity?: <Entity>): <Struct|Undefined>
summary: Finds a waypoint within a radial distance range and angular arc around center.
///DocStringEnd
*/
bot_find_radial_waypoint(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, checkSight, targetEntity)
{
	return self lethalbeats\botactor\navigation::bot_find_radial_waypoint(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, checkSight, targetEntity);
}

/*
///DocStringBegin
detail: bot_reposition_radial(center?: <Vector|Entity>, minRadius?: <Float>, maxRadius?: <Float>, minAngle?: <Float>, maxAngle?: <Float>, baseAngle?: <Float>, timeout?: <Float>, stopDist?: <Float>): <Bool>
summary: Finds a radial waypoint and executes movement towards it.
///DocStringEnd
*/
bot_reposition_radial(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, timeout, stopDist)
{
	return self lethalbeats\botactor\navigation::bot_reposition_radial(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, timeout, stopDist);
}

/*
///DocStringBegin
detail: bot_task_reposition_radial(center?: <Vector|Entity>, minRadius?: <Float>, maxRadius?: <Float>, minAngle?: <Float>, maxAngle?: <Float>, baseAngle?: <Float>, timeout?: <Float>, stopDist?: <Float>): <Struct>
summary: Constructs a reposition task to move radially around a center position or target entity.
///DocStringEnd
*/
bot_task_reposition_radial(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, timeout, stopDist)
{
	return self lethalbeats\botactor\behavior::bot_task_reposition_radial(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, timeout, stopDist);
}

bot_stop_move()
{
	if (!isDefined(self))
		return;
	if (!isDefined(self.actor))
		return;

	canInput = self _botCanUseBotAction();
	if (canInput)
	{
		self notify("bot_stop_move");
		self notify("bot_stop");
		self bot_release_sprint();
		self bot_release_melee();
	}

	if (isDefined(self.bot))
	{
		self.bot.stop_move = true;
		self.bot.moveto = undefined;
	}

	self.actor[SCRIPT_MOVE] = false;
	self.actor[PATH_LOCK] = false;
	self.actor[MOVE_LOOK_MODE] = 1;
	self.actor[PATROL_ACTIVE] = false;
	self.actor[LOCK] = false;
}

bot_stop_attack()
{
	if (!isDefined(self))
		return;
	if (!isDefined(self.actor))
		return;

	self bot_release_fire();
	self bot_release_melee();

	self.actor[BEST_TARGET_CURRENT] = undefined;
	self.actor[BEST_TARGET_LAST_UPDATE] = 0;
	self.actor[AIM_POS] = undefined;
}

bot_stop_look()
{
	if (!isDefined(self))
		return;
	if (!isDefined(self.actor))
		return;

	self.actor[AIM_POS] = undefined;
	self.actor[MOVE_LOOK_DIR] = undefined;
}

bot_stop_all()
{
	self bot_stop_attack();
	self bot_stop_look();
	self bot_stop_move();
	self bot_avoid_clear();
}

/*
///DocStringBegin
detail: bot_set_targets(targets: <Entity | Entity[]>): <Void>
summary: Set enabled target candidates for callback-driven selection pipeline.
///DocStringEnd
*/
bot_set_targets(targets)
{
	if (!isDefined(self))
		return;
	if (!isDefined(self.actor))
		return;

	self.actor[BEST_TARGET_CURRENT] = undefined;
	self.actor[BEST_TARGET_LAST_UPDATE] = 0;
	self.actor[AIM_POS] = undefined;

	if (!isDefined(targets))
	{
		self.actor[ENABLED_TARGETS] = [];
		return;
	}

	_targets = [];
	if (isArray(targets))
	{
		foreach(target in targets)
			if (isDefined(target)) _targets[_targets.size] = target;
	}
	else
	{
		_targets[_targets.size] = targets;
	}

	self.actor[ENABLED_TARGETS] = _targets;
	self.actor[BEST_TARGET_CURRENT] = undefined;
	self.actor[BEST_TARGET_LAST_UPDATE] = 0;
}

/*
///DocStringBegin
detail: Bot bot_set_target(targets: <Entity | Entity[]>): <Void>
summary: Backward-compatible alias for bot_set_targets.
///DocStringEnd
*/
bot_set_target(targets)
{
	self bot_set_targets(targets);
}

/*
///DocStringBegin
detail: bot_enable_target(targets: <Entity | Entity[]>): <Void>
summary: Legacy alias used by older survival/squad scripts; maps to bot_set_targets.
///DocStringEnd
*/
bot_enable_target(targets)
{
	self bot_set_targets(targets);
}

/*
///DocStringBegin
detail: bot_actor_set_inert(inert: <Bool>): <Void>
summary: Compatibility shim for legacy runtimes. When inert=true, stop movement/combat; when false, re-enable scripted control.
///DocStringEnd
*/
bot_actor_set_inert(inert)
{
	if (!isDefined(inert))
		inert = true;

	if (inert)
	{
		self bot_stop_all();
		self.actor[LOCK] = true;
		return;
	}

	self.actor[LOCK] = false;
}

/*
///DocStringBegin
detail: bot_set_path_priority(priority: <Bool>): <Void>
summary: When true, bot prioritizes current path (bot_go_to) over chase. Bot still aims and shoots at targets but won't deviate from path to pursue them.
///DocStringEnd
*/
bot_set_path_priority(priority)
{
	if (!isDefined(priority))
		priority = true;
	self.actor[PATH_LOCK] = priority;
}

/*
///DocStringBegin
detail: <Player> bot_set_charge(enabled: <Bool>): <Void>
summary: Enables or disables relentless charge mode (rush target directly with no standoff or backpedal, like attack dogs).
///DocStringEnd
*/
bot_set_charge(enabled)
{
	if (!isDefined(enabled))
		enabled = true;

	self.actor[MELEE_CHARGE] = enabled;
	self.bot_is_charge_mode = enabled;
}

/*
///DocStringBegin
detail: <Player> bot_is_charging(): <Bool>
summary: Returns true if the bot is in charge rush mode.
///DocStringEnd
*/
bot_is_charging()
{
	if (isDefined(self.bot_is_charge_mode) && self.bot_is_charge_mode)
		return true;

	if (isDefined(self.actor) && isDefined(self.actor[MELEE_CHARGE]) && self.actor[MELEE_CHARGE])
		return true;

	return false;
}

bot_hold_melee_charge()
{
	self bot_set_charge(true);
}

bot_release_melee_charge()
{
	self bot_set_charge(false);
}

bot_chase(target)
{
	if (isDefined(self.goap) && isDefined(self.goap.current_action))
		return;

	if (!isDefined(target))
		target = self.actor[CHASE_TARGET];

	if (!isDefined(target) || !isDefined(target.origin))
	{
		self notify("bot_chase");
		self.actor[CHASE_TARGET] = undefined;
		self.actor[CHASE_NEXT_MOVE_TIME] = 0;
		self.actor[CHASE_LAST_GOAL] = undefined;
		self bot_set_target(undefined);
		self bot_stop_move();
		return;
	}

	self notify("bot_chase");
	self.actor[CHASE_TARGET] = target;
	self.actor[MELEE_CHARGE] = false;
	self.actor[PATH_LOCK] = false;

	self bot_set_target(target);
	self thread lethalbeats\botactor\navigation::_botChaseLoop(target);
}

bot_melee_charge(target)
{
	if (!isDefined(target))
		target = self.actor[CHASE_TARGET];

	if (!isDefined(target) || !isDefined(target.origin))
		return;

	self notify("bot_chase");
	self.actor[CHASE_TARGET] = target;
	self.actor[MELEE_CHARGE] = true;
	self.actor[PATH_LOCK] = false;

	self bot_set_target(target);
	self thread lethalbeats\botactor\navigation::_botChaseLoop(target);
}

bot_set_team(team)
{
	if (!isDefined(team)) return;
	self.pers["team"] = team;
	self.team = team;
	self.sessionteam = team;
	self bot_stop_all();
}

bot_get_weapon_shoot_distance()
{
	weapon = self getCurrentWeapon();
	class = lethalbeats\weapon::weapon_get_class(weapon);

	dist = [];
	dist["min"] = 192;
	dist["max"] = 700;

	switch(class)
	{
		case "riot":
			dist["min"] = 0;
			dist["max"] = 120;
			break;
		case "shotgun":
		case "pistol":
		case "machine_pistol":
			dist["min"] = 100;
			dist["max"] = 300;
			break;
		case "smg":
			dist["min"] = 300;
			dist["max"] = 600;
			break;
		case "assault":
		case "lmg":
			dist["min"] = 600;
			dist["max"] = 1000;
			break;
		case "projectile":
		case "sniper":
			dist["min"] = 1000;
			dist["max"] = 3000;
			break;
	}

	return dist;
}

/*
///DocStringBegin
detail: bot_set_chase_distance(dist_min: <Float>, dist_max: <Float>): <Void>
summary: Configures the minimum and maximum chase distances.
///DocStringEnd
*/
bot_set_chase_distance(dist_min, dist_max)
{
	default_dist = undefined;

	if (!isDefined(dist_min) || dist_min < 0)
	{
		default_dist = self bot_get_weapon_shoot_distance();
		dist_min = default_dist["min"];
	}

	if (!isDefined(dist_max) || dist_max <= 0)
	{
		if (!isDefined(default_dist)) default_dist = self bot_get_weapon_shoot_distance();
		dist_max = default_dist["max"];
	}

	if (dist_max < dist_min) dist_max = dist_min;

	self.actor[SKILL_CHASE_DIST_MIN] = float(dist_min);
	self.actor[SKILL_CHASE_DIST_MAX] = float(dist_max);
}

/*
///DocStringBegin
detail: bot_set_chase_dist_min(dist_min: <Float>): <Void>
summary: Configures the minimum chase distance.
///DocStringEnd
*/
bot_set_chase_dist_min(dist_min)
{
	if (!isDefined(dist_min) || dist_min < 0)
	{
		dist_min = self bot_get_weapon_shoot_distance()["min"];
	}

	self.actor[SKILL_CHASE_DIST_MIN] = float(dist_min);
}

/*
///DocStringBegin
detail: bot_set_chase_dist_max(dist_max: <Float>): <Void>
summary: Configures the maximum chase distance.
///DocStringEnd
*/
bot_set_chase_dist_max(dist_max)
{
	if (!isDefined(dist_max) || dist_max < 0)
	{
		dist_max = self bot_get_weapon_shoot_distance()["max"];
	}

	self.actor[SKILL_CHASE_DIST_MAX] = float(dist_max);
}

bot_set_dist_max(dist)
{
	if (!isDefined(self.actor)) // Initialize if not present
		self.actor = [];

	if (!isDefined(dist))
	{
		self.actor[SKILL_DIST_MAX] = 100000 * 2;
		return;
	}

	if (dist < 0)
		dist = 0;

	self.actor[SKILL_DIST_MAX] = dist;
}

bot_get_melee_distance()
{
	if (!isDefined(self.actor[SKILL_MELEE_DIST]) || self.actor[SKILL_MELEE_DIST] <= 0)
		return 128 * 128; // Default squared distance

	dist = self.actor[SKILL_MELEE_DIST];
	return dist * dist;
}

bot_set_melee_distance(dist)
{
	if (!isDefined(dist) || dist <= 0)
	{
		// Fallback to default linear distance
		self.actor[SKILL_MELEE_DIST] = 120;
		return;
	}

	self.actor[SKILL_MELEE_DIST] = float(dist);
}

bot_set_sprint(hold)
{
	self.actor[HOLD_SPRINT] = hold;
}

_botCanUseBotAction()
{
	if (!isDefined(self))
		return false;

	isPlayerEnt = isPlayer(self);
	if (!isDefined(isPlayerEnt))
		return false;
	if (!isPlayerEnt)
		return false;

	alive = isAlive(self);
	if (!isDefined(alive))
		return false;

	return alive;
}

bot_press_remote(time) { if (isDefined(self)) self thread _botPressButton("remote", time); }
bot_press_breath(time) { if (isDefined(self)) self thread _botPressButton("holdbreath", time); }
bot_press_sprint(time) { if (isDefined(self)) self thread _botPressButton("sprint", time); }
// "+gostand" is the JUMP button in IW5
bot_press_jump(time) { if (isDefined(self)) self thread _botPressButton("gostand", time); }
bot_press_stand(time) { self lethalbeats\botactor\movement::bot_set_stance("stand"); }
bot_press_frag(time) { if (isDefined(self)) self thread _botPressButton("frag", time); }
bot_press_melee(time) { if (isDefined(self)) self thread _botPressButton("melee", time); }
bot_press_reload(time) { if (isDefined(self)) self thread _botPressButton("reload", time); }
bot_press_smoke(time) { if (isDefined(self)) self thread _botPressButton("smoke", time); }
bot_press_fire(time) { if (isDefined(self)) self thread _botPressButton("fire", time); }
bot_press_fire_hold(time) { if (isDefined(self)) self thread _botHoldFireFor(time); }
bot_press_ads(time) { if (isDefined(self)) self thread _botPressButton("ads", time); }
bot_press_activate(time) { if (isDefined(self)) self thread _botPressButton("activate", time); }
bot_press_crouch(time) { if (isDefined(self)) self thread _botPressButton("gocrouch", time); }
bot_press_prone(time) { if (isDefined(self)) self thread _botPressButton("goprone", time); }
bot_press_mantle(time) { self bot_press_jump(time); }

bot_hold_sprint()
{
	if (!isDefined(self))
		return;
	if (!isDefined(self.actor))
		return;

	self.actor[SPRINT_STATE] = true;
	self.actor[HOLD_SPRINT] = true;
	self _botButtonDown("sprint");
}
bot_release_sprint()
{
	if (!isDefined(self))
		return;

	if (isDefined(self.actor))
	{
		self.actor[SPRINT_STATE] = false;
		self.actor[HOLD_SPRINT] = false;
	}

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self botaction("-sprint");
}
bot_hold_fire() { if (isDefined(self)) self _botButtonDown("fire"); }
bot_release_fire()
{
	if (!isDefined(self))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self botaction("-fire");
}
bot_hold_melee() { if (isDefined(self)) self _botButtonDown("melee"); }
bot_release_melee()
{
	if (!isDefined(self))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self botaction("-melee");
}
bot_hold_ads() { if (isDefined(self)) self _botButtonDown("ads"); }
bot_release_ads()
{
	if (!isDefined(self))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self botaction("-ads");
}

/*
///DocStringBegin
detail: bot_disable_nodes(type <String>, disable <Bool>): <Void>
summary: Enables or disables a specific waypoint type for the bot's navigation.
///DocStringEnd
*/
bot_disable_nodes(type, disable)
{
	if (!isDefined(self.actor[DISABLED_NODES]))
		self.actor[DISABLED_NODES] = [];

	self.actor[DISABLED_NODES][type] = disable;
}

/*
///DocStringBegin
detail: bot_is_node_type_disabled(type <String>): <Bool>
summary: Returns true if the specified waypoint type is disabled for this bot.
///DocStringEnd
*/
bot_is_node_type_disabled(type)
{
	if (!isDefined(type) || !isDefined(self.actor[DISABLED_NODES]))
		return false;

	val = self.actor[DISABLED_NODES][type];
	return isDefined(val) && val;
}

bot_is_sprinting() { return self.actor[SPRINT_STATE]; }

bot_is_in_combat() { return !self.hasdonecombat; }

bot_get_enemy_eye_pos()
{
	target = self bot_get_current_target();
	return isPlayer(target) ? target getEye() : target.origin;
}

bot_target_is_valid(target)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return false;

	if (isPlayer(target))
	{
		if (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand))
			return false;
	}
	else if (!isAlive(target))
		return false;

	if (isDefined(self.actor[TARGET_FILTER]) && !self [[self.actor[TARGET_FILTER]]](target))
		return false;

	targets = [];
	targets[0] = target;
	validTargets = self bot_get_valid_targets(targets);

	for (i = 0; i < validTargets.size; i++)
	{
		if (validTargets[i] == target)
			return true;
	}

	return false;
}

/*
///DocStringBegin
detail: bot_default_valid_targets(targets: <Entity[]>): <Entity[]>
summary: Default target validator used by VALID_TARGETS pointer; enforces basic validity and optional legacy TARGET_FILTER.
///DocStringEnd
*/
bot_default_valid_targets(targets)
{
	newTargets = [];

	if (!isDefined(targets) || (isArray(targets) && targets.size == 0))
	{
		// Fallback for Survival mode bots lacking explicit targets
		foreach (player in level.players)
		{
			if (!isDefined(player) || !isAlive(player) || player == self) continue;
			if (isDefined(player.sessionState) && player.sessionState != "playing") continue;
			if (isDefined(player.inLastStand) && player.inLastStand) continue;
			if (player.team == self.team && !isDefined(self.actor[TARGET_FILTER])) continue;
			newTargets[newTargets.size] = player;
		}

		targets = newTargets;
	}

	if (!isDefined(targets) || !targets.size)
		return newTargets;

	for (i = 0; i < targets.size; i++)
	{
		target = targets[i];

		if (!isDefined(target) || !isDefined(target.origin))
			continue;

		if (isPlayer(target))
		{
			if (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand))
				continue;
		}
		else if (!isAlive(target))
			continue;

		if (isDefined(self.actor[TARGET_FILTER]) && !self [[self.actor[TARGET_FILTER]]](target))
			continue;

		newTargets[newTargets.size] = target;
	}

	return newTargets;
}

/*
///DocStringBegin
detail: bot_default_best_target(validTargets: <Entity[]>): <Entity>
summary: Default BEST_TARGET callback; picks nearest entity from valid target list.
///DocStringEnd
*/
bot_default_best_target(validTargets)
{
	return self lethalbeats\player::player_get_nearest_entity(validTargets);
}

/*
///DocStringBegin
detail: bot_get_valid_targets(targets: <Entity[] | Entity>): <Entity[]>
summary: Executes VALID_TARGETS callback and sanitizes output for safety.
///DocStringEnd
*/
bot_get_valid_targets(targets)
{
	inputTargets = [];

	if (isDefined(targets))
	{
		if (isArray(targets))
		{
			if (targets.size > 0)
				inputTargets = targets;
		}
		else
		{
			inputTargets[0] = targets;
		}
	}
	else
	{
		inputTargets = [];
		foreach (player in level.players)
		{
			if (!isDefined(player) || !isAlive(player) || player == self) continue;
			if (isDefined(player.sessionState) && player.sessionState != "playing") continue;
			if (isDefined(player.inLastStand) && player.inLastStand) continue;
			if (player.team == self.team && !isDefined(self.actor[TARGET_FILTER])) continue;

			inputTargets[inputTargets.size] = player;
		}
	}

	if (!isDefined(self.actor[VALID_TARGETS]))
		self.actor[VALID_TARGETS] = ::bot_default_valid_targets;

	rawValidTargets = self [[self.actor[VALID_TARGETS]]](inputTargets);
	cleanTargets = [];

	if (!isDefined(rawValidTargets) || !rawValidTargets.size)
		return cleanTargets;

	for (i = 0; i < rawValidTargets.size; i++)
	{
		target = rawValidTargets[i];

		if (!isDefined(target) || !isDefined(target.origin))
			continue;

		if (isPlayer(target))
		{
			if (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand))
				continue;
		}
		else if (!isAlive(target))
			continue;

		cleanTargets[cleanTargets.size] = target;
	}

	return cleanTargets;
}

/*
///DocStringBegin
detail: bot_select_target(): <Entity>
summary: Returns the selected target using utility-level validation/filter callback and nearest-valid fallback.
///DocStringEnd
*/
bot_select_target()
{
	validTargets = self bot_get_valid_targets(self.actor[ENABLED_TARGETS]);

	if (!validTargets.size)
	{
		self.actor[BEST_TARGET_CURRENT] = undefined;
		return undefined;
	}

	if (!isDefined(self.actor[BEST_TARGET]))
		self.actor[BEST_TARGET] = ::bot_default_best_target;

	now = gettime();
	current = self.actor[BEST_TARGET_CURRENT];
	currentStillValid = false;

	if (isDefined(current) && isDefined(current.origin))
	{
		for (i = 0; i < validTargets.size; i++)
		{
			if (validTargets[i] == current)
			{
				currentStillValid = true;
				break;
			}
		}
	}

	intervalSec = self.actor[BEST_TARGET_UPDATE_INTERVAL];
	if (!isDefined(intervalSec) || intervalSec < 0)
		intervalSec = 0;

	if (currentStillValid && intervalSec > 0)
	{
		lastUpdate = self.actor[BEST_TARGET_LAST_UPDATE];
		if (!isDefined(lastUpdate)) lastUpdate = 0;

		if (now - lastUpdate < int(intervalSec * 1000))
			return current;
	}

	bestTarget = self [[self.actor[BEST_TARGET]]](validTargets);

	if (isDefined(bestTarget) && isDefined(bestTarget.origin))
	{
		for (i = 0; i < validTargets.size; i++)
		{
			if (validTargets[i] == bestTarget)
			{
				self.actor[BEST_TARGET_CURRENT] = bestTarget;
				self.actor[BEST_TARGET_LAST_UPDATE] = now;
				return bestTarget;
			}
		}
	}

	fallback = self bot_default_best_target(validTargets);
	self.actor[BEST_TARGET_CURRENT] = fallback;
	self.actor[BEST_TARGET_LAST_UPDATE] = now;
	return fallback;
}

bot_has_targets()
{
	return self bot_get_valid_targets(self.actor[ENABLED_TARGETS]).size > 0;
}

bot_get_skill(define_idx, defaultValue)
{
	if (!isDefined(self.actor) || !isDefined(self.actor[define_idx]))
		return defaultValue;

	return self.actor[define_idx];
}

bot_set_skill(define_idx, value)
{
	if (!isDefined(self.actor[define_idx])) return;
	if (!isDefined(value)) value = self bot_get_skill(define_idx);
	self.actor[define_idx] = value;
}

_botButtonDown(buttonName)
{
	if (!isDefined(self))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self notify("bot_press_" + buttonName);
	self botaction("+" + buttonName);
}

_botButtonUp(buttonName)
{
	if (!isDefined(self))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self notify("bot_press_" + buttonName);
	self botaction("-" + buttonName);
}

_botHoldFireFor(time)
{
	if (!isDefined(self))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self bot_hold_fire();
	if (!isDefined(time))
		time = 0.05;
	else if (time == 0)
		time = 0.05;

	wait time;
	if (!isDefined(self))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self bot_release_fire();
}

_botPressButton(buttonName, time)
{
	if (!isDefined(self))
		return;
	if (!isDefined(self.actor))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	self notify("bot_press_" + buttonName);
	self endon("bot_press_" + buttonName);
	self endon("disconnect");
	self endon("death");

	negativeHold = false;
	if (isDefined(time))
	{
		if (time < 0)
			negativeHold = true;
	}

	if (negativeHold)
	{
		if (!isDefined(self))
			return;

		canInput = self _botCanUseBotAction();
		if (!canInput)
			return;

		self botaction("+" + buttonName);
		return;
	}

	if (!isDefined(time))
		time = 0.05;
	else if (time == 0)
		time = 0.05;

	self.actor[LOCK] = true;
	self botaction("+" + buttonName);
	wait time;

	if (!isDefined(self))
		return;
	if (!isDefined(self.actor))
		return;

	canInput = self _botCanUseBotAction();
	if (!canInput)
		return;

	if (buttonName == "sprint")
	{
		if (isDefined(self.actor[HOLD_SPRINT]))
		{
			if (self.actor[HOLD_SPRINT])
				return;
		}
	}

	self botaction("-" + buttonName);
	self.actor[LOCK] = true;
}

_botSprintMonitor()
{
	self endon("disconnect");
	self endon("death");

	for (;;)
	{
		self waittill("sprint_begin");
		self.actor[SPRINT_STATE] = true;
		self waittill("sprint_end");
		self.actor[SPRINT_STATE] = false;
		if (self.actor[HOLD_SPRINT]) self bot_press_sprint();
	}
}

