/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : navigation       |
|Creator : LastDemon99	   |
|Type : AI / Navigation    |
============================
*/

#include lethalbeats\botActor\utility;
#include lethalbeats\botactor\targeting;
#include lethalbeats\botActor\config;

#define LOCK 0
#define SPRINT_STATE 1
#define HOLD_SPRINT 2
#define ROUTE_SPRINT 135
#define SCRIPT_MOVE 3
#define PATH_LOCK 4
#define TARGET_MONITOR 5
#define HEARTBEAT_TARGET 6
#define HEARTBEAT_NAV 7
#define HEARTBEAT_MOVE 8

#define BEHAVIOR_COVER_SNAP 106
#define BEHAVIOR_COVER_MIN_TIME 107
#define BEHAVIOR_COVER_MAX_TIME 108
#define COVER_HOLDING_END_TIME 109
#define COVER_CURRENT_NODE 117

#define PATROL_ACTIVE 20
#define PATROL_LOOP 21
#define CHASE_TARGET 22
#define CHASE_NEXT_MOVE_TIME 23
#define CHASE_LAST_GOAL 24
#define CHASE_NEXT_HANDOVER 25
#define CACHED_PATH_DIST_SQ 26
#define NEXT_PATH_DIST_UPDATE 27
#define AVOID_ZONES 28
#define AVOID_WP 29
#define LAST_WALL_FLANK_WP 30
#define LAST_WAYPOINT_BYPASS_WP 31
#define NEGATIVE_MODE 32
#define MELEE_CHARGE 33
#define CHASE_HANDOVER_ACTIVE 34
#define CHASE_DIRECT_BLOCKED 35

#define AIM_POS 41
#define MOVE_LOOK_MODE 46

#define WP_CLAIM_PENALTY 24
#define MOVE_LOOK_DIR 45
#define SKILL_REMEMBER_TIME 65
#define SKILL_LOCATION_REMEMBER_TIME 66
#define SKILL_BONES 73
#define SKILL_CHASE_DIST_MIN 76
#define SKILL_CHASE_DIST_MAX 77
#define SKILL_MELEE_DIST 78

#define SIGHT_MAX_PITCH 0.90        // ~64 degrees: max abs sin(pitch) for navigation sight checks

// Tuning comes from lethalbeats\botactor\config, never from a dvar. See that file for why.
_botNavigationOpt(name)
{
	return lethalbeats\botactor\config::bot_config_get(name);
}

_botNavigationIsLiteGoap()
{
	return isDefined(self.goap) && isDefined(self.goap.full_allowed) && !self.goap.full_allowed;
}

_botNavigationChaseTick()
{
	tickMs = _botNavigationOpt("chase_tick_ms");
	return float(tickMs) * 0.001;
}

_botNavigationChaseRepathDist()
{
	return _botNavigationOpt("chase_repath_dist");
}

_botNavigationEdgeFailTtl()
{
	return _botNavigationOpt("edge_fail_ttl_ms");
}

_botNavigationTraversalTimeout(baseTimeout)
{
	if (!isDefined(baseTimeout))
		baseTimeout = 3.0;

	timeout = baseTimeout + 2.5;
	if (timeout < 5.0)
		timeout = 5.0;

	return timeout;
}

_botGetWaypoint(index)
{
	if (!isDefined(index) || !isDefined(level.waypoints))
		return undefined;

	wp = level.waypoints[index];
	if (!isDefined(wp) || !isDefined(wp.origin))
		return undefined;

	return wp;
}

_botGetWaypointOrigin(index)
{
	if (!isDefined(index) || !isDefined(level.waypoints))
		return undefined;

	wp = level.waypoints[index];
	if (!isDefined(wp) || !isDefined(wp.origin))
		return undefined;

	return wp.origin;
}

_botNavigationUsePathBudget(now)
{
	maxSearches = _botNavigationOpt("path_searches_per_tick");
	if (maxSearches <= 0)
		return false;

	if (!isDefined(level.botactor_path_budget_time) || now - level.botactor_path_budget_time >= 50)
	{
		level.botactor_path_budget_time = now;
		level.botactor_path_budget = maxSearches;
	}

	if (!isDefined(level.botactor_path_budget) || level.botactor_path_budget <= 0)
		return false;

	level.botactor_path_budget--;
	return true;
}

/*
///DocStringBegin
detail: bot_wp_is_traversal(wp: <Struct>): <Bool>
summary: True for nodes that only fit one body at a time: climb, mantle and jump.
///DocStringEnd
*/
bot_wp_is_traversal(wp)
{
	if (!isDefined(wp) || !isDefined(wp.type))
		return false;

	return wp.type == "climb" || wp.type == "mantle" || wp.type == "jump" || wp.type == "doorway";
}

/*
///DocStringBegin
detail: bot_wp_is_doorway(wp: <Struct>): <Bool>
summary: True for doorway / gap portal nodes.
///DocStringEnd
*/
bot_wp_is_doorway(wp)
{
	if (!isDefined(wp) || !isDefined(wp.type))
		return false;

	return wp.type == "doorway";
}

/*
///DocStringBegin
detail: bot_wp_claim_owner(wpIdx: <Int>): <Entity | Undefined>
summary: Bot currently holding that traversal. Clears expired claims and claims from dead bots on the way, so nothing has to release them for the system to stay healthy.
///DocStringEnd
*/
bot_wp_claim_owner(wpIdx)
{
	if (!isDefined(level.botactor_wp_claim) || !isDefined(level.botactor_wp_claim[wpIdx]))
		return undefined;

	claim = level.botactor_wp_claim[wpIdx];
	if (!isDefined(claim.bot) || !isAlive(claim.bot) || gettime() >= claim.until)
	{
		level.botactor_wp_claim[wpIdx] = undefined;
		return undefined;
	}

	return claim.bot;
}

/*
///DocStringBegin
detail: <Player> bot_wp_claim(wpIdx: <Int>, ms: <Int>): <Bool>
summary: Reserves a traversal for ms. Fails if a live bot already holds it. Renewing your own claim always succeeds.
///DocStringEnd
*/
bot_wp_claim(wpIdx, ms)
{
	owner = bot_wp_claim_owner(wpIdx);
	if (isDefined(owner) && owner != self)
		return false;

	if (!isDefined(level.botactor_wp_claim))
		level.botactor_wp_claim = [];

	claim = level.botactor_wp_claim[wpIdx];
	if (!isDefined(claim))
		claim = spawnstruct();

	claim.bot = self;
	claim.until = gettime() + ms;
	level.botactor_wp_claim[wpIdx] = claim;
	return true;
}

/*
///DocStringBegin
detail: <Player> bot_wp_release(wpIdx: <Int>): <Void>
summary: Releases the claim if it is yours. Optional: the expiry releases it anyway.
///DocStringEnd
*/
bot_wp_release(wpIdx)
{
	owner = bot_wp_claim_owner(wpIdx);
	if (isDefined(owner) && owner == self)
		level.botactor_wp_claim[wpIdx] = undefined;
}

/*
///DocStringBegin
detail: <Player> bot_wp_mark_fail(wpIdx: <Int>, ttl_ms: <Int>): <Void>
summary: Marks the waypoint, and the edge from where the bot stands, as failed for ITS own A* only. This is what stops it retrying the same impossible traversal forever: without it the next repath plans straight back through it.
///DocStringEnd
*/
bot_wp_mark_fail(wpIdx, ttl_ms)
{
	if (!isDefined(wpIdx))
		return;

	self _botWPMemoryMarkFail(wpIdx, ttl_ms);

	fromWp = _botgetNearestWaypoint(self.origin, true);
	if (isDefined(fromWp) && fromWp != wpIdx)
		self _botEdgeMemoryMarkFail(fromWp, wpIdx, ttl_ms);
}

_botNavigationWaitPathBudget(maxWaitMs)
{
	if (!isDefined(maxWaitMs))
		maxWaitMs = 350;

	waited = 0;
	for (;;)
	{
		if (_botNavigationUsePathBudget(gettime()))
			return true;

		if (waited >= maxWaitMs)
			return false;

		wait 0.05;
		waited += 50;
	}
}

// Pursue a target until it stops being valid
_botChaseLoop(target)
{
	self notify("bot_chase");
	self endon("bot_chase");
	self endon("disconnect");
	self endon("death");
	self endon("bot_chase_end");

	// GOAP drives its own chase through this same loop (action_chase_target threads it), so it has to end when that action does.
	self endon("goap_action_end");

	if (!isDefined(self.actor)) return;

	if (isDefined(target))
	{
		target endon("disconnect");
		target endon("death");
	}

	self.actor[CHASE_TARGET] = target;
	self.actor[CHASE_NEXT_MOVE_TIME] = 0;
	self.actor[CHASE_LAST_GOAL] = undefined;
	self.actor[SCRIPT_MOVE] = true;

	preserveAvoid = isDefined(self.actor[CHASE_HANDOVER_ACTIVE]) && self.actor[CHASE_HANDOVER_ACTIVE];
	if (!preserveAvoid)
	{
		self.actor[NEGATIVE_MODE] = false;
		self bot_avoid_clear();
	}

	self bot_set_target(target);
	self notify("bot_move");

	if (!isDefined(self.bot)) return;

	for (;;)
	{
		if (!isDefined(self))
			return;
		if (!isPlayer(self))
			return;
		alive = isAlive(self);
		if (!isDefined(alive) || !alive)
			return;
		if (!isDefined(self.actor) || !isDefined(self.bot))
			return;

		target = self.actor[CHASE_TARGET];
		if (!isDefined(target) || !isDefined(target.origin))
			break;

		if (isPlayer(target) && (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand)))
		{
			self.actor[CHASE_TARGET] = undefined;
			break;
		}

		now = gettime();
		self.actor[HEARTBEAT_NAV] = now;

		isOmniscient = !isDefined(self bot_get_skill(SKILL_REMEMBER_TIME));
		locRememberMs = self bot_get_skill(SKILL_LOCATION_REMEMBER_TIME, 5.0) * 1000;
		distMin = self bot_get_skill(SKILL_CHASE_DIST_MIN, 192);
		distMax = self bot_get_skill(SKILL_CHASE_DIST_MAX, 700);
		allowMelee = self.actor[MELEE_CHARGE];

		// Where do we believe the target is?
		target_pos = undefined;
		if (isOmniscient || self lethalbeats\botactor\targeting::_botHasTargetSight(target))
			target_pos = target.origin;
		else
		{
			targetObj = self.bot.targets[target getEntityNumber()];
			if (isDefined(targetObj) && isDefined(targetObj.last_seen_pos) && targetObj.no_trace_time <= locRememberMs)
				target_pos = targetObj.last_seen_pos;
		}

		if (!isDefined(target_pos))
		{
			// Lost it and the memory expired: hold and let targeting re-acquire.
			self _botNavigationBrake();
			wait 0.4;
			continue;
		}

		distSq = distanceSquared(self.origin, target_pos);

		// Optional cover behaviour, unchanged.
		if (_botCoverNodesEnabled() && !isDefined(self.goap) && now >= self.actor[COVER_HOLDING_END_TIME])
		{
			self.actor[COVER_HOLDING_END_TIME] = now + 1500;
			snapPct = isDefined(self.actor[BEHAVIOR_COVER_SNAP]) ? self.actor[BEHAVIOR_COVER_SNAP] : 0;
			if (snapPct > 0 && randomint(100) < snapPct)
			{
				coverNode = self _findFreeCover(600, self.origin, target_pos);
				if (isDefined(coverNode))
				{
					self thread _botMoveAndHoldCover(coverNode, target);
					return;
				}
			}
		}

		// Melee chargers close all the way in; shooters stop at attack range.
		attackDist = distMin;
		if (allowMelee)
		{
			meleeDist = self bot_get_skill(SKILL_MELEE_DIST, 120);
			attackDist = meleeDist * 0.75;
		}
		if (attackDist < 16)
			attackDist = 16;

		// Melee execution while in reach.
		if (allowMelee && distSq <= self bot_get_melee_distance() && self lethalbeats\botactor\targeting::_botHasTargetSight(target))
		{
			self bot_release_sprint();
			self bot_press_melee();
		}

		// Already standing at a usable distance? Then hold and let combat work
		if (distSq <= attackDist * attackDist && self _botChaseStandoffClear(target_pos))
		{
			self _botNavigationBrake();

			lookDir = target_pos - self.origin;
			if (lengthsquared(lookDir) > 1)
				self lethalbeats\botactor\movement::bot_set_look_dir(lookDir);

			wait _botNavigationChaseTick();
			continue;
		}

		// Otherwise close the distance BY ROUTE, always
		self.actor[SCRIPT_MOVE] = true;
		self bot_go_to(target_pos, 32, 3, 8, false, true);

		if (!isDefined(self) || !isDefined(self.actor))
			return;

		self.actor[HEARTBEAT_NAV] = gettime();
		self.actor[CHASE_TARGET] = target;

		wait _botNavigationChaseTick();
	}
}

bot_go_to(goal, stop_dist, wp_timeout, goal_timeout, keep_patrol, keep_chase)
{
	_botactorEnsureWaypoints();
	if (!isDefined(self) || !isDefined(self.actor) || !isDefined(goal))
		return false;

	if (!isDefined(keep_patrol))
		keep_patrol = false;
	if (!isDefined(keep_chase))
		keep_chase = false;

	goalNode = undefined;
	if (isDefined(self.bot_goto_goal_node))
	{
		goalNode = self.bot_goto_goal_node;
		self.bot_goto_goal_node = undefined;
	}

	target = self.actor[CHASE_TARGET];
	if (isDefined(self.bot_goto_goal_target))
	{
		target = self.bot_goto_goal_target;
		self.bot_goto_goal_target = undefined;
	}
	if (isDefined(goalNode))
	{
		if (isDefined(target))
			self.bot_cover_target = target;
		else
			self.bot_cover_target = undefined;
	}

	if (!keep_patrol)
	{
		self notify("bot_patrol");
		self.actor[PATROL_ACTIVE] = false;
	}
	if (!keep_chase)
	{
		self notify("bot_chase");
		self notify("bot_charge");
		self.actor[CHASE_TARGET] = undefined;
		self.actor[CHASE_NEXT_MOVE_TIME] = 0;
		self.actor[CHASE_LAST_GOAL] = undefined;
	}

	self.actor[SCRIPT_MOVE] = true;
	self.actor[PATH_LOCK] = true;  // Prevent targeting loop from starting new chases
	self.actor[SPRINT_STATE] = false;
	self.actor[LOCK] = true;

	// Sprint is a property of the ROUTE, asked for with bot_set_route_sprint
	if (isDefined(self.actor[ROUTE_SPRINT]) && self.actor[ROUTE_SPRINT])
	{
		self.actor[HOLD_SPRINT] = true;
		self bot_press_sprint();
	}
	else
		self.actor[HOLD_SPRINT] = false;

	self notify("bot_move");

	// Whether the bot keeps AIMING while it walks this route is an engagement
	prevMoveLookMode = self.actor[MOVE_LOOK_MODE];
	if (!self lethalbeats\botactor\behavior::bot_engagement_allows_targets())
		self.actor[MOVE_LOOK_MODE] = 0;
	else
		self.actor[MOVE_LOOK_MODE] = 1;

	// bot_go_to is self-cancelling
	if (self lethalbeats\botactor\utility::bot_is_reacting())
	{
		if (isDefined(self.botactor_route_tag))
			self.botactor_route_tag = undefined;
		else if (self lethalbeats\botactor\utility::_botGrenadeDebug())
			print("BT_NADE STOMP bot=" + self.name + " task=" + (isDefined(self.ba) && isDefined(self.ba.task) ? self.ba.task.kind : "none") + " goap=" + (isDefined(self.goap) ? "attached" : "no") + " - a route was started during the reaction and cancelled it");
	}

	self notify("bot_go_to");
	self endon("bot_go_to");
	self endon("disconnect");
	self endon("death");

	// No endon("goap_action_end") here on purpose

	// Stagger only when NOT in keep_chase mode; chase handover must start
	if (!keep_chase)
	{
		stagger = float(self getentitynumber()) * 0.1;
		if (stagger > 0.3)
			stagger = 0.3;

		staggered = 0.0;
		while (staggered < stagger)
		{
			wait 0.05;
			staggered += 0.05;

			if (isDefined(self.ba))
				self.ba.runner_beat = gettime();
			if (isDefined(self.actor))
				self.actor[HEARTBEAT_NAV] = gettime();
		}
	}

	if (!isdefined(goal))
	{
		self.actor[SCRIPT_MOVE] = false;
		self.actor[SPRINT_STATE] = false;
		self.actor[HOLD_SPRINT] = false;
		self.actor[LOCK] = true;
		return false;
	}

	if (!isdefined(stop_dist))
		stop_dist = 32;

	// A bot cannot reliably settle inside ~12 units of a point
	if (stop_dist < 12)
		stop_dist = 12;

	if (!isdefined(wp_timeout))
		wp_timeout = 3.0;

	if (!isdefined(goal_timeout))
		goal_timeout = 8.0;

	ok = false;
	processed = false;
	sub_ok = false;
	self.bot_chase_repath_requested = false;
	self.bot_goto_stale = false;

	if (isdefined(level.waypoints) && level.waypoints.size > 0)
	{
		team = undefined;
		if (isdefined(level.teambased) && level.teambased)
			team = self.team;

		// 1. Direct Move if goal is already in LOS and navigable (avoids clipping corners)
		eyeOffset = (0, 0, 15);
		if (bullettracepassed(self.origin + eyeOffset, goal + eyeOffset, false, self) && self _botPathIsNavigable(self.origin, goal))
		{
			ok = self _botGoToPointSimple(goal, stop_dist, goal_timeout, true, goalNode, undefined, keep_chase, target, goal);
			if (self _botGoToHasChaseRefreshRequest())
				return self _botGoToResumeChase(target, prevMoveLookMode);
			if (ok)
				processed = true;
		}

		// 2. Prioritize bridging
		if (!processed)
		{
			bridgeIdx = self _botGoToFindBridgeWaypoint(goal);
			bridgeWp = _botGetWaypoint(bridgeIdx);
			if (isdefined(bridgeWp) && self _botPathIsNavigable(self.origin, bridgeWp.origin) && self _botPathIsNavigable(bridgeWp.origin, goal))
			{
				bridgePath = undefined;
				if (self _botNavigationWaitPathBudget(300))
					bridgePath = bot_astar_search(self.origin, bridgeWp.origin, team, false);
				sub_ok = true;
				if (isdefined(bridgePath) && bridgePath.size > 0)
				{
					self.botactor_active_path = bridgePath;
					self.botactor_active_path_team = team;
					for (i = bridgePath.size - 1; i >= 0; i--)
					{
						wp_idx = bridgePath[i];
						wp = _botGetWaypoint(wp_idx);
						if (!isdefined(wp)) continue;

						if (isDefined(keep_chase) && keep_chase)
						{
							target = self.actor[CHASE_TARGET];
							allowRefresh = true;
							if (isDefined(self.actor[NEGATIVE_MODE]) && self.actor[NEGATIVE_MODE] && !self _botChaseTargetMovedFromGoal(goal, target))
								allowRefresh = false;

							if (allowRefresh && self _botGoToShouldResumeDynamicChase(goal, target))
								return self _botGoToResumeChase(target, prevMoveLookMode);
						}

						bool_corner = false;
						dir_to_next = undefined;
						if (isDefined(self.actor[130]) && self.actor[130] && i > 0)
						{
							next_pos = _botGetWaypointOrigin(bridgePath[i-1]);
							if (isDefined(next_pos))
							{
								dir_to_next = (next_pos[0] - self.origin[0], next_pos[1] - self.origin[1], 0);
								if (lengthsquared(dir_to_next) > 1)
								{
									target_yaw = vectortoyaw(dir_to_next);
									yaw_delta = angleClamp180(target_yaw - self.angles[1]);
									if (abs(yaw_delta) > 45) bool_corner = true;
								}
							}
						}

						nodeTimeout = wp_timeout;
						if (self _botIsTraversalNode(wp) || (isDefined(wp.type) && wp.type == "climb"))
							nodeTimeout = _botNavigationTraversalTimeout(wp_timeout);

						if (!self _botGoToPointSimple(wp.origin, 36, nodeTimeout, bool_corner, wp, wp_idx, keep_chase, target, goal))
						{
							if (self _botGoToHasChaseRefreshRequest())
								return self _botGoToResumeChase(target, prevMoveLookMode);
							sub_ok = false;
							break;
						}

						if (bool_corner)
							self lethalbeats\botactor\movement::bot_look_at_angles(vectortoangles(dir_to_next), 400);
					}
				}
				else
				{
					bool_corner = false;
					dir_to_next = undefined;
					if (isDefined(self.actor[130]) && self.actor[130])
					{
						dir_to_next = (goal[0] - self.origin[0], goal[1] - self.origin[1], 0);
						if (lengthsquared(dir_to_next) > 1)
						{
							target_yaw = vectortoyaw(dir_to_next);
							yaw_delta = angleClamp180(target_yaw - self.angles[1]);
							if (abs(yaw_delta) > 45) bool_corner = true;
						}
					}

					nodeTimeout = wp_timeout;
					if (self _botIsTraversalNode(bridgeWp) || (isDefined(bridgeWp.type) && bridgeWp.type == "climb"))
						nodeTimeout = _botNavigationTraversalTimeout(wp_timeout);

					sub_ok = self _botGoToPointSimple(bridgeWp.origin, 36, nodeTimeout, bool_corner, bridgeWp, bridgeIdx, keep_chase, target, goal);
					if (self _botGoToHasChaseRefreshRequest())
						return self _botGoToResumeChase(target, prevMoveLookMode);

					if (isDefined(sub_ok) && sub_ok && bool_corner)
						self lethalbeats\botactor\movement::bot_look_at_angles(vectortoangles(dir_to_next), 400);
				}

				if (isDefined(sub_ok) && sub_ok)
				{
					ok = self _botGoToPointSimple(goal, stop_dist, goal_timeout, true, goalNode, undefined, keep_chase, target, goal);
					if (self _botGoToHasChaseRefreshRequest())
						return self _botGoToResumeChase(target, prevMoveLookMode);
					processed = true;
				}
			}
		}

		// 3. Fallback: Standard A* Search
		if (!processed)
		{
			path = undefined;
			if (!self _botNavigationWaitPathBudget(500))
			{
				processed = true;
			}
			else
			{
				path = bot_astar_search(self.origin, goal, team, false);
				if (isdefined(path) && path.size > 0)
				{
					sub_ok = true;
					self.botactor_active_path = path;
					self.botactor_active_path_team = team;
					for (i = path.size - 1; i >= 0; i--)
					{
						wp_idx = path[i];
						wp = _botGetWaypoint(wp_idx);
						if (!isdefined(wp)) continue;

						if (isDefined(keep_chase) && keep_chase)
						{
							target = self.actor[CHASE_TARGET];
							allowRefresh = true;
							if (isDefined(self.actor[NEGATIVE_MODE]) && self.actor[NEGATIVE_MODE] && !self _botChaseTargetMovedFromGoal(goal, target))
								allowRefresh = false;

							if (allowRefresh && self _botGoToShouldResumeDynamicChase(goal, target))
								return self _botGoToResumeChase(target, prevMoveLookMode);
						}

						bool_corner = false;
						dir_to_next = undefined;
						if (isDefined(self.actor[130]) && self.actor[130] && i > 0)
						{
							next_pos = _botGetWaypointOrigin(path[i-1]);
							if (isDefined(next_pos))
							{
								dir_to_next = (next_pos[0] - self.origin[0], next_pos[1] - self.origin[1], 0);
								if (lengthsquared(dir_to_next) > 1)
								{
									target_yaw = vectortoyaw(dir_to_next);
									yaw_delta = angleClamp180(target_yaw - self.angles[1]);
									if (abs(yaw_delta) > 45) bool_corner = true;
								}
							}
						}

						nodeTimeout = wp_timeout;
						if (self _botIsTraversalNode(wp) || (isDefined(wp.type) && wp.type == "climb"))
							nodeTimeout = _botNavigationTraversalTimeout(wp_timeout);

						if (!self _botGoToPointSimple(wp.origin, 36, nodeTimeout, bool_corner, wp, wp_idx, keep_chase, target, goal))
						{
							if (self _botGoToHasChaseRefreshRequest())
								return self _botGoToResumeChase(target, prevMoveLookMode);
							sub_ok = false;
							break;
						}

						if (bool_corner)
							self lethalbeats\botactor\movement::bot_look_at_angles(vectortoangles(dir_to_next), 400);
					}
					if (isDefined(sub_ok) && sub_ok)
					{
						ok = self _botGoToPointSimple(goal, stop_dist, goal_timeout, true, goalNode, undefined, keep_chase, target, goal);
						if (self _botGoToHasChaseRefreshRequest())
							return self _botGoToResumeChase(target, prevMoveLookMode);
						processed = true;
					}
					else if (isDefined(sub_ok) && !sub_ok)
					{
						// Path failed mid-transit (e.g. climb failed after 3 attempts and edge marked blocked)
						// Repath immediately to find an alternate route avoiding the blocked obstacle
						if (self _botNavigationWaitPathBudget(350))
						{
							altPath = bot_astar_search(self.origin, goal, team, false);
							if (isDefined(altPath) && altPath.size > 0)
							{
								self.botactor_active_path = altPath;
								self.botactor_active_path_team = team;
								alt_ok = true;
								for (j = altPath.size - 1; j >= 0; j--)
								{
									alt_wp_idx = altPath[j];
									alt_wp = _botGetWaypoint(alt_wp_idx);
									if (!isdefined(alt_wp)) continue;

									altNodeTimeout = wp_timeout;
									if (self _botIsTraversalNode(alt_wp) || (isDefined(alt_wp.type) && alt_wp.type == "climb"))
										altNodeTimeout = _botNavigationTraversalTimeout(wp_timeout);

									if (!self _botGoToPointSimple(alt_wp.origin, 36, altNodeTimeout, false, alt_wp, alt_wp_idx, keep_chase, target, goal))
									{
										alt_ok = false;
										break;
									}
								}
								if (alt_ok)
								{
									ok = self _botGoToPointSimple(goal, stop_dist, goal_timeout, true, goalNode, undefined, keep_chase, target, goal);
									if (self _botGoToHasChaseRefreshRequest())
										return self _botGoToResumeChase(target, prevMoveLookMode);
									processed = true;
								}
							}
						}
					}
				}
			}
		}
	}

	// Final leg if map has no waypoints, or if waypoint path succeeded and was not yet processed
	if (!processed && (!isDefined(level.waypoints) || !level.waypoints.size || sub_ok))
	{
		ok = self _botGoToPointSimple(goal, stop_dist, goal_timeout, true, goalNode, undefined, keep_chase, target, goal);
		if (self _botGoToHasChaseRefreshRequest())
			return self _botGoToResumeChase(target, prevMoveLookMode);
	}

	self.bot.moveto = undefined;
	self.actor[SCRIPT_MOVE] = false;
	self.actor[PATH_LOCK] = false;
	self.actor[LOCK] = false;
	if (isDefined(self.ba))
		self.ba.move_stop_dist = 16;
	if (!isDefined(keep_chase) || !keep_chase || ok)
	{
		self.actor[NEGATIVE_MODE] = false; // Clear fence-stuck reroute flag so bot returns to normal chase behavior
		self.actor[CHASE_HANDOVER_ACTIVE] = false;
	}
	else
	{
		self.actor[NEGATIVE_MODE] = true;
		self.actor[CHASE_HANDOVER_ACTIVE] = true;
	}
	if (isDefined(prevMoveLookMode)) self.actor[MOVE_LOOK_MODE] = prevMoveLookMode;
	self.botactor_active_path = undefined;
	self.botactor_active_path_team = undefined;

	if (!isDefined(keep_chase) || !keep_chase)
		self.actor[CHASE_HANDOVER_ACTIVE] = false;

	// bot_go_to never restarts the chase itself any more
	return ok;
}

/*
///DocStringBegin
detail: bot_astar_search(start: <Vector>, goal: <Vector>, team: <String>, greedy_path: <Bool>): <Array>
summary: Local A* path search over level.waypoints, independent from iw5_bot_warfare.
///DocStringEnd
*/
bot_astar_search(start, goal, team, greedy_path)
{
	if (!isDefined(self) || !isDefined(self.actor))
		return [];

	if (!isDefined(start) || !isDefined(goal))
		return [];

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return [];

	if (!isDefined(greedy_path))
		greedy_path = false;

	open = [];
	openset = [];
	closed = [];

	startWp = _botgetNearestWaypoint(start);
	if (!isDefined(startWp))
		return [];

	startWpOrg = _botGetWaypointOrigin(startWp);
	if (!isDefined(startWpOrg))
		return [];

	_startwp = undefined;
	if (!bullettracepassed(start + (0, 0, 15), startWpOrg + (0, 0, 15), false, undefined))
		_startwp = _botgetNearestWaypointWithSight(start);

	if (isDefined(_startwp))
	{
		startWp = _startwp;
		startWpOrg = _botGetWaypointOrigin(startWp);
		if (!isDefined(startWpOrg))
			return [];
	}

	goalWp = _botgetNearestWaypoint(goal, true);
	if (!isDefined(goalWp))
		return [];

	goalWpOrg = _botGetWaypointOrigin(goalWp);
	if (!isDefined(goalWpOrg))
		return [];

	_goalwp = undefined;
	if (!bullettracepassed(goal + (0, 0, 15), goalWpOrg + (0, 0, 15), false, undefined))
		_goalwp = _botgetNearestWaypointWithSight(goal, true);

	if (isDefined(_goalwp))
	{
		goalWp = _goalwp;
		goalWpOrg = _botGetWaypointOrigin(goalWp);
		if (!isDefined(goalWpOrg))
			return [];
	}

	node = spawnstruct();
	node.g = 0;
	node.h = distancesquared(startWpOrg, goalWpOrg);
	if (!isDefined(node.h))
		return [];

	node.f = node.h + node.g;
	node.index = startWp;
	node.parent = undefined;

	openset[node.index + ""] = node;
	open[open.size] = node;

	expanded = 0;
	yieldEvery = 64;
	if (greedy_path)
		yieldEvery = 96;

	maxExpanded = level.waypoints.size * 3;
	if (maxExpanded < 128)
		maxExpanded = 128;

	while (open.size)
	{
		bestOpen = undefined;
		bestF = undefined;
		for (openIdx = 0; openIdx < open.size; openIdx++)
		{
			openNode = open[openIdx];
			if (!isDefined(openNode) || !isDefined(openNode.f) || !isDefined(openNode.index))
				continue;

			if (!isDefined(bestOpen))
			{
				bestOpen = openIdx;
				bestF = openNode.f;
			}
			else if (openNode.f < bestF)
			{
				bestOpen = openIdx;
				bestF = openNode.f;
			}
		}

		if (!isDefined(bestOpen))
			return [];

		bestNode = open[bestOpen];
		lastOpen = open.size - 1;
		open[bestOpen] = open[lastOpen];
		open[lastOpen] = undefined;

		bestNodeStr = bestNode.index + "";
		openset[bestNodeStr] = undefined;

		wp = _botGetWaypoint(bestNode.index);
		if (!isDefined(wp) || !isDefined(wp.origin) || !isDefined(bestNode.g))
			continue;

		if (bestNode.index == goalWp)
		{
			path = [];

			while (isDefined(bestNode))
			{
				bestNodeStr = bestNode.index + "";
				path[path.size] = bestNode.index;
				bestNode = bestNode.parent;
			}

			return path;
		}

		expanded++;
		if (expanded > maxExpanded)
			return [];
		if ((expanded % yieldEvery) == 0)
			wait 0.05;

		if (!isDefined(wp.children) || !wp.children.size)
		{
			closed[bestNodeStr] = bestNode;
			continue;
		}

		for (i = wp.children.size - 1; i >= 0; i--)
		{
			child = wp.children[i];
			childStr = child + "";
			childWp = _botGetWaypoint(child);
			if (!isDefined(childWp) || !isDefined(childWp.origin))
				continue;

			if (self _botEdgeMemoryIsBlocked(bestNode.index, child))
				continue;

			if (self _botAvoidContains(childWp.origin))
				continue;

			if (!self _botWaypointEdgeValid(bestNode.index, child, wp, childWp))
				continue;

			penalty = 1;

			if (isDefined(childWp.type))
			{
				disabledNode = self bot_is_node_type_disabled(childWp.type);
				if (isDefined(disabledNode) && disabledNode)
					continue;

				if (childWp.type == "climb" || childWp.type == "prone")
					penalty += 4;

				// Penalize claimed traversals so A* prefers alternate open paths
				if (bot_wp_is_traversal(childWp))
				{
					claimOwner = bot_wp_claim_owner(child);
					if (isDefined(claimOwner) && claimOwner != self)
						penalty += WP_CLAIM_PENALTY;
				}
			}

			stepDistSq = distancesquared(wp.origin, childWp.origin);
			if (!isDefined(stepDistSq))
				continue;

			edgeCost = stepDistSq * penalty;
			newg = bestNode.g + edgeCost;

			inopen = isDefined(openset[childStr]);
			if (inopen)
			{
				if (isDefined(openset[childStr].g) && openset[childStr].g <= newg)
					continue;
			}

			inclosed = isDefined(closed[childStr]);
			if (inclosed)
			{
				if (isDefined(closed[childStr].g) && closed[childStr].g <= newg)
					continue;
			}

			node = undefined;
			if (inopen)
				node = openset[childStr];
			else if (inclosed)
				node = closed[childStr];
			else
				node = spawnstruct();

			node.parent = bestNode;
			node.g = newg;
			node.h = distancesquared(childWp.origin, goalWpOrg);
			if (!isDefined(node.h))
				continue;

			node.f = node.g + node.h;
			node.index = child;

			if (inclosed)
				closed[childStr] = undefined;

			if (!inopen)
			{
				open[open.size] = node;
				openset[childStr] = node;
			}
		}

		closed[bestNodeStr] = bestNode;
	}

	return [];
}

bot_avoid_clear()
{
	self.actor[AVOID_ZONES] = [];
	self _botWPMemoryClear();
	self.botactor_bad_edges = [];
	self.actor[NEGATIVE_MODE] = false;
}

_botNavigationBrake()
{
	if (isDefined(self.bot))
	{
		self.bot.stop_move = true;
		self.bot.moveto = undefined;
	}
	self.actor[SPRINT_STATE] = false;
	self.actor[HOLD_SPRINT] = false;
}

// Am I standing at a real firing position relative to pos, or just close to it
_botChaseStandoffClear(pos)
{
	if (!isDefined(pos))
		return false;

	if (!bullettracepassed(self.origin + (0, 0, 18), pos + (0, 0, 18), false, self))
		return false;

	return bullettracepassed(self.origin + (0, 0, 45), pos + (0, 0, 45), false, self);
}

_botChaseTargetMovedFromGoal(goal, target)
{
	if (!isDefined(goal) || !isDefined(target) || !isDefined(target.origin))
		return false;

	repathDist = _botNavigationChaseRepathDist();
	return distanceSquared(goal, target.origin) > repathDist * repathDist;
}

_botGoToHasChaseRefreshRequest()
{
	return isDefined(self.bot_chase_repath_requested) && self.bot_chase_repath_requested;
}

_botGoToShouldResumeDynamicChase(goal, target)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return false;

	if (self lethalbeats\botactor\targeting::_botHasTargetSight(target))
		return true;

	return self _botChaseTargetMovedFromGoal(goal, target);
}

// The current path went stale
_botGoToResumeChase(target, prevMoveLookMode)
{
	self.bot_chase_repath_requested = false;
	self.bot_goto_stale = true;

	self.botactor_active_path = undefined;
	self.botactor_active_path_team = undefined;

	if (isDefined(prevMoveLookMode))
		self.actor[MOVE_LOOK_MODE] = prevMoveLookMode;

	if (isDefined(self.actor))
	{
		self.actor[PATH_LOCK] = false;
		self.actor[LOCK] = false;
		self.actor[CHASE_HANDOVER_ACTIVE] = false;
		self.actor[NEGATIVE_MODE] = false;
		self.actor[NEXT_PATH_DIST_UPDATE] = 0;
		self.actor[SCRIPT_MOVE] = false;
	}

	if (isDefined(self.bot))
		self.bot.stop_move = false;

	if (isDefined(self.ba))
		self.ba.move_stop_dist = 16;

	return false;
}

_botEscapeBlockedMove(blockedPoint)
{
	if (_botNavigationOpt("escape_backstep") == 0)
		return;

	if (!isDefined(blockedPoint) || !isDefined(self.bot))
		return;

	dir = (self.origin[0] - blockedPoint[0], self.origin[1] - blockedPoint[1], 0);
	lenSq = lengthSquared(dir);
	if (!isDefined(lenSq) || lenSq <= 1)
	{
		forward = anglesToForward(self.angles);
		dir = (0 - forward[0], 0 - forward[1], 0);
		lenSq = lengthSquared(dir);
	}

	if (!isDefined(lenSq) || lenSq <= 1)
		return;

	len = sqrt(lenSq);
	dir = (dir[0] / len, dir[1] / len, 0);
	right = anglesToRight(self.angles);
	side = 1;
	if (randomInt(2) == 0)
		side = -1;

	escape = self.origin + (dir * 96) + (right * (side * 48));
	start = self.origin + (0, 0, 18);
	end = escape + (0, 0, 18);
	if (!bullettracepassed(start, end, false, self))
		escape = self.origin + (dir * 96);

	if (!bullettracepassed(start, escape + (0, 0, 18), false, self))
		return;

	self.bot.moveto = escape;
	self.bot.stop_move = false;
	self bot_release_sprint();
	wait 0.22;
}

_botMarkBlockedMove(point, wpIdx)
{
	ttl = _botNavigationEdgeFailTtl();

	if (isDefined(self.actor))
	{
		self.actor[NEGATIVE_MODE] = true;
		self.actor[CHASE_HANDOVER_ACTIVE] = true;
	}

	self _botAvoidMark(self.origin, 176, ttl);

	if (isDefined(wpIdx))
	{
		self _botWPMemoryMarkFail(wpIdx, ttl);
		fromWp = _botgetNearestWaypoint(self.origin, true);
		if (isDefined(fromWp) && fromWp != wpIdx)
			self _botEdgeMemoryMarkFail(fromWp, wpIdx, ttl);
	}

	self _botEscapeBlockedMove(point);
}

bot_get_node_forward_yaw(node)
{
	if (!isDefined(node) || !isDefined(node.angles))
		return self.angles[1];

	// node.type has to be checked before it is compared: an undefined vs string comparison is a runtime error in GSC, not a false.
	if (!isDefined(node.type))
		return node.angles[1];

	if (node.type == "cover_left") return node.angles[1] + 90;
	else if (node.type == "cover_right") return node.angles[1] - 90;
	else return node.angles[1];
}

bot_get_forward_pos(dist, useNode)
{
	if (!isDefined(useNode)) useNode = false;
	if (useNode && isDefined(self.node)) forward = anglesToForward(self.node.angles);
	else forward = anglesToForward(self.angles);
	return self.origin + (forward * dist);
}

bot_get_yaw_to_target(target, useNode)
{
	if (!isDefined(target)) target = self bot_get_current_target();
	if (isDefined(target)) return self bot_get_yaw_to_pos(target.origin);
	return self bot_get_yaw_to_pos(self bot_get_forward_pos(150, useNode));
}

bot_abs_yaw_to_angles(angles)
{
	yaw = self.angles[1] - angles;
	yaw = angleClamp180(yaw);
	if (yaw < 0) yaw = -1 * yaw;
	return yaw;
}

bot_abs_yaw_to_pos(org)
{
	return self bot_abs_yaw_to_angles(self bot_get_yaw(org));
}

bot_abs_yaw_to_pos_2d(org)
{
	return self bot_abs_yaw_to_angles(self bot_get_yaw_2d(org));
}

bot_abs_yaw_to_target(target)
{
	if (!isDefined(target)) target = self bot_get_current_target();
	if (!isDefined(target)) return undefined;
	return self bot_abs_yaw_to_pos(target.origin);
}

bot_abs_yaw_to_target_2d(target)
{
	if (!isDefined(target)) target = self bot_get_current_target();
	if (!isDefined(target)) return undefined;
	return self bot_abs_yaw_to_pos_2d(target.origin);
}

bot_get_yaw(org, start)
{
	if (!isDefined(start)) start = self.origin;
	return vectorToYaw(org - start);
}

bot_get_yaw_2d(org, start)
{
	if (!isDefined(start)) start = self.origin;
	dir = (org[0], org[1], 0) - (start[0], start[1], 0);
	return vectorToYaw(dir);
}

bot_get_yaw_to_tag(tag, org)
{
	yaw = self getTagAngles(tag)[1] - self bot_get_yaw(org, self getTagOrigin(tag));
	return angleClamp180(yaw);
}

bot_get_yaw_to_pos(org, useNode)
{
	if (!isDefined(useNode)) useNode = false;

	yaw = self.angles[1];
	if (useNode && isDefined(self.node)) yaw = self.node.angles[1];
	yaw = yaw - self bot_get_yaw(org);
	return angleClamp180(yaw);
}

bot_get_node_type()
{
	return isDefined(self.node) ? self.node.type : "none";
}

bot_get_dir(useNode)
{
	if (!isDefined(useNode)) useNode = false;
	if (useNode && isDefined(self.node)) return self.node.angles[1];
	return self.angles[1];
}

bot_get_forward(useNode)
{
	if (!isDefined(useNode)) useNode = false;
	if (useNode && isDefined(self.node)) return anglesToForward(self.node.angles);
	return anglesToForward(self.angles);
}

bot_get_origin(useNode)
{
	if (!isDefined(useNode)) useNode = false;
	if (useNode && isDefined(self.node)) return anglesToForward(self.node.origin);
	return self.origin;
}

bot_get_quadrant(angle)
{
	angle = angleClamp(angle);
	if (angle < 45 || angle > 315) return "front";
	else if (angle < 135) return "left";
	else if (angle < 225) return "back";
	else return "right";
}

bot_get_quadrant_anim_weights(yaw)
{
	yaw = angleClamp(yaw);
	forward = cos(yaw);
	side = sin(yaw);

	result["front"] = 0;
	result["back"] = 0;
	result["left"] = 0;
	result["right"] = 0;

	if (forward > 0) result["front"] = forward;
	else result["back"] = -forward;

	if (side > 0) result["left"] = side;
	else result["right"] = -side;

	total = result["front"] + result["back"] + result["left"] + result["right"];

	if (total > 0)
	{
		result["front"] /= total;
		result["back"] /= total;
		result["left"] /= total;
		result["right"] /= total;
	}

	return result;
}

// Check if the sight line from `from` to `to` has a reasonable pitch angle
_botSightAngleOk(from, to)
{
	if (!isDefined(from) || !isDefined(to))
		return false;

	dx = to[0] - from[0];
	dy = to[1] - from[1];
	dz = to[2] - from[2];
	horizDistSq = dx * dx + dy * dy;

	if (horizDistSq < 1)
		return true; // very close, no meaningful angle

	horizDist = sqrt(horizDistSq);
	dzAbs = dz;
	if (dzAbs < 0)
		dzAbs = 0 - dzAbs;

	// sin(pitch) = dz / horizDist  (approximation for small angles)
	if (dzAbs > SIGHT_MAX_PITCH * horizDist)
		return false;

	return true;
}

// Detects if there's likely a non-traversable barrier (fence/railing) between
_botDetectHeightBarrier(target_pos)
{
	if (!isDefined(target_pos) || !isDefined(level.waypoints) || !level.waypoints.size)
		return false;

	// Find waypoints near the target
	nearTargetWp = _botgetNearestWaypoint(target_pos);
	if (!isDefined(nearTargetWp))
		return false;
	targetWpOrg = _botGetWaypointOrigin(nearTargetWp);
	if (!isDefined(targetWpOrg))
		return false;
	targetWpZ = targetWpOrg[2];

	// Find waypoints near the bot
	nearSelfWp = _botgetNearestWaypoint(self.origin);
	if (!isDefined(nearSelfWp))
		return false;
	selfWpOrg = _botGetWaypointOrigin(nearSelfWp);
	if (!isDefined(selfWpOrg))
		return false;
	selfWpZ = selfWpOrg[2];

	// Height difference between closest waypoints
	zDiff = selfWpZ - targetWpZ;
	if (zDiff < 0)
		zDiff = 0 - zDiff;

	// 2D flat distance
	flatDistSq = distanceSquared(
		(self.origin[0], self.origin[1], 0),
		(target_pos[0], target_pos[1], 0)
	);

	// Close horizontally but different height = likely a barrier (fence on elevated ground, etc.)
	if (flatDistSq < 400 * 400 && zDiff > 48)
		return true;

	// High path-to-Euclidean distance ratio indicates a barrier
	if (flatDistSq < 300 * 300 && flatDistSq > 64 * 64)
	{
		// Quick bullet trace at ground level to check for physical obstruction
		groundTrace = bulletTrace(self.origin + (0, 0, 24), target_pos + (0, 0, 24), false, self);
		if (isDefined(groundTrace) && isDefined(groundTrace["fraction"]) && groundTrace["fraction"] < 0.85)
			return true;
	}

	return false;
}

// Will linearly search for the nearest waypoint to pos that has a direct line of sight
_botgetNearestWaypointWithSight(pos, useZWeight)
{
	_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	if (!isDefined(useZWeight))
		useZWeight = false;

	candidate = undefined;
	dist = 2147483647;

	for (i = level.waypoints.size - 1; i >= 0; i--)
	{
		if (!isDefined(level.waypoints[i]) || !isDefined(level.waypoints[i].origin))
			continue;

		wpOrigin = level.waypoints[i].origin;
		if (!bullettracepassed(pos + (0, 0, 15), wpOrigin + (0, 0, 15), false, undefined))
			continue;

		if (!_botSightAngleOk(pos + (0, 0, 15), wpOrigin))
			continue;

		curdis = distancesquared(wpOrigin, pos);
		if (useZWeight)
		{
			zDiff = abs(wpOrigin[2] - pos[2]);
			curdis += (zDiff * zDiff * 4.0);
		}

		if (curdis > dist)
			continue;

		dist = curdis;
		candidate = i;
	}

	return candidate;
}

// Will linearly search for the nearest waypoint
_botgetNearestWaypoint(pos, useZWeight)
{
	_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	if (!isDefined(useZWeight))
		useZWeight = false;

	candidate = undefined;
	dist = 2147483647;

	for (i = level.waypoints.size - 1; i >= 0; i--)
	{
		if (!isDefined(level.waypoints[i]) || !isDefined(level.waypoints[i].origin))
			continue;

		curdis = distancesquared(level.waypoints[i].origin, pos);

		// Z-weighting penalizes waypoints at differing heights to prevent picking ledges
		if (useZWeight)
		{
			zDelta = level.waypoints[i].origin[2] - pos[2];
			if (zDelta < 0) zDelta = 0 - zDelta;
			if (zDelta > 40)
				curdis += zDelta * zDelta * 6;
		}

		if (curdis > dist)
			continue;

		dist = curdis;
		candidate = i;
	}

	return candidate;
}

/*
///DocStringBegin
detail: bot_get_waypoint_hops(fromPos: <Vector3>, toPos: <Vector3>, maxHops: <Int>): <Int>
summary: Returns shortest graph hop distance between two positions. Returns 0 if same node, -1 if unreachable/no waypoints, or maxHops + 1 if exceeding maxHops.
///DocStringEnd
*/
bot_get_waypoint_hops(fromPos, toPos, maxHops)
{
	_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size) return -1;
	if (!isDefined(fromPos) || !isDefined(toPos)) return -1;
	if (!isDefined(maxHops)) maxHops = 14;

	startWp = _botgetNearestWaypoint(fromPos, true);
	goalWp = _botgetNearestWaypoint(toPos, true);

	if (!isDefined(startWp) || !isDefined(goalWp)) return -1;
	if (startWp == goalWp) return 0;

	visited = [];
	visited[startWp + ""] = true;

	queue = [];
	depths = [];
	queue[0] = startWp;
	depths[0] = 0;

	head = 0;
	while (head < queue.size)
	{
		currWp = queue[head];
		currDepth = depths[head];
		head++;

		if (currDepth >= maxHops) return maxHops + 1;

		wp = level.waypoints[currWp];
		if (!isDefined(wp) || !isDefined(wp.children)) continue;

		for (i = 0; i < wp.children.size; i++)
		{
			child = wp.children[i];
			if (!isDefined(child)) continue;
			if (child == goalWp) return currDepth + 1;

			childKey = child + "";
			if (isDefined(visited[childKey])) continue;

			visited[childKey] = true;
			nextIdx = queue.size;
			queue[nextIdx] = child;
			depths[nextIdx] = currDepth + 1;
		}
	}

	return -1;
}

/*
///DocStringBegin
detail: bot_should_catchup(target: <Entity|Vector3>, isUrgent?: <Bool>): <Bool>
summary: Returns true if the bot is topologically separated from target by a long detour, walls, or excessive distance.
///DocStringEnd
*/
bot_should_catchup(target, isUrgent)
{
	if (!isDefined(target)) return false;
	targetPos = isDefined(target.origin) ? target.origin : target;

	hops = bot_get_waypoint_hops(self.origin, targetPos, 14);
	hasSight = bullettracepassed(self.origin + (0, 0, 55), targetPos + (0, 0, 55), false, self);
	distSq = distanceSquared(self.origin, targetPos);

	if (!isDefined(isUrgent)) isUrgent = false;

	if (hops >= 0)
		return (hops >= 8 || (hops >= 5 && !hasSight) || (isUrgent && hops >= 3) || distSq > 1300 * 1300);

	return ((isUrgent && distSq > 600 * 600) || distSq > 1100 * 1100 || (distSq > 850 * 850 && !hasSight));
}

// Returns a new heap
_botNewHeap()
{
	heap_node = spawnstruct();
	heap_node.data = [];
	return heap_node;
}

// Inserts the item into the heap
_botHeapInsert(item)
{
	if (!isDefined(self) || !isDefined(self.data))
		return;

	if (!isDefined(item) || !isDefined(item.f))
		return;

	insert = self.data.size;
	self.data[insert] = item;
	current = insert + 1;

	while (current > 1)
	{
		last = current;
		current = int(current / 2);

		if (!isDefined(self.data[current - 1]) || !isDefined(self.data[current - 1].f))
			break;

		if (item.f >= self.data[current - 1].f)
			break;

		self.data[last - 1] = self.data[current - 1];
		self.data[current - 1] = item;
	}
}

// Helper function to determine what is the next child of the bst
_HeapNextChild(node, hsize)
{
	if (!isDefined(self) || !isDefined(self.data))
		return -1;

	if (!isDefined(node) || !isDefined(hsize))
		return -1;

	left = node * 2;
	right = left + 1;

	if (left > hsize)
		return -1;

	if (right > hsize)
		return left;

	if (!isDefined(self.data[left - 1]) || !isDefined(self.data[left - 1].f))
		return right;

	if (!isDefined(self.data[right - 1]) || !isDefined(self.data[right - 1].f))
		return left;

	if (self.data[left - 1].f < self.data[right - 1].f)
		return left;

	return right;
}

// Removes an item from the heap
_botHeapRemove()
{
	if (!isDefined(self) || !isDefined(self.data))
		return 0;

	remove = self.data.size;
	if (!remove)
		return remove;

	while (remove > 0 && (!isDefined(self.data[remove - 1]) || !isDefined(self.data[remove - 1].f)))
	{
		self.data[remove - 1] = undefined;
		remove--;
	}

	if (!remove)
		return remove;

	move = self.data[remove - 1];
	self.data[0] = move;
	self.data[remove - 1] = undefined;
	remove--;

	if (!remove)
		return remove;

	last = 1;
	next = self _HeapNextChild(1, remove);

	while (next != -1)
	{
		if (!isDefined(self.data[next - 1]) || !isDefined(self.data[next - 1].f))
			break;

		if (!isDefined(move) || !isDefined(move.f))
			break;

		if (move.f <= self.data[next - 1].f)
			break;

		self.data[last - 1] = self.data[next - 1];
		self.data[next - 1] = move;

		last = next;
		next = self _HeapNextChild(next, remove);
	}

	return remove;
}

// A heap invariant comparator for A* nodes
_botReverseHeapAStar(item, item2)
{
	if (!isDefined(item) || !isDefined(item.f))
		return false;

	if (!isDefined(item2) || !isDefined(item2.f))
		return true;

	return item.f < item2.f;
}

_botWPMemoryClear()
{
	self.actor[AVOID_WP] = [];
	self.actor[LAST_WALL_FLANK_WP] = undefined;
	self.actor[LAST_WAYPOINT_BYPASS_WP] = undefined;
}

_botWPMemoryPrune()
{
	list = [];
	if (isDefined(self.actor[AVOID_WP]))
		list = self.actor[AVOID_WP];

	if (!isDefined(list) || !list.size)
	{
		self.actor[AVOID_WP] = [];
		return;
	}

	now = gettime();
	newList = [];

	for (i = 0; i < list.size; i++)
	{
		entry = list[i];
		if (!isDefined(entry) || !isDefined(entry.wp) || !isDefined(entry.expire))
			continue;

		if (now > entry.expire)
			continue;

		if (!isDefined(entry.strikes))
			entry.strikes = 1;

		newList[newList.size] = entry;
	}

	if (newList.size > 24)
	{
		trimmed = [];
		start = newList.size - 24;
		for (i = start; i < newList.size; i++)
			trimmed[trimmed.size] = newList[i];

		newList = trimmed;
	}

	self.actor[AVOID_WP] = newList;
}

_botWPMemoryGetStrikes(wpIdx)
{
	if (!isDefined(wpIdx))
		return 0;

	self _botWPMemoryPrune();

	if (!isDefined(self.actor[AVOID_WP]) || !self.actor[AVOID_WP].size)
		return 0;

	for (i = 0; i < self.actor[AVOID_WP].size; i++)
	{
		entry = self.actor[AVOID_WP][i];
		if (!isDefined(entry) || !isDefined(entry.wp) || entry.wp != wpIdx)
			continue;

		if (!isDefined(entry.strikes))
			return 1;

		return entry.strikes;
	}

	return 0;
}

_botWPMemoryIsBlocked(wpIdx)
{
	if (!isDefined(wpIdx))
		return false;

	if (!isDefined(self.actor[NEGATIVE_MODE]) || !self.actor[NEGATIVE_MODE])
		return false;

	return (self _botWPMemoryGetStrikes(wpIdx)) > 0;
}

_botWPMemoryMarkFail(wpIdx, ttl_ms)
{
	if (!isDefined(wpIdx))
		return;

	if (!isDefined(ttl_ms) || ttl_ms <= 0)
		ttl_ms = 6500;
	if (ttl_ms < 2000)
		ttl_ms = 2000;
	if (ttl_ms > 20000)
		ttl_ms = 20000;

	self _botWPMemoryPrune();
	if (!isDefined(self.actor[AVOID_WP]))
		self.actor[AVOID_WP] = [];

	now = gettime();
	for (i = 0; i < self.actor[AVOID_WP].size; i++)
	{
		entry = self.actor[AVOID_WP][i];
		if (!isDefined(entry) || !isDefined(entry.wp) || entry.wp != wpIdx)
			continue;

		if (!isDefined(entry.strikes))
			entry.strikes = 1;
		entry.strikes++;
		entry.expire = now + ttl_ms;
		return;
	}

	entry = spawnstruct();
	entry.wp = wpIdx;
	entry.strikes = 1;
	entry.expire = now + ttl_ms;
	self.actor[AVOID_WP][self.actor[AVOID_WP].size] = entry;
	self _botWPMemoryPrune();
}

_botEdgeMemoryKey(fromWp, toWp)
{
	if (!isDefined(fromWp) || !isDefined(toWp))
		return undefined;

	return (fromWp + "") + "_" + (toWp + "");
}

_botEdgeMemoryPrune()
{
	list = [];
	if (isDefined(self.botactor_bad_edges))
		list = self.botactor_bad_edges;

	if (!isDefined(list) || !list.size)
	{
		self.botactor_bad_edges = [];
		return;
	}

	now = gettime();
	newList = [];
	for (i = 0; i < list.size; i++)
	{
		entry = list[i];
		if (!isDefined(entry) || !isDefined(entry.key) || !isDefined(entry.expire))
			continue;

		if (now > entry.expire)
			continue;

		newList[newList.size] = entry;
	}

	if (newList.size > 32)
	{
		trimmed = [];
		start = newList.size - 32;
		for (i = start; i < newList.size; i++)
			trimmed[trimmed.size] = newList[i];

		newList = trimmed;
	}

	self.botactor_bad_edges = newList;
}

_botEdgeMemoryIsBlocked(fromWp, toWp)
{
	key = _botEdgeMemoryKey(fromWp, toWp);
	if (!isDefined(key))
		return false;

	if (isDefined(level.botactor_bad_edges_global))
	{
		entry = level.botactor_bad_edges_global[key];
		if (isDefined(entry))
		{
			if (!isDefined(entry.expire) || gettime() <= entry.expire)
				return true;
		}
	}

	self _botEdgeMemoryPrune();
	if (!isDefined(self.botactor_bad_edges) || !self.botactor_bad_edges.size)
		return false;

	for (i = 0; i < self.botactor_bad_edges.size; i++)
	{
		entry = self.botactor_bad_edges[i];
		if (!isDefined(entry) || !isDefined(entry.key))
			continue;

		if (entry.key == key)
			return true;
	}

	return false;
}

_botEdgeMemoryMarkFail(fromWp, toWp, ttl_ms)
{
	key = _botEdgeMemoryKey(fromWp, toWp);
	if (!isDefined(key))
		return;

	if (!isDefined(ttl_ms) || ttl_ms <= 0)
		ttl_ms = _botNavigationEdgeFailTtl();

	self _botEdgeMemoryPrune();
	if (!isDefined(self.botactor_bad_edges))
		self.botactor_bad_edges = [];

	now = gettime();
	for (i = 0; i < self.botactor_bad_edges.size; i++)
	{
		entry = self.botactor_bad_edges[i];
		if (!isDefined(entry) || !isDefined(entry.key) || entry.key != key)
			continue;

		if (!isDefined(entry.strikes))
			entry.strikes = 1;
		entry.strikes++;
		entry.expire = now + ttl_ms;
		return;
	}

	entry = spawnstruct();
	entry.key = key;
	entry.from = fromWp;
	entry.to = toWp;
	entry.strikes = 1;
	entry.expire = now + ttl_ms;
	self.botactor_bad_edges[self.botactor_bad_edges.size] = entry;
	self _botEdgeMemoryPrune();
}

_botWaypointEdgeValidationEnabled()
{
	return false;
}

_botWaypointEdgeValidationKey(fromWp, toWp)
{
	return _botEdgeMemoryKey(fromWp, toWp);
}

_botWaypointEdgeSkipsTrace(wp, childWp)
{
	if (!isDefined(wp) || !isDefined(childWp))
		return true;

	if (self _botIsTraversalNode(wp) || self _botIsTraversalNode(childWp))
		return true;

	if (isDefined(wp.type) && (wp.type == "climb" || wp.type == "prone"))
		return true;

	if (isDefined(childWp.type) && (childWp.type == "climb" || childWp.type == "prone"))
		return true;

	zDelta = abs(wp.origin[2] - childWp.origin[2]);
	if (zDelta > 96)
		return true;

	return false;
}

_botWaypointEdgeTracePasses(wp, childWp)
{
	if (!isDefined(wp) || !isDefined(wp.origin) || !isDefined(childWp) || !isDefined(childWp.origin))
		return false;

	if (self _botWaypointEdgeSkipsTrace(wp, childWp))
		return true;

	lowA = wp.origin + (0, 0, 18);
	lowB = childWp.origin + (0, 0, 18);
	if (!bullettracepassed(lowA, lowB, false, undefined))
		return false;

	highA = wp.origin + (0, 0, 54);
	highB = childWp.origin + (0, 0, 54);
	if (!bullettracepassed(highA, highB, false, undefined))
		return false;

	return true;
}


_botWaypointEdgeValid(fromWp, toWp, wp, childWp)
{
	if (!self _botWaypointEdgeValidationEnabled())
		return true;

	key = _botWaypointEdgeValidationKey(fromWp, toWp);
	if (!isDefined(key))
		return true;

	if (!isDefined(level.botactor_edge_valid_cache))
		level.botactor_edge_valid_cache = [];

	if (isDefined(level.botactor_edge_valid_cache[key]))
		return level.botactor_edge_valid_cache[key] != 0;

	valid = self _botWaypointEdgeTracePasses(wp, childWp);
	level.botactor_edge_valid_cache[key] = valid ? 1 : 0;
	return valid;
}

_botAvoidPrune()
{
	list = [];
	if (isDefined(self.actor[AVOID_ZONES]))
		list = self.actor[AVOID_ZONES];

	if (!isDefined(list) || !list.size)
	{
		self.actor[AVOID_ZONES] = [];
		return;
	}

	now = gettime();
	newList = [];

	for (i = 0; i < list.size; i++)
	{
		zone = list[i];
		if (!isDefined(zone) || !isDefined(zone.origin) || !isDefined(zone.expire) || !isDefined(zone.radius_sq))
			continue;

		if (now > zone.expire)
			continue;

		newList[newList.size] = zone;
	}

	if (newList.size > 10)
	{
		trimmed = [];
		start = newList.size - 10;
		for (i = start; i < newList.size; i++)
			trimmed[trimmed.size] = newList[i];

		newList = trimmed;
	}

	self.actor[AVOID_ZONES] = newList;
}

_botAvoidContains(pos)
{
	if (!isDefined(pos))
		return false;

	if (!isDefined(self.actor[NEGATIVE_MODE]) || !self.actor[NEGATIVE_MODE])
		return false;

	self _botAvoidPrune();

	if (!isDefined(self.actor[AVOID_ZONES]) || !self.actor[AVOID_ZONES].size)
		return false;

	testPos = (pos[0], pos[1], self.origin[2]);
	for (i = 0; i < self.actor[AVOID_ZONES].size; i++)
	{
		zone = self.actor[AVOID_ZONES][i];
		if (!isDefined(zone) || !isDefined(zone.origin) || !isDefined(zone.radius_sq))
			continue;

		if (distanceSquared(testPos, zone.origin) <= zone.radius_sq)
			return true;
	}

	return false;
}

_botAvoidMark(pos, radius, ttl_ms)
{
	if (!isDefined(pos))
		return;

	if (!isDefined(radius) || radius <= 0)
		radius = 128;
	if (radius < 72)
		radius = 72;
	if (radius > 256)
		radius = 256;

	if (!isDefined(ttl_ms) || ttl_ms <= 0)
		ttl_ms = 3000;
	if (ttl_ms < 1000)
		ttl_ms = 1000;
	if (ttl_ms > 8000)
		ttl_ms = 8000;

	self _botAvoidPrune();
	if (!isDefined(self.actor[AVOID_ZONES]))
		self.actor[AVOID_ZONES] = [];

	now = gettime();
	markPos = (pos[0], pos[1], self.origin[2]);
	markSq = radius * radius;

	for (i = 0; i < self.actor[AVOID_ZONES].size; i++)
	{
		zone = self.actor[AVOID_ZONES][i];
		if (!isDefined(zone) || !isDefined(zone.origin) || !isDefined(zone.radius_sq) || !isDefined(zone.expire))
			continue;

		if (distanceSquared(markPos, zone.origin) > 48 * 48)
			continue;

		if (zone.radius_sq < markSq)
			zone.radius_sq = markSq;

		newExpire = now + ttl_ms;
		if (zone.expire < newExpire)
			zone.expire = newExpire;

		return;
	}

	zone = spawnstruct();
	zone.origin = markPos;
	zone.radius_sq = markSq;
	zone.expire = now + ttl_ms;
	self.actor[AVOID_ZONES][self.actor[AVOID_ZONES].size] = zone;
	self _botAvoidPrune();
}

_botGetWaypointBypass(goal, scale)
{
	if (!isDefined(goal))
		return undefined;

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	team = undefined;
	if (isDefined(level.teambased) && level.teambased)
		team = self.team;

	if (!_botNavigationUsePathBudget(gettime()))
		return undefined;

	path = bot_astar_search(self.origin, goal, team, true);
	if (!isDefined(path) || path.size < 2)
		return undefined;

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	self.actor[LAST_WAYPOINT_BYPASS_WP] = undefined;
	negativeMode = false;
	if (isDefined(self.actor[NEGATIVE_MODE]) && self.actor[NEGATIVE_MODE])
		negativeMode = true;

	startTrace = self.origin + (0, 0, 16);
	bestCandidate = undefined;
	bestFraction = -1;
	bestWp = undefined;
	bestScore = -99999999;

	// path is goal->start, so inspect the first few "next from start" options from the tail.
	maxChecks = 2 + scale;
	if (negativeMode)
	{
		maxChecks = 8 + scale * 3;
		if (maxChecks > 22)
			maxChecks = 22;
	}
	checks = 0;
	minDepth = 0;
	if (negativeMode && path.size > 2)
		minDepth = 1;
	for (i = path.size - 2; i >= 0 && checks < maxChecks; i--)
	{
		wpIdx = path[i];
		if (!isDefined(level.waypoints[wpIdx]) || !isDefined(level.waypoints[wpIdx].origin))
			continue;

		candidate = level.waypoints[wpIdx].origin;
		candidate = (candidate[0], candidate[1], self.origin[2]);
		checks++;
		if (negativeMode && checks <= minDepth)
			continue;

		if (distanceSquared(self.origin, candidate) < 24 * 24)
			continue;
		if (self _botWPMemoryIsBlocked(wpIdx))
			continue;
		if (self _botAvoidContains(candidate))
			continue;
		if (self _botIsTightCornerPos(candidate) && scale < 3)
			continue;

		visible = sighttracepassed(startTrace, candidate, 0, undefined);
		if (visible && !negativeMode)
		{
			if (self _botSightAngleOk(startTrace, candidate))
			{
				self.actor[LAST_WAYPOINT_BYPASS_WP] = wpIdx;
				return candidate;
			}
		}

		tr = bullettrace(startTrace, candidate + (0, 0, 16), false, self);
		if (!isDefined(tr) || !isDefined(tr["fraction"]))
			continue;

		if (negativeMode)
		{
			pathDepth = checks;
			wpStrikes = self _botWPMemoryGetStrikes(wpIdx);
			score = int(tr["fraction"] * 100000) + pathDepth * 8000 - wpStrikes * 30000;
			if (visible)
				score += 12000;

			if (score > bestScore)
			{
				bestScore = score;
				bestCandidate = candidate;
				bestWp = wpIdx;
			}
			continue;
		}

		if (tr["fraction"] > bestFraction)
		{
			bestFraction = tr["fraction"];
			bestCandidate = candidate;
			bestWp = wpIdx;
		}
	}

	// Fallback: test elevated Z points if planar angle checks fail
	if (!isDefined(bestCandidate) && negativeMode)
	{
		elevations = [];
		elevations[elevations.size] = 48;
		elevations[elevations.size] = 72;
		elevations[elevations.size] = 96;
		elevations[elevations.size] = 128;

		for (e = 0; e < elevations.size; e++)
		{
			elevZ = self.origin[2] + elevations[e];
			for (i = path.size - 2; i >= 0; i--)
			{
				wpIdx = path[i];
				if (!isDefined(level.waypoints[wpIdx]) || !isDefined(level.waypoints[wpIdx].origin))
					continue;

				wpOrg = level.waypoints[wpIdx].origin;
				elevCandidate = (wpOrg[0], wpOrg[1], elevZ);
				if (distanceSquared(self.origin, elevCandidate) < 24 * 24)
					continue;
				if (self _botAvoidContains(elevCandidate))
					continue;

				elevTrace = bullettrace(startTrace, elevCandidate, false, self);
				if (!isDefined(elevTrace) || !isDefined(elevTrace["fraction"]))
					continue;

				if (elevTrace["fraction"] < 0.5)
					continue;

				if (self _botSightAngleOk(startTrace, elevCandidate))
				{
					self.actor[LAST_WAYPOINT_BYPASS_WP] = wpIdx;
					return elevCandidate;
				}
			}
		}
	}

	if (isDefined(bestCandidate))
	{
		if (!negativeMode && bestFraction < 0.55)
			return undefined;

		self.actor[LAST_WAYPOINT_BYPASS_WP] = bestWp;
		return bestCandidate;
	}

	return undefined;
}

_botBuildDetourPlanToTarget(target, scale)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return [];

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return [];

	team = undefined;
	if (isDefined(level.teambased) && level.teambased)
		team = self.team;

	if (!_botNavigationUsePathBudget(gettime()))
		return [];

	raw = bot_astar_search(self.origin, target.origin, team, false);
	if (!isDefined(raw) || raw.size < 3)
		return [];

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	skipFront = 1 + scale;
	plan = [];
	stepCount = 0;
	toTarget = (target.origin[0] - self.origin[0], target.origin[1] - self.origin[1], 0);
	targetDirOk = lengthsquared(toTarget) > 1;
	if (targetDirOk)
		toTarget = vectornormalize(toTarget);

	for (i = raw.size - 2; i >= 0; i--)
	{
		wpIdx = raw[i];
		wpOrg = _botGetWaypointOrigin(wpIdx);
		if (!isDefined(wpOrg))
			continue;

		stepCount++;
		if (stepCount <= skipFront)
			continue;

		if (self _botWPMemoryIsBlocked(wpIdx))
			continue;

		candidate = (wpOrg[0], wpOrg[1], self.origin[2]);
		if (distanceSquared(self.origin, candidate) < 56 * 56)
			continue;

		// Avoid overly frontal nodes during initial detour planning
		if (targetDirOk && plan.size < 4)
		{
			toWp = (candidate[0] - self.origin[0], candidate[1] - self.origin[1], 0);
			if (lengthsquared(toWp) > 1)
			{
				toWp = vectornormalize(toWp);
				align = toTarget[0] * toWp[0] + toTarget[1] * toWp[1];
				if (align > 0.92)
					continue;
			}
		}

		if (plan.size && plan[plan.size - 1] == wpIdx)
			continue;

		plan[plan.size] = wpIdx;
		if (plan.size >= 12)
			break;
	}

	// Fallback: use path segment without frontal filtering
	if (!plan.size)
	{
		stepCount = 0;
		for (i = raw.size - 2; i >= 0; i--)
		{
			wpIdx = raw[i];
			if (!isDefined(_botGetWaypointOrigin(wpIdx)))
				continue;

			stepCount++;
			if (stepCount <= skipFront)
				continue;
			if (self _botWPMemoryIsBlocked(wpIdx))
				continue;

			plan[plan.size] = wpIdx;
			if (plan.size >= 10)
				break;
		}
	}

	return plan;
}

_botBuildSideDetourPlan(target, scale, preferredSide)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return [];

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return [];

	team = undefined;
	if (isDefined(level.teambased) && level.teambased)
		team = self.team;

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	toTarget = (target.origin[0] - self.origin[0], target.origin[1] - self.origin[1], 0);
	if (lengthsquared(toTarget) < 1)
		return [];
	toTarget = vectornormalize(toTarget);
	right = (0 - toTarget[1], toTarget[0], 0);

	radii = [];
	radii[radii.size] = 420 + scale * 80;
	radii[radii.size] = 620 + scale * 110;
	radii[radii.size] = 820 + scale * 130;

	bestPlan = [];
	bestScore = -99999999;
	skipFront = 1 + scale;

	for (r = 0; r < radii.size; r++)
	{
		for (side = 0; side < 2; side++)
		{
			sign = 1;
			if (side == 1)
				sign = -1;
			if (isDefined(preferredSide) && preferredSide != 0 && sign != preferredSide)
				continue;

			pseudo = target.origin + right * (radii[r] * sign);
			pseudo = (pseudo[0], pseudo[1], self.origin[2]);

			if (!_botNavigationUsePathBudget(gettime()))
				continue;

			raw = bot_astar_search(self.origin, pseudo, team, false);
			if (!isDefined(raw) || raw.size < 3)
				continue;

			plan = [];
			stepCount = 0;
			for (i = raw.size - 2; i >= 0; i--)
			{
				wpIdx = raw[i];
				wpOrg = _botGetWaypointOrigin(wpIdx);
				if (!isDefined(wpOrg))
					continue;

				stepCount++;
				if (stepCount <= skipFront)
					continue;

				if (self _botWPMemoryIsBlocked(wpIdx))
					continue;

				candidate = (wpOrg[0], wpOrg[1], self.origin[2]);
				if (distanceSquared(self.origin, candidate) < 56 * 56)
					continue;

				// Lateral planning initial nodes: avoid direct frontal trajectory
				if (plan.size < 2)
				{
					toWp = (candidate[0] - self.origin[0], candidate[1] - self.origin[1], 0);
					if (lengthsquared(toWp) > 1)
					{
						toWp = vectornormalize(toWp);
						align = toTarget[0] * toWp[0] + toTarget[1] * toWp[1];
						if (align > 0.90)
							continue;
					}
				}

				if (plan.size && plan[plan.size - 1] == wpIdx)
					continue;

				plan[plan.size] = wpIdx;
				if (plan.size >= 12)
					break;
			}

			if (!plan.size)
				continue;

			firstWp = _botGetWaypointOrigin(plan[0]);
			if (!isDefined(firstWp))
				continue;
			firstDir = (firstWp[0] - self.origin[0], firstWp[1] - self.origin[1], 0);
			alignAbs = 1.0;
			if (lengthsquared(firstDir) > 1)
			{
				firstDir = vectornormalize(firstDir);
				alignAbs = toTarget[0] * firstDir[0] + toTarget[1] * firstDir[1];
				if (alignAbs < 0)
					alignAbs = 0 - alignAbs;
			}

			firstStrikes = self _botWPMemoryGetStrikes(plan[0]);
			score = plan.size * 3000 + int((1.0 - alignAbs) * 50000) - firstStrikes * 40000 - r * 2500;
			if (score > bestScore)
			{
				bestScore = score;
				bestPlan = plan;
			}
		}
	}

	return bestPlan;
}

bot_go_hunt_route(target, sideSign, scale, maxSteps)
{
	if (!isDefined(target) || !isAlive(target) || !isDefined(target.origin))
		return false;

	if (self lethalbeats\botactor\targeting::_botHasTargetSight(target))
		return true;

	if (!isDefined(sideSign))
		sideSign = 0;
	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (!isDefined(maxSteps) || maxSteps <= 0)
		maxSteps = 4;

	plan = self _botBuildSideDetourPlan(target, scale, sideSign);
	if (!isDefined(plan) || !plan.size)
		plan = self _botBuildDetourPlanToTarget(target, scale);
	if (!isDefined(plan) || !plan.size)
		return false;

	self.actor[CHASE_TARGET] = target;
	steps = 0;
	for (i = 0; i < plan.size && steps < maxSteps; i++)
	{
		if (!isDefined(target) || !isAlive(target) || !isDefined(target.origin))
			break;

		if (self lethalbeats\botactor\targeting::_botHasTargetSight(target))
			return true;

		wp = _botGetWaypoint(plan[i]);
		if (!isDefined(wp))
			continue;

		if (distanceSquared(wp.origin, target.origin) < 192 * 192)
			break;

		reached = self bot_go_to(wp.origin, 64, 3, 5, false, false);
		self.actor[CHASE_TARGET] = target;
		steps++;

		if (!isDefined(reached) || !reached)
			self _botWPMemoryMarkFail(plan[i], 6500);
	}

	return true;
}

_botGetRandomLargetsStrage(scale)
{
	if (!isDefined(scale) || scale <= 0)
		scale = 1;

	if (scale > 4)
		scale = 4;

	myOrg = self.origin + (0, 0, 16);
	step = 100 * scale;

	traces = [];
	traces[traces.size] = bullettrace(myOrg, myOrg + (-step, 0, 0), false, self);
	traces[traces.size] = bullettrace(myOrg, myOrg + (step, 0, 0), false, self);
	traces[traces.size] = bullettrace(myOrg, myOrg + (0, step, 0), false, self);
	traces[traces.size] = bullettrace(myOrg, myOrg + (0, -step, 0), false, self);
	traces[traces.size] = bullettrace(myOrg, myOrg + (-step, -step, 0), false, self);
	traces[traces.size] = bullettrace(myOrg, myOrg + (-step, step, 0), false, self);
	traces[traces.size] = bullettrace(myOrg, myOrg + (step, -step, 0), false, self);
	traces[traces.size] = bullettrace(myOrg, myOrg + (step, step, 0), false, self);

	bestFraction = -1;
	bestCount = 0;
	bestPos = undefined;
	top = [];

	for (i = 0; i < traces.size; i++)
	{
		tr = traces[i];
		if (!isDefined(tr) || !isDefined(tr["position"]))
			continue;

		candidate = tr["position"];
		candidate = (candidate[0], candidate[1], self.origin[2]);
		if (self _botAvoidContains(candidate))
			continue;

		fraction = 0;
		if (isDefined(tr["fraction"]))
			fraction = tr["fraction"];

		if (fraction > bestFraction)
		{
			bestFraction = fraction;
			top = [];
			top[top.size] = tr;
		}
		else if (bestFraction - fraction < 0.1)
			top[top.size] = tr;
	}

	if (!top.size)
		return undefined;

	pick = top[randomint(top.size)];
	if (!isDefined(pick) || !isDefined(pick["position"]))
		return undefined;

	bestPos = pick["position"];
	return (bestPos[0], bestPos[1], self.origin[2]);
}

_botGetSpaceClearCount(pos, radius)
{
	if (!isDefined(pos))
		return 0;

	if (!isDefined(radius) || radius <= 0)
		radius = 72;

	start = (pos[0], pos[1], pos[2] + 16);
	dirs = [];
	dirs[dirs.size] = (1, 0, 0);
	dirs[dirs.size] = (-1, 0, 0);
	dirs[dirs.size] = (0, 1, 0);
	dirs[dirs.size] = (0, -1, 0);
	dirs[dirs.size] = (0.707, 0.707, 0);
	dirs[dirs.size] = (0.707, -0.707, 0);
	dirs[dirs.size] = (-0.707, 0.707, 0);
	dirs[dirs.size] = (-0.707, -0.707, 0);

	clearCount = 0;
	dirCount = dirs.size;
	if (dirCount > 8)
		dirCount = 8;

	guard = 0;
	for (dirIdx = 0; dirIdx < dirCount; dirIdx++)
	{
		guard++;
		if (guard > 16)
			break;

		end = start + dirs[dirIdx] * radius;
		tr = bullettrace(start, end, false, self);
		if (!isDefined(tr) || !isDefined(tr["fraction"]))
			continue;

		if (tr["fraction"] >= 0.75)
			clearCount++;
	}

	return clearCount;
}

_botIsTightCornerPos(pos)
{
	clear72 = self _botGetSpaceClearCount(pos, 72);
	return clear72 <= 2;
}

_botGetAxisCornerBypass(goal, scale)
{
	if (!isDefined(goal))
		return undefined;

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	my = self.origin;
	dx = goal[0] - my[0];
	dy = goal[1] - my[1];

	maxStep = 96 + (scale * 56); // 152..320

	stepX = dx;
	if (stepX > maxStep)
		stepX = maxStep;
	else if (stepX < 0 - maxStep)
		stepX = 0 - maxStep;

	stepY = dy;
	if (stepY > maxStep)
		stepY = maxStep;
	else if (stepY < 0 - maxStep)
		stepY = 0 - maxStep;

	candidates = [];
	stepXAbs = stepX;
	if (stepXAbs < 0)
		stepXAbs = 0 - stepXAbs;

	stepYAbs = stepY;
	if (stepYAbs < 0)
		stepYAbs = 0 - stepYAbs;

	if (stepXAbs > 8)
		candidates[candidates.size] = (my[0] + stepX, my[1], my[2]);
	if (stepYAbs > 8)
		candidates[candidates.size] = (my[0], my[1] + stepY, my[2]);

	if (!candidates.size)
		return undefined;

	startTrace = my + (0, 0, 16);
	best = undefined;
	bestScore = -99999999;

	for (i = 0; i < candidates.size; i++)
	{
		candidate = candidates[i];
		if (self _botAvoidContains(candidate))
			continue;
		if (self _botIsTightCornerPos(candidate) && scale < 3)
			continue;

		tr = bullettrace(startTrace, candidate + (0, 0, 16), false, self);
		if (!isDefined(tr) || !isDefined(tr["fraction"]))
			continue;

		fraction = tr["fraction"];
		if (fraction < 0.2)
			continue;

		remainSq = distanceSquared(candidate, goal);
		score = int(fraction * 100000) - int(remainSq * 0.01);
		if (score > bestScore)
		{
			bestScore = score;
			best = candidate;
		}
	}

	return best;
}

_botGetPreemptCornerBypass(goal, scale)
{
	if (!isDefined(goal))
		return undefined;

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	my = self.origin;
	toGoal = (goal[0] - my[0], goal[1] - my[1], 0);
	if (lengthsquared(toGoal) < 72 * 72)
		return undefined;

	startTrace = my + (0, 0, 16);
	if (sighttracepassed(startTrace, goal, 0, undefined))
		return undefined;

	dir = vectornormalize(toGoal);
	probe = (my[0] + dir[0] * 72, my[1] + dir[1] * 72, my[2]);
	tr = bullettrace(startTrace, probe + (0, 0, 16), false, self);
	if (!isDefined(tr) || !isDefined(tr["fraction"]) || tr["fraction"] > 0.9)
		return undefined;

	bypass = self _botGetWaypointBypass(goal, scale);
	if (!isDefined(bypass))
		bypass = self _botGetAxisCornerBypass(goal, scale);
	if (!isDefined(bypass))
		return undefined;
	if (self _botAvoidContains(bypass))
		return undefined;

	if (!sighttracepassed(startTrace, bypass, 0, undefined))
		return undefined;

	if (!self _botSightAngleOk(startTrace, bypass))
		return undefined;

	return bypass;
}

_botGetWallFlankBypass(target, scale)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return undefined;

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	self.actor[LAST_WALL_FLANK_WP] = undefined;

	negativeMode = false;
	if (isDefined(self.actor[NEGATIVE_MODE]) && self.actor[NEGATIVE_MODE])
		negativeMode = true;

	eye = self getEye();
	if (!isDefined(eye))
		eye = self.origin + (0, 0, 60);
	eyeOffset = eye[2] - self.origin[2];
	if (eyeOffset < 20)
		eyeOffset = 20;
	if (eyeOffset > 75)
		eyeOffset = 75;

	targetPos = self lethalbeats\botactor\targeting::_botGetTargetSightPos(target);
	if (!isDefined(targetPos))
		return undefined;

	minDistSq = 96 * 96;
	maxDist = 360 + scale * 120;
	if (negativeMode)
	{
		minDist = 180 + scale * 35;
		minDistSq = minDist * minDist;
		maxDist = 620 + scale * 180;
	}
	else
	{
		// Bound flank distance to short/medium range
	}
	maxDistSq = maxDist * maxDist;

	startTrace = self.origin + (0, 0, 16);
	best = undefined;
	bestScore = -99999999;
	maxEval = 120 + scale * 40;
	if (maxEval > 260)
		maxEval = 260;
	evalCount = 0;

	for (i = 0; i < level.waypoints.size; i++)
	{
		if (evalCount >= maxEval)
			break;

		wp = level.waypoints[i];
		if (!isDefined(wp) || !isDefined(wp.origin))
			continue;
		if (self _botWPMemoryIsBlocked(i))
			continue;

		wpPos = wp.origin;
		toTargetSq = distanceSquared(wpPos, target.origin);
		if (toTargetSq < minDistSq || toTargetSq > maxDistSq)
			continue;

		candidate = (wpPos[0], wpPos[1], self.origin[2]);
		if (distanceSquared(self.origin, candidate) < 56 * 56)
			continue;
		if (self _botAvoidContains(candidate))
			continue;

		botDir = anglesToForward((0, self.angles[1], 0));
		startTracePull = self.origin + (0, 0, 32) - (botDir * 20);

		trToCandidate = bullettrace(startTracePull, candidate + (0, 0, 32), false, self);
		if (!isDefined(trToCandidate) || !isDefined(trToCandidate["fraction"]))
			continue;
		if (trToCandidate["fraction"] < 0.95)
			continue;

		wpEye = (wpPos[0], wpPos[1], wpPos[2] + eyeOffset);
		passed = sightTracePassed(wpEye, targetPos, false, self);

		if (!isDefined(passed) || !passed)
		{
			if (!negativeMode)
				continue;
			passed = false;
		}

		if (passed && !self _botSightAngleOk(wpEye, targetPos))
		{
			if (!negativeMode)
				continue;
			passed = false;
		}

		selfSq = distanceSquared(self.origin, candidate);
		toCandidateFraction = trToCandidate["fraction"];
		evalCount++;

		score = 12000 + int(toCandidateFraction * 22000) - int(selfSq * 0.008) - int(toTargetSq * 0.003);
		if (passed)
			score += 15000;

		if (negativeMode)
		{
			toTargetFromSelf = (target.origin[0] - self.origin[0], target.origin[1] - self.origin[1], 0);
			toCandidateFromSelf = (candidate[0] - self.origin[0], candidate[1] - self.origin[1], 0);
			alignAbs = 0.0;
			if (lengthsquared(toTargetFromSelf) > 1 && lengthsquared(toCandidateFromSelf) > 1)
			{
				v1 = vectornormalize(toTargetFromSelf);
				v2 = vectornormalize(toCandidateFromSelf);
				alignAbs = v1[0] * v2[0] + v1[1] * v2[1];
				if (alignAbs < 0)
					alignAbs = 0 - alignAbs;
			}

			wpStrikes = self _botWPMemoryGetStrikes(i);
			score += int(selfSq * 0.004); // Prefer wider detour in negative mode
			score += int((1.0 - alignAbs) * 45000); // Prefer lateral flank over frontal line
			score -= wpStrikes * 25000; // Heavy penalty for repeated IDs
		}

		if (score > bestScore)
		{
			bestScore = score;
			best = candidate;
			self.actor[LAST_WALL_FLANK_WP] = i;
		}
	}

	if (!isDefined(best) && negativeMode)
	{
		elevations = [];
		elevations[elevations.size] = 48;
		elevations[elevations.size] = 72;
		elevations[elevations.size] = 96;
		elevations[elevations.size] = 128;

		startTrace = self.origin + (0, 0, 16);
		for (e = 0; e < elevations.size; e++)
		{
			elevZ = self.origin[2] + elevations[e];
			for (i = 0; i < level.waypoints.size && evalCount < maxEval; i++)
			{
				wp = level.waypoints[i];
				if (!isDefined(wp) || !isDefined(wp.origin))
					continue;
				if (self _botWPMemoryIsBlocked(i))
					continue;

				wpPos = wp.origin;
				toTargetSq = distanceSquared(wpPos, target.origin);
				if (toTargetSq < minDistSq || toTargetSq > maxDistSq)
					continue;

				elevCandidate = (wpPos[0], wpPos[1], elevZ);
				if (distanceSquared(self.origin, elevCandidate) < 56 * 56)
					continue;
				if (self _botAvoidContains(elevCandidate))
					continue;

				trToElev = bullettrace(startTrace, elevCandidate, false, self);
				if (!isDefined(trToElev) || !isDefined(trToElev["fraction"]))
					continue;
				if (trToElev["fraction"] < 0.95)
					continue;

				if (self _botSightAngleOk(startTrace, elevCandidate))
				{
					self.actor[LAST_WALL_FLANK_WP] = i;
					return elevCandidate;
				}
			}
		}
	}

	return best;
}

_botGetBackstepGoal(goal, scale)
{
	if (!isDefined(goal))
		return undefined;

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	my = self.origin;
	dir = (goal[0] - my[0], goal[1] - my[1], 0);
	if (lengthsquared(dir) < 1)
	{
		fwd = anglesToForward((0, self.angles[1], 0));
		dir = (fwd[0], fwd[1], 0);
	}

	dir = vectornormalize(dir);
	back = (0 - dir[0], 0 - dir[1], 0);
	right = (0 - back[1], back[0], 0);

	backDist = 72 + (scale * 24);
	sideDist = 48 + (scale * 16);

	candidates = [];
	candidates[candidates.size] = (my[0] + back[0] * backDist, my[1] + back[1] * backDist, my[2]);
	candidates[candidates.size] = (my[0] + back[0] * backDist + right[0] * sideDist, my[1] + back[1] * backDist + right[1] * sideDist, my[2]);
	candidates[candidates.size] = (my[0] + back[0] * backDist - right[0] * sideDist, my[1] + back[1] * backDist - right[1] * sideDist, my[2]);
	candidates[candidates.size] = (my[0] + right[0] * sideDist, my[1] + right[1] * sideDist, my[2]);
	candidates[candidates.size] = (my[0] - right[0] * sideDist, my[1] - right[1] * sideDist, my[2]);

	startTrace = my + (0, 0, 16);
	best = undefined;
	bestScore = -99999999;

	for (i = 0; i < candidates.size; i++)
	{
		candidate = candidates[i];
		if (distanceSquared(my, candidate) < 24 * 24)
			continue;

		tr = bullettrace(startTrace, candidate + (0, 0, 16), false, self);
		if (!isDefined(tr) || !isDefined(tr["fraction"]))
			continue;

		fraction = tr["fraction"];
		if (fraction < 0.25)
			continue;

		remainSq = distanceSquared(candidate, goal);
		score = int(fraction * 100000) - int(remainSq * 0.01);
		if (score > bestScore)
		{
			bestScore = score;
			best = candidate;
		}
	}

	return best;
}

// Bridge waypoint for navigating around barriers with target on opposite side
_botGetBridgeWaypoint(target, scale)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return undefined;

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	if (!isDefined(scale) || scale <= 0)
		scale = 1;
	if (scale > 4)
		scale = 4;

	targetPos = self lethalbeats\botactor\targeting::_botGetTargetSightPos(target);
	if (!isDefined(targetPos))
		return undefined;

	startTrace = self.origin + (0, 0, 16);
	best = undefined;
	bestScore = -99999999;
	maxEval = 200 + scale * 50;
	if (maxEval > 400)
		maxEval = 400;
	evalCount = 0;
	maxDistSq = (500 + scale * 200) * (500 + scale * 200);

	for (i = 0; i < level.waypoints.size && evalCount < maxEval; i++)
	{
		evalCount++;
		wp = level.waypoints[i];
		if (!isDefined(wp) || !isDefined(wp.origin))
			continue;

		wpPos = wp.origin;
		candidate = (wpPos[0], wpPos[1], wpPos[2]);
		distSq = distanceSquared(self.origin, candidate);
		if (distSq < 100 * 100 || distSq > maxDistSq)
			continue;

		if (self _botWPMemoryIsBlocked(i))
			continue;
		if (self _botAvoidContains(candidate))
			continue;

		trToWp = bullettrace(startTrace, candidate + (0, 0, 16), false, self);
		if (!isDefined(trToWp) || !isDefined(trToWp["fraction"]))
			continue;
		if (trToWp["fraction"] < 0.85)
			continue;

		wpEye = (wpPos[0], wpPos[1], wpPos[2] + 56);
		if (!sightTracePassed(wpEye, targetPos, false, self))
			continue;

		if (!self _botSightAngleOk(startTrace, candidate))
			continue;

		zDelta = wpPos[2] - self.origin[2];
		elevBonus = 0;
		if (zDelta > 0)
			elevBonus = int(zDelta * 50);

		score = int(trToWp["fraction"] * 80000) + elevBonus - int(distSq * 0.005);

		if (score > bestScore)
		{
			bestScore = score;
			best = candidate;
			self.actor[LAST_WAYPOINT_BYPASS_WP] = i;
		}
	}

	return best;
}

/*
///DocStringBegin
detail: bot_find_radial_waypoint(center?: <Vector|Entity>, minRadius?: <Float>, maxRadius?: <Float>, minAngle?: <Float>, maxAngle?: <Float>, baseAngle?: <Float>, checkSight?: <Bool>, targetEntity?: <Entity>): <Struct|Undefined>
summary: Finds a tactical reposition waypoint within a radial distance range and angular arc around a center position or target entity.
///DocStringEnd
*/
bot_find_radial_waypoint(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, checkSight, targetEntity)
{
	_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	// Resolve center position
	centerPos = self.origin;
	if (isDefined(center))
	{
		if (isPlayer(center) || (isDefined(center.origin) && lethalbeats\utility::is_vector(center.origin)))
		{
			centerPos = center.origin;
			if (!isDefined(targetEntity))
				targetEntity = center;
		}
		else if (lethalbeats\utility::is_vector(center))
			centerPos = center;
	}
	else if (isDefined(self.actor[CHASE_TARGET]) && isAlive(self.actor[CHASE_TARGET]))
	{
		centerPos = self.actor[CHASE_TARGET].origin;
		if (!isDefined(targetEntity))
			targetEntity = self.actor[CHASE_TARGET];
	}

	// Resolve radius range
	if (!isDefined(minRadius) && !isDefined(maxRadius))
	{
		minRadius = 200;
		maxRadius = 450;
	}
	else if (isDefined(minRadius) && !isDefined(maxRadius))
	{
		// Single radius value passed: construct a +/- 30% band
		r = minRadius;
		minRadius = max(64, r * 0.7);
		maxRadius = r * 1.3;
	}
	else if (!isDefined(minRadius) && isDefined(maxRadius))
	{
		minRadius = max(64, maxRadius * 0.5);
	}

	if (maxRadius < minRadius)
	{
		temp = minRadius;
		minRadius = maxRadius;
		maxRadius = temp;
	}

	minRadiusSq = minRadius * minRadius;
	maxRadiusSq = maxRadius * maxRadius;

	// Resolve base angle (yaw in degrees)
	if (!isDefined(baseAngle))
	{
		toSelf = (self.origin[0] - centerPos[0], self.origin[1] - centerPos[1], 0);
		if (lengthSquared(toSelf) > 16)
			baseAngle = vectorToYaw(toSelf);
		else
			baseAngle = self.angles[1];
	}

	// Resolve angular arc [minAngle, maxAngle] relative to baseAngle
	if (!isDefined(minAngle) && !isDefined(maxAngle))
	{
		minAngle = -180;
		maxAngle = 180;
	}
	else if (isDefined(minAngle) && !isDefined(maxAngle))
	{
		arc = abs(minAngle);
		minAngle = 0 - arc;
		maxAngle = arc;
	}

	if (maxAngle < minAngle)
	{
		temp = minAngle;
		minAngle = maxAngle;
		maxAngle = temp;
	}

	if (!isDefined(checkSight))
		checkSight = false;

	if (!isDefined(targetEntity) && isDefined(self.actor[CHASE_TARGET]))
		targetEntity = self.actor[CHASE_TARGET];

	startTrace = self.origin + (0, 0, 16);
	candidates = [];
	scores = [];
	maxCandidates = 5;

	for (i = 0; i < level.waypoints.size; i++)
	{
		wp = level.waypoints[i];
		if (!isDefined(wp) || !isDefined(wp.origin))
			continue;

		wpPos = wp.origin;

		// Height filter: avoid unreachable levels far above or below
		zDiff = abs(wpPos[2] - self.origin[2]);
		if (zDiff > 120)
			continue;

		// Distance from center (XY plane)
		toWpCenter = (wpPos[0] - centerPos[0], wpPos[1] - centerPos[1], 0);
		distCenterSq = lengthSquared(toWpCenter);
		if (distCenterSq < minRadiusSq || distCenterSq > maxRadiusSq)
			continue;

		// Distance from current bot position: must move at least slightly, but not excessively
		distFromSelfSq = distanceSquared(self.origin, wpPos);
		if (distFromSelfSq < 48 * 48)
			continue;

		// Relative angular sector check
		wpYaw = vectorToYaw(toWpCenter);
		relAngle = angleClamp180(wpYaw - baseAngle);

		if (minAngle > -180 || maxAngle < 180)
		{
			if (relAngle < minAngle || relAngle > maxAngle)
				continue;
		}

		// Avoid memory blocks or avoid zones
		if (self _botWPMemoryIsBlocked(i))
			continue;
		if (self _botAvoidContains(wpPos))
			continue;

		// Sight check to target if required
		if (checkSight && isDefined(targetEntity) && isDefined(targetEntity.origin))
		{
			targetSightPos = self lethalbeats\botactor\targeting::_botGetTargetSightPos(targetEntity);
			if (isDefined(targetSightPos))
			{
				wpEye = wpPos + (0, 0, 56);
				if (!sightTracePassed(wpEye, targetSightPos, false, self))
					continue;
			}
		}

		// Direct trace check from bot to waypoint
		tr = bulletTrace(startTrace, wpPos + (0, 0, 16), false, self);
		if (!isDefined(tr) || !isDefined(tr["fraction"]) || tr["fraction"] < 0.75)
			continue;

		// Scoring
		score = int(tr["fraction"] * 50000);

		// Bonus for cover nodes (crouch / stand)
		if (isDefined(wp.type))
		{
			if (wp.type == "crouch" || wp.type == "stand")
				score += 20000;
			else if (wp.type == "prone")
				score += 8000;
		}

		// Slight preference for intermediate distance
		distSelf = sqrt(distFromSelfSq);
		idealDist = (minRadius + maxRadius) * 0.5;
		distDiff = abs(distSelf - idealDist);
		score -= int(distDiff * 30);

		// Angular diversity bonus: encourage lateral movement over staying in line
		score += int(abs(relAngle) * 40);

		// Insert into top candidates
		inserted = false;
		for (c = 0; c < candidates.size; c++)
		{
			if (score > scores[c])
			{
				shiftFrom = candidates.size;
				if (shiftFrom >= maxCandidates)
					shiftFrom = maxCandidates - 1;

				for (k = shiftFrom; k > c; k--)
				{
					candidates[k] = candidates[k - 1];
					scores[k] = scores[k - 1];
				}
				candidates[c] = wp;
				scores[c] = score;
				inserted = true;
				break;
			}
		}

		if (!inserted && candidates.size < maxCandidates)
		{
			candidates[candidates.size] = wp;
			scores[scores.size] = score;
		}
	}

	if (!candidates.size)
		return undefined;

	// Pick randomly from top candidates to prevent predictable grouping
	pickIdx = randomInt(candidates.size);
	return candidates[pickIdx];
}

/*
///DocStringBegin
detail: bot_reposition_radial(center?: <Vector|Entity>, minRadius?: <Float>, maxRadius?: <Float>, minAngle?: <Float>, maxAngle?: <Float>, baseAngle?: <Float>, timeout?: <Float>, stopDist?: <Float>): <Bool>
summary: Finds a radial waypoint and executes movement towards it using bot_go_to.
///DocStringEnd
*/
bot_reposition_radial(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, timeout, stopDist)
{
	wp = self bot_find_radial_waypoint(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, false, undefined);
	if (!isDefined(wp) || !isDefined(wp.origin))
		return false;

	if (!isDefined(stopDist)) stopDist = 32;
	if (!isDefined(timeout)) timeout = 4.0;

	self.actor[SCRIPT_MOVE] = true;
	self.actor[PATH_LOCK] = true;
	self.actor[MOVE_LOOK_MODE] = 1;

	reached = self bot_go_to(wp.origin, stopDist, 2.5, timeout, false, false);

	self.actor[SCRIPT_MOVE] = false;
	self.actor[PATH_LOCK] = false;
	return isDefined(reached) && reached;
}

// Checks if a direct line from start to end stays within the navigable waypoint grid
_botPathIsNavigable(start, end)
{
	return true;
}

_botGoToHandleFail(prevMoveLookMode)
{
	if (isDefined(prevMoveLookMode))
		self.actor[MOVE_LOOK_MODE] = prevMoveLookMode;
	self.actor[SCRIPT_MOVE] = false;
	self.actor[PATH_LOCK] = false;
	self bot_stop_move();
	self.actor[SPRINT_STATE] = false;
	self.actor[HOLD_SPRINT] = false;
	self.actor[LOCK] = false;
	return false;
}

_botGoToFinalize(prevMoveLookMode, ok)
{
	self.actor[SCRIPT_MOVE] = false;
	self.actor[PATH_LOCK] = false;
	self bot_stop_move();
	self.actor[SPRINT_STATE] = false;
	self.actor[HOLD_SPRINT] = false;
	self.actor[LOCK] = false;

	if (isDefined(prevMoveLookMode))
		self.actor[MOVE_LOOK_MODE] = prevMoveLookMode;

	return ok;
}

_botGoToFindBridgeWaypoint(goal)
{
	return undefined;
}

_botGoToPointSimple(point, stop_dist, timeout, final_segment, node, wpIdx, keep_chase, chaseTarget, chaseGoal)
{
	self endon("bot_go_to");
	self endon("disconnect");
	self endon("death");

	if (!isDefined(point) || !isDefined(self) || !isDefined(self.origin))
		return false;

	self.node = node;

	if (!isDefined(final_segment))
		final_segment = true;
	if (!isDefined(stop_dist))
		stop_dist = 64;
	if (!isDefined(timeout))
		timeout = 3;

	stop_dist_sq = stop_dist * stop_dist;
	elapsed = 0.0;

	if (!isDefined(self.actor) || !isDefined(self.bot)) return false;

	// One arrival radius for the whole stack
	if (isDefined(self.ba))
		self.ba.move_stop_dist = stop_dist;

	isClimbNode = isDefined(node) && isDefined(node.type) && node.type == "climb";
	climbJumpAttempts = 0;
	climbLastJumpTime = 0;
	climbLastPos = self.origin;
	climbLastPosTime = gettime();
	climbStallAccum = 0.0;

	for (;;)
	{
		if (!isDefined(self))
			return false;
		if (!isPlayer(self))
			return false;
		alive = isAlive(self);
		if (!isDefined(alive) || !alive)
			return false;
		if (!isDefined(self.actor) || !isDefined(self.bot) || !isDefined(self.origin) || !isDefined(point))
			return false;

		self.bot.moveto = point;
		animLocked = false;
		if (isDefined(self.bot.anim_lock))
			animLocked = self.bot.anim_lock;

		if (!animLocked)
			self.bot.stop_move = false;
		self.actor[HEARTBEAT_NAV] = gettime();

		if (isDefined(keep_chase) && keep_chase && isDefined(chaseTarget))
		{
			if (!isDefined(chaseTarget.origin))
				return false;

			// Only the target MOVING invalidates this route
			if (self _botChaseTargetMovedFromGoal(chaseGoal, chaseTarget))
			{
				self.bot_chase_repath_requested = true;
				return false;
			}
		}

		dist_sq = distancesquared(self.origin, point);
		if (!isDefined(dist_sq))
			return false;

		if (isDefined(node))
		{
			self _botUpdateTraversalNode(node, point, dist_sq);
			self _botUpdateDoorwayNode(node, point, dist_sq, wpIdx);
			self _botUpdateClimbNode(node, point, dist_sq, wpIdx);
		}

		// 1. Direct 3D distance arrival check
		if (dist_sq <= stop_dist_sq)
		{
			if (final_segment)
			{
				self.bot.stop_move = true; // Brake
				self.actor[SPRINT_STATE] = false;
				self.actor[HOLD_SPRINT] = false;
				if (isDefined(self.ba))
					self.ba.move_stop_dist = 16;
			}
			if (isDefined(node)) self _botHandleWaypointArrival(node, final_segment);
			return true;
		}

		// 2. Ladder Climb & Non-ladder obstacle climb handling
		if (isClimbNode)
		{
			now = gettime();
			onLadder = self isOnLadder();

			if (onLadder)
			{
				// Successfully hooked to ladder! Reset jump attempts & stall
				climbJumpAttempts = 0;
				climbStallAccum = 0.0;
				climbLastPos = self.origin;
				climbLastPosTime = now;

				zDiff = abs(self.origin[2] - point[2]);
				dist2d = distance2d(self.origin, point);
				if (zDiff <= 36 && dist2d <= 48)
				{
					if (isDefined(node)) self _botHandleWaypointArrival(node, final_segment);
					return true;
				}
			}
			else
			{
				// Not on ladder: could be a medium wall, high obstacle, or failed ladder attachment
				waitingInQueue = isDefined(self.bot.stop_move) && self.bot.stop_move;
				if (!waitingInQueue)
				{
					dist2d = distance2d(self.origin, point);

					// Sample horizontal movement every 150ms to detect stalling ("se frena")
					if (now - climbLastPosTime >= 150)
					{
						horizMoved = distance2d(self.origin, climbLastPos);
						climbLastPos = self.origin;
						climbLastPosTime = now;

						isBlocked = (horizMoved < 4) || (isDefined(self.ba) && isDefined(self.ba.blocked) && self.ba.blocked);
						if (isBlocked && dist2d <= 110)
							climbStallAccum += 0.15;
						else
							climbStallAccum = 0.0;
					}

					// Trigger jump if stalled in front of the climb obstacle, or within point-blank range of an elevated ledge
					zDelta = point[2] - self.origin[2];
					isStalledNearObstacle = (climbStallAccum >= 0.2 && dist2d <= 110);
					isHuggingElevatedWall = (dist2d <= 48 && zDelta > 18);

					if (isStalledNearObstacle || isHuggingElevatedWall)
					{
						if (now >= climbLastJumpTime + 700)
						{
							if (climbJumpAttempts < 3)
							{
								climbJumpAttempts++;
								climbLastJumpTime = now;
								climbStallAccum = 0.0;

								// Look towards the climb target/obstacle
								toObstacle = (point[0] - self.origin[0], point[1] - self.origin[1], 0);
								if (lengthsquared(toObstacle) > 1)
									self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(toObstacle), 600);

								// Press sprint + jump to trigger mantle / climb jump over obstacle
								self bot_press_sprint(0.25);
								self bot_press_jump(0.25);
								self.bot.stop_move = false;
							}
							else
							{
								// All 3 jump attempts failed without getting on a ladder or reaching destination!
								// Reroute: mark node/edge as failed and release claims
								if (isDefined(wpIdx))
								{
									self bot_wp_release(wpIdx);
									self bot_wp_mark_fail(wpIdx, 10000);
								}
								if (isDefined(self.bot_climb_partner_idx))
								{
									self bot_wp_release(self.bot_climb_partner_idx);
									self bot_wp_mark_fail(self.bot_climb_partner_idx, 10000);
									self.bot_climb_partner_idx = undefined;
								}
								self _botMarkBlockedMove(point, wpIdx);
								return false;
							}
						}
					}
				}
			}
		}

		// Also check 2D X-Y only dist if we're physically unable to reach true Z
		// IMPORTANT: For climb/ladder nodes, vertical height is mandatory! Never trigger 2D arrival when Z is far!
		if (!isClimbNode && abs(point[2] - self.origin[2]) < 38)
		{
			world_dir_2d = (point[0] - self.origin[0], point[1] - self.origin[1], 0);
			world_dir_2d_sq = lengthsquared(world_dir_2d);
			if (isDefined(world_dir_2d_sq) && world_dir_2d_sq <= stop_dist_sq)
			{
				if (final_segment)
				{
					self.bot.stop_move = true;
					self.actor[SPRINT_STATE] = false;
					self.actor[HOLD_SPRINT] = false;
					if (isDefined(self.ba))
						self.ba.move_stop_dist = 16;
				}
				if (isDefined(node)) self _botHandleWaypointArrival(node, final_segment);
				return true;
			}
		}

		if (elapsed >= timeout)
		{
			if (isClimbNode)
			{
				if (isDefined(wpIdx))
				{
					self bot_wp_release(wpIdx);
					self bot_wp_mark_fail(wpIdx, 10000);
				}
				if (isDefined(self.bot_climb_partner_idx))
				{
					self bot_wp_release(self.bot_climb_partner_idx);
					self bot_wp_mark_fail(self.bot_climb_partner_idx, 10000);
					self.bot_climb_partner_idx = undefined;
				}
			}
			self _botMarkBlockedMove(point, wpIdx);
			if (final_segment && isDefined(self.ba))
				self.ba.move_stop_dist = 16;
			return false;
		}

		wait 0.05;
		elapsed += 0.05;
	}
}

_botIsTraversalNode(node)
{
	if (!isDefined(node) || !isDefined(node.type))
		return false;

	if (node.type == "jump" || node.type == "mantle")
		return true;

	return false;
}

_botUpdateTraversalNode(node, point, distSq)
{
	isTraversal = self _botIsTraversalNode(node);
	if (!isDefined(isTraversal) || !isTraversal)
		return;

	if (!isDefined(point) || !isDefined(distSq))
		return;

	if (distSq > 220 * 220)
		return;

	now = gettime();

	// Traversal nodes (jump/climb/mantle) require body facing the traversal gap during approach
	dir = (point[0] - self.origin[0], point[1] - self.origin[1], 0);
	if (lengthsquared(dir) > 1)
		self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(dir), 700);

	if (!isDefined(self.bot.next_traversal_press) || now >= self.bot.next_traversal_press)
	{
		self bot_press_sprint(0.25);
		self bot_press_jump(0.18);
		self.bot.next_traversal_press = now + 350;
	}
}

_botUpdateDoorwayNode(node, point, distSq, wpIdx)
{
	if (!isDefined(node) || !isDefined(node.type) || node.type != "doorway")
		return;

	if (!isDefined(self) || !isDefined(self.origin))
		return;

	// 1. Single-body Queue / Mutex Claim
	if (isDefined(wpIdx))
	{
		self.bot_current_wp_idx = wpIdx;
		claimOwner = bot_wp_claim_owner(wpIdx);
		if (isDefined(claimOwner) && claimOwner != self)
		{
			// Another bot is currently crossing this doorway; brake and yield
			self.bot.stop_move = true;
			return;
		}

		// Reserve doorway while approaching/crossing (3.5s timeout auto-cleans)
		self bot_wp_claim(wpIdx, 3500);
	}

	// 2. Virtual Rail Alignment & Steering Direction
	doorYaw = 0;
	if (isDefined(node.angles))
		doorYaw = node.angles[1];

	fwd = anglesToForward((0, doorYaw, 0));
	toBot = (self.origin[0] - node.origin[0], self.origin[1] - node.origin[1], 0);
	dot = toBot[0] * fwd[0] + toBot[1] * fwd[1];

	// Keep body facing along the passage direction through the doorway
	faceDir = fwd;
	if (dot > 0)
		faceDir = (0 - fwd[0], 0 - fwd[1], 0);

	if (lengthsquared(faceDir) > 0.01)
		self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(faceDir), 600);

	// 3. Speed Regulation (cancel sprint in narrow openings to prevent corner bounce)
	doorW = 54;
	if (isDefined(node.door_width))
		doorW = node.door_width;

	if (doorW < 50)
	{
		self.actor[HOLD_SPRINT] = false;
		self.actor[SPRINT_STATE] = false;
	}

	// 4. Stance Regulation (duck if opening is low)
	doorH = 76;
	if (isDefined(node.door_height))
		doorH = node.door_height;

	if (doorH < 60)
		self lethalbeats\botactor\movement::bot_set_stance("crouch");
}

_botUpdateClimbNode(node, point, distSq, wpIdx)
{
	if (!isDefined(node) || !isDefined(node.type) || node.type != "climb")
		return;

	if (!isDefined(self) || !isDefined(self.origin))
		return;

	// 1. Single-body Queue / Mutex Claim (Ladders fit only 1 bot)
	if (isDefined(wpIdx))
	{
		self.bot_current_wp_idx = wpIdx;
		claimOwner = bot_wp_claim_owner(wpIdx);
		partnerIdx = undefined;

		// Check the connected partner climb node (the other end of the ladder)
		if (isDefined(node.children) && isDefined(level.waypoints))
		{
			for (ci = 0; ci < node.children.size; ci++)
			{
				childIdx = node.children[ci];
				if (isDefined(level.waypoints[childIdx]) && isDefined(level.waypoints[childIdx].type) && level.waypoints[childIdx].type == "climb")
				{
					partnerIdx = childIdx;
					if (!isDefined(claimOwner))
						claimOwner = bot_wp_claim_owner(childIdx);
					break;
				}
			}
		}

		if (isDefined(claimOwner) && claimOwner != self)
		{
			// Another bot is currently climbing this ladder; queue / yield at entrance
			self.bot.stop_move = true;
			self.actor[HOLD_SPRINT] = false;
			self.actor[SPRINT_STATE] = false;
			self bot_release_sprint();

			// If too close to the ladder base/top, back off slightly so the exiting bot isn't blocked
			toNode = (self.origin[0] - node.origin[0], self.origin[1] - node.origin[1], 0);
			if (lengthsquared(toNode) < 45 * 45 && lengthsquared(toNode) > 1)
			{
				backDir = vectornormalize(toNode);
				self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(backDir), 400);
			}
			return;
		}

		// Reserve ladder while approaching/climbing (5.0s timeout auto-cleans)
		self bot_wp_claim(wpIdx, 5000);
		if (isDefined(partnerIdx))
		{
			self.bot_climb_partner_idx = partnerIdx;
			self bot_wp_claim(partnerIdx, 5000);
		}
	}

	// 2. Speed Regulation: STRICTLY cancel sprint when approaching or on a ladder
	// Never carry sprint momentum into a ladder (causes overshoot / clipping behind ladder)
	self.actor[HOLD_SPRINT] = false;
	self.actor[SPRINT_STATE] = false;
	self bot_release_sprint();

	// 3. Facing & Alignment: Look at ladder face rungs during approach and climb
	climbYaw = 0;
	hasAngles = false;
	if (isDefined(node.angles) && (node.angles[0] != 0 || node.angles[1] != 0 || node.angles[2] != 0))
	{
		climbYaw = node.angles[1];
		hasAngles = true;
	}

	onLadder = self isOnLadder();

	if (onLadder)
	{
		// On the ladder: Face towards the ladder rungs and look up or down
		zDelta = point[2] - self.origin[2];
		pitch = -35;
		if (zDelta < -20)
			pitch = 35;

		lookYaw = climbYaw;
		if (!hasAngles)
		{
			toTarget = (point[0] - self.origin[0], point[1] - self.origin[1], 0);
			if (lengthsquared(toTarget) > 1)
				lookYaw = vectortoyaw(toTarget);
		}

		self lethalbeats\botactor\movement::bot_look_at_angles((pitch, lookYaw, 0), 500);

		// Drive directly along ladder without side-drift or jumping
		self.bot.stop_move = false;
		return;
	}

	// Approaching ladder: Face toward ladder node directly
	approachDir = (point[0] - self.origin[0], point[1] - self.origin[1], 0);
	if (lengthsquared(approachDir) > 1)
	{
		if (hasAngles)
		{
			fwd = anglesToForward((0, climbYaw, 0));
			toBot = (self.origin[0] - node.origin[0], self.origin[1] - node.origin[1], 0);
			dot = toBot[0] * fwd[0] + toBot[1] * fwd[1];

			// Stay in front half-space; face into the ladder
			faceDir = (0 - fwd[0], 0 - fwd[1], 0);
			if (dot < 0)
				faceDir = fwd;

			self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(faceDir), 600);
		}
		else
		{
			self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(approachDir), 600);
		}
	}
}

_botHandleWaypointArrival(node, isFinalSegment)
{
	if (!isDefined(node) || !isDefined(node.type))
		return;

	// In transit, avoid forcing heavy stances unless explicitly required by map geometry (like crawling tunnels or doorways)
	if (!isFinalSegment && node.type != "crouch" && node.type != "prone" && node.type != "climb" && node.type != "jump" && node.type != "mantle" && node.type != "doorway")
		return;

	switch (node.type)
	{
		case "doorway":
			if (isDefined(self.bot_current_wp_idx))
				self bot_wp_release(self.bot_current_wp_idx);
			self notify("bot_behavior_doorway");
			break;

		case "climb":
			if (isDefined(self.bot_current_wp_idx))
				self bot_wp_release(self.bot_current_wp_idx);
			if (isDefined(self.bot_climb_partner_idx))
			{
				self bot_wp_release(self.bot_climb_partner_idx);
				self.bot_climb_partner_idx = undefined;
			}
			self notify("bot_behavior_climb");
			break;

		case "jump":
		case "mantle":
			self bot_press_sprint(0.25);
			self bot_press_jump(0.2);
			self notify("bot_behavior_jump");
			break;

		case "cover_crouch_window":
		case "cover_crouch":
		case "crouch":
			self lethalbeats\botactor\movement::bot_set_stance("crouch");
			self notify("bot_behavior_crouch");
			break;

		case "cover_stand":
		case "cover_right":
		case "cover_left":
		case "stand":
			// This used to call bot_press_stand(), which presses "+gostand" -- the JUMP button. Bots hopped on arrival at every stand node.
			self lethalbeats\botactor\movement::bot_set_stance("stand");
			self notify("bot_behavior_stand");
			break;

		case "cover_prone":
		case "prone":
			self lethalbeats\botactor\movement::bot_set_stance("prone");
			self notify("bot_behavior_prone");
			break;
	}

	if (isFinalSegment && issubstr(node.type, "cover"))
	{
		target = self _botGetCoverLookTarget();
		if (isDefined(target))
		{
			self _botFaceCoverTarget(target);
		}
		else if (isDefined(node.angles))
		{
			yaw = self bot_get_node_forward_yaw(node);
			self lethalbeats\botactor\movement::bot_look_at_angles((node.angles[0], yaw, 0), 1500);
		}
	}
}

_botGetCoverLookTarget()
{
	if (isDefined(self.bot_cover_target) && isDefined(self.bot_cover_target.origin))
		return self.bot_cover_target;

	if (isDefined(self.actor[CHASE_TARGET]) && isDefined(self.actor[CHASE_TARGET].origin))
		return self.actor[CHASE_TARGET];

	return undefined;
}

_botFaceCoverTarget(target)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return false;

	eye = self getEye();
	if (!isDefined(eye))
		eye = self.origin + (0, 0, 60);

	aimPos = target.origin + (0, 0, 48);
	self lethalbeats\botactor\movement::bot_set_aim_pos(aimPos);
	self lethalbeats\botactor\movement::bot_set_look_dir(aimPos - eye);
	self.actor[MOVE_LOOK_MODE] = 1;

	if (isDefined(self.bot))
	{
		self.bot.moveto = undefined;
		self.bot.stop_move = false;
	}

	lookDir = aimPos - eye;
	if (lengthSquared(lookDir) <= 1)
		return false;

	self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(lookDir), 600);
	return true;
}

_botCoverNodesEnabled()
{
	return _botNavigationOpt("cover_nodes") != 0;
}

_botGetCoverWaypoints()
{
	_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints)) return [];

	if (isDefined(level.botactor_cover_waypoints) && isDefined(level.botactor_cover_waypoints_count) && level.botactor_cover_waypoints_count == level.waypoints.size)
		return level.botactor_cover_waypoints;

	covers = [];
	for (i = 0; i < level.waypoints.size; i++)
	{
		wp = level.waypoints[i];
		if (!isDefined(wp) || !isDefined(wp.type) || !isDefined(wp.origin)) continue;
		if (!issubstr(wp.type, "cover")) continue;

		if (!isDefined(wp.botactor_cover_yaw) && isDefined(wp.angles))
			wp.botactor_cover_yaw = self bot_get_node_forward_yaw(wp);

		covers[covers.size] = wp;
	}

	level.botactor_cover_waypoints = covers;
	level.botactor_cover_waypoints_count = level.waypoints.size;
	return covers;
}

_findFreeCover(radius, centerPos, targetPos, checkSight)
{
	_botactorEnsureWaypoints();
	if (!_botCoverNodesEnabled()) return undefined;
	if (!isDefined(level.waypoints)) return undefined;
	if (!isDefined(checkSight)) checkSight = false;

	coverWaypoints = _botGetCoverWaypoints();
	if (!coverWaypoints.size) return undefined;

	bestWp = undefined;
	bestScore = 2147483647;
	fallbackWp = undefined;
	fallbackDistSq = 2147483647;
	radiusSq = radius * radius;
	hasTarget = isDefined(targetPos);
	traceLimit = 8;
	topNodes = [];
	topScores = [];

	// When checkSight is true, require line-of-sight to targetPos for tactical utility
	eyeOffset = (0, 0, 45);

	for (i = 0; i < coverWaypoints.size; i++)
	{
		wp = coverWaypoints[i];
		if (!isDefined(wp) || !isDefined(wp.origin)) continue;

		if (isDefined(wp.claimbot) && wp.claimbot != self && isAlive(wp.claimbot))
			continue;

		distSq = distanceSquared(centerPos, wp.origin);
		if (distSq > radiusSq)
			continue;

		if (distSq < fallbackDistSq)
		{
			fallbackDistSq = distSq;
			fallbackWp = wp;
		}

		score = distSq;
		if (hasTarget)
		{
			targetDir = (targetPos[0] - wp.origin[0], targetPos[1] - wp.origin[1], 0);
			if (lengthSquared(targetDir) > 1 && isDefined(wp.angles))
			{
				if (isDefined(wp.botactor_cover_yaw))
					coverYaw = wp.botactor_cover_yaw;
				else
					coverYaw = self bot_get_node_forward_yaw(wp);

				targetYaw = vectorToYaw(targetDir);
				yawDelta = abs(angleClamp180(targetYaw - coverYaw));

				// If the cover faces clearly away from the target, keep it only as fallback.
				if (yawDelta > 135)
					continue;

				score += int(yawDelta * 9000);
			}
		}

		if (checkSight && hasTarget)
		{
			insertIdx = topNodes.size;
			for (j = 0; j < topScores.size; j++)
			{
				if (score < topScores[j])
				{
					insertIdx = j;
					break;
				}
			}

			if (insertIdx < traceLimit)
			{
				shiftFrom = topNodes.size;
				if (shiftFrom >= traceLimit)
					shiftFrom = traceLimit - 1;

				for (j = shiftFrom; j > insertIdx; j--)
				{
					topNodes[j] = topNodes[j - 1];
					topScores[j] = topScores[j - 1];
				}

				topNodes[insertIdx] = wp;
				topScores[insertIdx] = score;
			}

			continue;
		}

		if (score < bestScore)
		{
			bestScore = score;
			bestWp = wp;

			// Early out on first suitable candidate with distance and visibility
			if (!hasTarget && distSq < 256*256)
				break;
		}
	}

	if (checkSight && hasTarget)
	{
		for (i = 0; i < topNodes.size; i++)
		{
			wp = topNodes[i];
			if (!isDefined(wp) || !isDefined(wp.origin)) continue;

			if (bulletTracePassed(wp.origin + eyeOffset, targetPos + eyeOffset, false, undefined))
				return wp;
		}

		return undefined;
	}

	if (!isDefined(bestWp))
		return fallbackWp;

	return bestWp;
}

_botMoveAndHoldCover(coverNode, target)
{
	self notify("bot_chase");
	self endon("bot_chase");
	self endon("disconnect");
	self endon("death");

	coverNode.claimbot = self;
	self.actor[COVER_CURRENT_NODE] = coverNode;
	self.bot_cover_target = target;
	if (isDefined(target))
		self.actor[CHASE_TARGET] = target;

	reached = self bot_go_to_node(coverNode, 32, 5, 8, false, false);
	if (isDefined(target))
		self.actor[CHASE_TARGET] = target;

	if (reached)
	{
		minTime = isDefined(self.actor[BEHAVIOR_COVER_MIN_TIME]) ? float(self.actor[BEHAVIOR_COVER_MIN_TIME]) : 2.0;
		maxTime = isDefined(self.actor[BEHAVIOR_COVER_MAX_TIME]) ? float(self.actor[BEHAVIOR_COVER_MAX_TIME]) : 5.0;
		if (minTime > maxTime) maxTime = minTime;

		holdTimeMs = int(randomFloatRange(minTime, maxTime) * 1000);
		endTime = gettime() + holdTimeMs;

		while (gettime() < endTime)
		{
			targetObj = target;
			if (!isDefined(targetObj) || !isDefined(targetObj.origin))
				targetObj = self.actor[CHASE_TARGET];

			if (isDefined(targetObj) && isDefined(targetObj.origin))
				self _botFaceCoverTarget(targetObj);
			else
				break;

			wait 0.2;
		}

		self lethalbeats\botactor\movement::bot_set_stance("stand");
	}

	if (isDefined(coverNode.claimbot) && coverNode.claimbot == self)
		coverNode.claimbot = undefined;
	self.actor[COVER_CURRENT_NODE] = undefined;
	self.bot_cover_target = undefined;
	self.actor[COVER_HOLDING_END_TIME] = gettime() + 2500;

	if (isDefined(self.actor[CHASE_TARGET]))
		self thread _botChaseLoop(self.actor[CHASE_TARGET]);
}

_botBuiltinFileRead(file)
{
	if (isDefined(level.bot_builtins) && isDefined(level.bot_builtins["fileread"]))
		return [[level.bot_builtins["fileread"]]](file);
	return undefined;
}

_botactorEnsureWaypoints()
{
	if (isDefined(level.waypoints) && level.waypoints.size > 0)
		return;

	level.waypoints = botactor_load_waypoints_gsc();
}

botactor_load_waypoints_gsc()
{
	waypoints = [];
	mapname = getDvar("mapname");

	paths = [];
	paths[0] = "maps/mp/bots/waypoints/" + mapname + ".gsc";
	paths[1] = "scriptdata/waypoints/" + mapname + ".gsc";
	paths[2] = "waypoints/" + mapname + ".gsc";

	content = undefined;
	for (p = 0; p < paths.size; p++)
	{
		content = _botBuiltinFileRead(paths[p]);
		if (isDefined(content) && content != "")
			break;
	}

	if (!isDefined(content) || content == "")
		return waypoints;

	lines = strtok(content, "\n\r");
	if (lines.size == 0)
		return waypoints;

	for (i = 0; i < lines.size; i++)
	{
		line = lines[i];
		if (line == "" || isSubStr(line, "//"))
			continue;

		if (isSubStr(line, "= spawnstruct();"))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx))
			{
				wp = spawnstruct();
				wp.children = [];
				waypoints[idx] = wp;
			}
			continue;
		}

		if (isSubStr(line, ".origin = ("))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
				waypoints[idx].origin = _botParseVector(line);
			continue;
		}

		if (isSubStr(line, ".type = \""))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
				waypoints[idx].type = _botParseQuotedString(line);
			continue;
		}

		if (isSubStr(line, ".angles = ("))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
				waypoints[idx].angles = _botParseVector(line);
			continue;
		}

		if (isSubStr(line, ".door_width = "))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
				waypoints[idx].door_width = float(_botParseValue(line));
			continue;
		}

		if (isSubStr(line, ".door_height = "))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
				waypoints[idx].door_height = float(_botParseValue(line));
			continue;
		}

		if (isSubStr(line, ".door_rail = "))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
				waypoints[idx].door_rail = float(_botParseValue(line));
			continue;
		}

		if (isSubStr(line, ".door_tag = \""))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
				waypoints[idx].door_tag = _botParseQuotedString(line);
			continue;
		}

		if (isSubStr(line, ".children["))
		{
			idx = _botParseWpIndex(line);
			if (isDefined(idx) && isDefined(waypoints[idx]))
			{
				dst = int(_botParseValue(line));
				waypoints[idx].children[waypoints[idx].children.size] = dst;
			}
			continue;
		}
	}

	return waypoints;
}

_botParseWpIndex(line)
{
	pos1 = _botStringIndexOf(line, "waypoints[");
	if (pos1 < 0)
		return undefined;

	pos1 += 10;
	pos2 = _botStringIndexOfFrom(line, "]", pos1);
	if (pos2 < 0)
		return undefined;

	sub = getSubStr(line, pos1, pos2);
	return int(sub);
}

_botParseVector(line)
{
	p1 = _botStringIndexOf(line, "(");
	p2 = _botStringIndexOf(line, ")");
	if (p1 < 0 || p2 < 0 || p2 <= p1)
		return (0, 0, 0);

	sub = getSubStr(line, p1 + 1, p2);
	toks = strtok(sub, ",");
	if (toks.size < 3)
		return (0, 0, 0);

	return (float(toks[0]), float(toks[1]), float(toks[2]));
}

_botParseQuotedString(line)
{
	p1 = _botStringIndexOf(line, "\"");
	if (p1 < 0)
		return "";

	p2 = _botStringIndexOfFrom(line, "\"", p1 + 1);
	if (p2 < 0)
		return "";

	return getSubStr(line, p1 + 1, p2);
}

_botParseValue(line)
{
	p1 = _botStringIndexOf(line, "=");
	if (p1 < 0)
		return "0";

	p2 = _botStringIndexOf(line, ";");
	if (p2 < 0)
		p2 = line.size;

	sub = getSubStr(line, p1 + 1, p2);
	toks = strtok(sub, " \t\r\n;");
	if (toks.size > 0)
		return toks[0];

	return "0";
}

_botStringIndexOf(str, sub)
{
	if (!isDefined(str) || !isDefined(sub) || sub.size > str.size)
		return -1;

	limit = str.size - sub.size;
	for (i = 0; i <= limit; i++)
	{
		match = true;
		for (j = 0; j < sub.size; j++)
		{
			if (str[i + j] != sub[j])
			{
				match = false;
				break;
			}
		}
		if (match)
			return i;
	}
	return -1;
}

_botStringIndexOfFrom(str, sub, start)
{
	if (!isDefined(str) || !isDefined(sub) || start >= str.size)
		return -1;

	limit = str.size - sub.size;
	for (i = start; i <= limit; i++)
	{
		match = true;
		for (j = 0; j < sub.size; j++)
		{
			if (str[i + j] != sub[j])
			{
				match = false;
				break;
			}
		}
		if (match)
			return i;
	}
	return -1;
}
