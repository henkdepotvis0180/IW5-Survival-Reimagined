/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : ai_patrol        |
|Creator : LastDemon99	   |
|Type : AI / Behavior      |
============================
*/

#include lethalbeats\botactor\utility;
#include lethalbeats\botactor\movement;
#include lethalbeats\botactor\navigation;
#include lethalbeats\botactor\behavior;

#define LOCK 0
#define SCRIPT_MOVE 3
#define PATH_LOCK 4
#define HEARTBEAT_NAV 7
#define PATROL_ACTIVE 20
#define PATROL_LOOP 21
#define CHASE_TARGET 22
#define CHASE_NEXT_MOVE_TIME 23
#define CHASE_LAST_GOAL 24
#define AIM_POS 41
#define MOVE_LOOK_MODE 46

// --- AWARENESS & ALERT STAGES ---
#define PATROL_ALERT_UNAWARE 0          // Relaxed patrol along waypoints
#define PATROL_ALERT_CURIOUS 1          // Heard/saw faint stimulus, turns to look briefly
#define PATROL_ALERT_INVESTIGATING 2    // Dispatched to POI to inspect disturbance
#define PATROL_ALERT_ALERTED 3          // Post-combat / high-vigilance search mode
#define PATROL_ALERT_COMBAT 4           // Visual confirmation / direct engagement

// --- TUNABLE DEFAULTS ---
#define PATROL_DEFAULT_STOP_DIST 32
#define PATROL_DEFAULT_WP_TIMEOUT 5.0
#define PATROL_DEFAULT_GOAL_TIMEOUT 15.0
#define PATROL_DEFAULT_ANGLE_TIME 1200
#define PATROL_INVESTIGATE_DURATION 7.0
#define PATROL_POST_COMBAT_COOLDOWN 4.0
#define PATROL_PERCEPTION_TICK 0.2
#define PATROL_SIGHT_DIST 1400
#define PATROL_SIGHT_FOV_UNAWARE 0.60   // ~75 degree cone
#define PATROL_SIGHT_FOV_ALERT 0.15     // ~135 degree cone
#define PATROL_HEAR_GUNFIRE_DIST_SQ 2400 * 2400
#define PATROL_HEAR_FOOTSTEP_DIST_SQ 550 * 550
#define PATROL_RADIO_BACKUP_DIST_SQ 1800 * 1800

/*
///DocStringBegin
detail: bot_patrol_route_create(name?: <String>, mode?: <String>): <Struct>
summary: Instantiates a new patrol route configuration struct.
///DocStringEnd
*/
bot_patrol_route_create(name, mode)
{
	route = spawnStruct();
	route.name = isDefined(name) ? name : "default_route";
	route.points = [];
	route.timers = [];
	route.angles = [];
	route.stances = [];
	route.scan_modes = [];
	route.mode = isDefined(mode) ? mode : "loop";
	route.speed = "walk";
	return route;
}

/*
///DocStringBegin
detail: bot_patrol_route_add_point(route: <Struct>, pos: <Vector3>, timer?: <Float>, angles?: <Vector3>, stance?: <String>, scan_mode?: <String>): <Struct>
summary: Appends a waypoint with timing, look orientation, stance, and scanning mode to a route.
///DocStringEnd
*/
bot_patrol_route_add_point(route, pos, timer, angles, stance, scan_mode)
{
	if (!isDefined(route) || !isDefined(pos) || !lethalbeats\utility::is_vector(pos))
		return route;

	idx = route.points.size;
	route.points[idx] = pos;
	route.timers[idx] = isDefined(timer) ? timer : 0.0;
	route.angles[idx] = isDefined(angles) && lethalbeats\utility::is_vector(angles) ? angles : undefined;
	route.stances[idx] = isDefined(stance) ? stance : "stand";
	route.scan_modes[idx] = isDefined(scan_mode) ? scan_mode : "fixed";
	return route;
}

/*
///DocStringBegin
detail: bot_patrol_create(points: <Vector3[]>, timers?: <Float[]>, angles?: <Vector3[]>, loop?: <Bool | String>, stances?: <String[]>): <Struct>
summary: Constructs a complete patrol route struct from array parameters.
///DocStringEnd
*/
bot_patrol_create(points, timers, angles, loop, stances)
{
	mode = "loop";
	if (isDefined(loop))
	{
		if (lethalbeats\utility::is_string(loop))
			mode = loop;
		else if (!loop)
			mode = "once";
	}

	route = bot_patrol_route_create("patrol", mode);
	if (!isDefined(points) || !points.size)
		return route;

	for (i = 0; i < points.size; i++)
	{
		point = points[i];
		if (!lethalbeats\utility::is_vector(point))
			continue;

		t = isDefined(timers) && isDefined(timers[i]) ? timers[i] : 0.0;
		ang = isDefined(angles) && isDefined(angles[i]) ? angles[i] : undefined;
		st = isDefined(stances) && isDefined(stances[i]) ? stances[i] : "stand";
		bot_patrol_route_add_point(route, point, t, ang, st, "fixed");
	}

	return route;
}

/*
///DocStringBegin
detail: <Player> bot_patrol(points: <Vector3[]>, timers?: <Float[]>, angles?: <Vector3[]>, loop?: <Bool | String>, stances?: <String[]>, mode?: <String>): <Bool>
summary: High-level command issuing a dedicated sensory patrol task on the bot.
///DocStringEnd
*/
bot_patrol(points, timers, angles, loop, stances, mode)
{
	if (!isDefined(points) || !points.size)
		return false;

	route = bot_patrol_create(points, timers, angles, loop, stances);
	if (isDefined(mode))
		route.mode = mode;

	return self bot_patrol_start(route, true, true);
}

/*
///DocStringBegin
detail: <Player> bot_patrol_start(route: <Struct>, resumeAfterCombat?: <Bool>, reactiveMode?: <Bool>): <Bool>
summary: Starts patrolling a specified route struct with perception monitoring and reactive AI transitions.
///DocStringEnd
*/
bot_patrol_start(route, resumeAfterCombat, reactiveMode)
{
	if (!isDefined(route) || !isDefined(route.points) || !route.points.size)
		return false;

	self notify("bot_chase");
	self.actor[CHASE_TARGET] = undefined;
	self.actor[CHASE_NEXT_MOVE_TIME] = 0;
	self.actor[CHASE_LAST_GOAL] = undefined;

	task = lethalbeats\botactor\behavior::bot_task_patrol(route.points, route.timers, route.angles, route.mode, route.stances, route.scan_modes);
	task.stop_dist = PATROL_DEFAULT_STOP_DIST;
	task.wp_timeout = PATROL_DEFAULT_WP_TIMEOUT;
	task.goal_timeout = PATROL_DEFAULT_GOAL_TIMEOUT;
	task.angle_time = PATROL_DEFAULT_ANGLE_TIME;
	task.angle_hold = 0.5;
	task.resume_combat = isDefined(resumeAfterCombat) ? resumeAfterCombat : true;
	task.reactive = isDefined(reactiveMode) ? reactiveMode : true;
	task.alert_state = PATROL_ALERT_UNAWARE;
	task.perception_meter = 0;

	self.actor[PATROL_LOOP] = (route.mode == "loop" || route.mode == "pingpong" || route.mode == "random");
	self.actor[PATROL_ACTIVE] = true;

	self lethalbeats\botactor\behavior::bot_do(task);
	self thread _botPatrolPerceptionMonitor(task);
	return true;
}

/*
///DocStringBegin
detail: <Player> bot_patrol_pause(): <Void>
summary: Temporarily pauses patrol movement while preserving route progression index.
///DocStringEnd
*/
bot_patrol_pause()
{
	self.actor[PATROL_ACTIVE] = false;
	self bot_stop_move();
	self notify("bot_patrol_paused");
}

/*
///DocStringBegin
detail: <Player> bot_patrol_resume(): <Void>
summary: Resumes active patrol movement along the current route.
///DocStringEnd
*/
bot_patrol_resume()
{
	self.actor[PATROL_ACTIVE] = true;
	self notify("bot_patrol_resumed");
}

/*
///DocStringBegin
detail: <Player> bot_patrol_stop(): <Void>
summary: Cancels patrol task, terminates perception monitors, and clears patrol runtime flags.
///DocStringEnd
*/
bot_patrol_stop()
{
	self.actor[PATROL_ACTIVE] = false;
	self.actor[PATROL_LOOP] = false;
	self bot_stop_move();
	self notify("bot_patrol_stopped");
	self notify("bot_patrol_end");
}

/*
///DocStringBegin
detail: <Player> bot_is_patrolling(): <Bool>
summary: Returns true if the bot has an active patrol task running.
///DocStringEnd
*/
bot_is_patrolling()
{
	if (!isDefined(self.actor[PATROL_ACTIVE]) || !self.actor[PATROL_ACTIVE])
		return false;

	kind = self lethalbeats\botactor\behavior::bot_task_kind();
	return isDefined(kind) && kind == "patrol";
}

/*
///DocStringBegin
detail: <Player> bot_patrol_get_alert_state(): <Int>
summary: Returns the current alert level (0=UNAWARE, 1=CURIOUS, 2=INVESTIGATING, 3=ALERTED, 4=COMBAT).
///DocStringEnd
*/
bot_patrol_get_alert_state()
{
	if (isDefined(self.ba) && isDefined(self.ba.task) && isDefined(self.ba.task.alert_state))
		return self.ba.task.alert_state;

	return PATROL_ALERT_UNAWARE;
}

/*
///DocStringBegin
detail: <Player> bot_patrol_investigate(pos: <Vector3>, duration?: <Float>, lookAngles?: <Vector3>): <Void>
summary: Commands a patrolling bot to break route and investigate a point of interest (POI).
///DocStringEnd
*/
bot_patrol_investigate(pos, duration, lookAngles)
{
	if (!isDefined(pos) || !lethalbeats\utility::is_vector(pos))
		return;

	if (!isDefined(self.ba) || !isDefined(self.ba.task) || self.ba.task.kind != "patrol")
		return;

	task = self.ba.task;
	if (task.alert_state == PATROL_ALERT_COMBAT)
		return;

	task.poi = pos;
	task.alert_state = PATROL_ALERT_INVESTIGATING;
	task.investigate_until = gettime() + int((isDefined(duration) ? duration : PATROL_INVESTIGATE_DURATION) * 1000);
	task.poi_angles = lookAngles;

	self notify("bot_patrol_alert", PATROL_ALERT_INVESTIGATING);
}

/*
///DocStringBegin
detail: <Player> bot_patrol_broadcast_alert(pos: <Vector3>, alertLevel: <Int>): <Void>
summary: Propagates a radio alert to nearby patrolling comrades within backup radius.
///DocStringEnd
*/
bot_patrol_broadcast_alert(pos, alertLevel)
{
	if (!isDefined(pos))
		return;

	players = level.players;
	if (!isDefined(players) || !players.size)
		return;

	for (i = 0; i < players.size; i++)
	{
		other = players[i];
		if (!isDefined(other) || !isAlive(other) || other == self)
			continue;

		if (isDefined(self.team) && isDefined(other.team) && other.team != self.team)
			continue;

		if (other bot_is_patrolling())
		{
			if (distanceSquared(other.origin, pos) <= PATROL_RADIO_BACKUP_DIST_SQ)
			{
				if (alertLevel >= PATROL_ALERT_COMBAT)
					other bot_patrol_investigate(pos, PATROL_INVESTIGATE_DURATION + 4.0);
				else
					other bot_patrol_investigate(pos, PATROL_INVESTIGATE_DURATION);
			}
		}
	}
}

/*
///DocStringBegin
detail: <Player> bot_patrol_on_damage(eAttacker?: <Entity>, iDamage?: <Int>, sMeansOfDeath?: <String>, sWeapon?: <String>): <Void>
summary: Sensory reaction hook when taking damage while on patrol.
///DocStringEnd
*/
bot_patrol_on_damage(eAttacker, iDamage, sMeansOfDeath, sWeapon)
{
	if (!self bot_is_patrolling())
		return;

	if (isDefined(eAttacker) && isAlive(eAttacker))
	{
		if (isDefined(self.ba) && isDefined(self.ba.task))
		{
			self.ba.task.alert_state = PATROL_ALERT_COMBAT;
			self.ba.task.combat_clear_until = undefined;
		}

		self.actor[CHASE_TARGET] = eAttacker;
		toAttacker = eAttacker.origin - self.origin;
		if (lengthSquared(toAttacker) > 1)
			self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(toAttacker), 800);

		self bot_patrol_broadcast_alert(eAttacker.origin, PATROL_ALERT_COMBAT);
		self notify("bot_patrol_alert", PATROL_ALERT_COMBAT);
	}
	else
	{
		self bot_patrol_investigate(self.origin, PATROL_INVESTIGATE_DURATION);
	}
}

/*
///DocStringBegin
detail: <Player> bot_patrol_on_noise(pos: <Vector3>, intensity?: <Float>, sourceEnt?: <Entity>): <Void>
summary: Sensory reaction hook when hearing a noise, explosion, or gunshot near the patrol route.
///DocStringEnd
*/
bot_patrol_on_noise(pos, intensity, sourceEnt)
{
	if (!self bot_is_patrolling())
		return;

	if (!isDefined(pos) || !lethalbeats\utility::is_vector(pos))
		return;

	distSq = distanceSquared(self.origin, pos);
	if (distSq > PATROL_HEAR_GUNFIRE_DIST_SQ)
		return;

	lookAng = undefined;
	toNoise = pos - self.origin;
	if (lengthSquared(toNoise) > 1)
		lookAng = vectorToAngles(toNoise);

	if (distSq <= PATROL_HEAR_FOOTSTEP_DIST_SQ)
	{
		// Close noise: immediate investigate
		self bot_patrol_investigate(pos, PATROL_INVESTIGATE_DURATION, lookAng);
	}
	else
	{
		// Medium/distant noise: turn head curiously and investigate
		if (isDefined(self.ba) && isDefined(self.ba.task) && self.ba.task.alert_state == PATROL_ALERT_UNAWARE)
		{
			if (isDefined(lookAng))
				self lethalbeats\botactor\movement::bot_look_at_angles(lookAng, 900);

			self bot_patrol_investigate(pos, PATROL_INVESTIGATE_DURATION, lookAng);
		}
	}
}

/*
///DocStringBegin
detail: <Player> bot_patrol_on_target_spotted(target: <Entity>): <Void>
summary: Sensory hook invoked when an enemy is visually confirmed along the patrol route.
///DocStringEnd
*/
bot_patrol_on_target_spotted(target)
{
	if (!self bot_is_patrolling())
		return;

	if (!isDefined(target) || !isAlive(target))
		return;

	if (isDefined(self.ba) && isDefined(self.ba.task))
	{
		self.ba.task.alert_state = PATROL_ALERT_COMBAT;
		self.ba.task.combat_clear_until = undefined;
		self.ba.task.perception_meter = 100;
	}

	self.actor[CHASE_TARGET] = target;
	self bot_patrol_broadcast_alert(target.origin, PATROL_ALERT_COMBAT);
	self notify("bot_patrol_alert", PATROL_ALERT_COMBAT);
}

/*
///DocStringBegin
detail: <Player> bot_patrol_on_target_lost(target: <Entity>): <Void>
summary: Sensory hook invoked when an engaged target breaks line of sight or is killed.
///DocStringEnd
*/
bot_patrol_on_target_lost(target)
{
	if (!isDefined(self.ba) || !isDefined(self.ba.task) || self.ba.task.kind != "patrol")
		return;

	self.ba.task.alert_state = PATROL_ALERT_ALERTED;
	self.ba.task.combat_clear_until = gettime() + int(PATROL_POST_COMBAT_COOLDOWN * 1000);
}

_botPatrolPerceptionMonitor(task)
{
	self notify("bot_patrol_perception");
	self endon("bot_patrol_perception");
	self endon("bot_patrol_stopped");
	self endon("bot_patrol_end");
	self endon("disconnect");
	self endon("death");

	for (;;)
	{
		wait PATROL_PERCEPTION_TICK;

		if (!self bot_is_patrolling())
			break;

		if (task.alert_state == PATROL_ALERT_COMBAT)
			continue;

		// Scan players for visual perception
		players = level.players;
		if (!isDefined(players) || !players.size)
			continue;

		botEye = self getEye();
		botAngles = self getPlayerAngles();
		bestThreat = undefined;
		highestDelta = 0;

		for (i = 0; i < players.size; i++)
		{
			p = players[i];
			if (!isDefined(p) || !isAlive(p) || p == self)
				continue;

			if (isDefined(self.team) && isDefined(p.team) && p.team == self.team)
				continue;

			targetPos = p.origin + (0, 0, 45);
			distSq = distanceSquared(self.origin, p.origin);
			maxDist = PATROL_SIGHT_DIST;

			// Visibility range modifier based on enemy stance & movement speed
			pVel = p getVelocity();
			if (lengthSquared(pVel) > 180 * 180)
				maxDist *= 1.25;
			else if (p getStance() == "crouch")
				maxDist *= 0.75;
			else if (p getStance() == "prone")
				maxDist *= 0.45;

			if (distSq > maxDist * maxDist)
				continue;

			// FOV Cone Check
			minFov = (task.alert_state == PATROL_ALERT_UNAWARE) ? PATROL_SIGHT_FOV_UNAWARE : PATROL_SIGHT_FOV_ALERT;
			coneDot = lethalbeats\vector::vector_get_cone_dot(targetPos, botEye, botAngles);
			if (coneDot < minFov)
				continue;

			// Line of Sight Trace Check
			if (sightTracePassed(botEye, targetPos, false, self))
			{
				rate = 35;
				if (distSq < 400 * 400) rate = 100;
				else if (coneDot > 0.85) rate = 65;

				if (rate > highestDelta)
				{
					highestDelta = rate;
					bestThreat = p;
				}
			}
		}

		if (isDefined(bestThreat))
		{
			task.perception_meter += highestDelta;
			if (task.perception_meter >= 100)
			{
				self bot_patrol_on_target_spotted(bestThreat);
			}
			else if (task.perception_meter >= 35 && task.alert_state == PATROL_ALERT_UNAWARE)
			{
				// Peripheral suspicion: look towards disturbance
				task.alert_state = PATROL_ALERT_CURIOUS;
				toThreat = bestThreat.origin - self.origin;
				if (lengthSquared(toThreat) > 1)
					self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(toThreat), 700);
			}
		}
		else
		{
			if (task.perception_meter > 0)
				task.perception_meter -= 15;

			if (task.perception_meter <= 0)
			{
				task.perception_meter = 0;
				if (task.alert_state == PATROL_ALERT_CURIOUS)
					task.alert_state = PATROL_ALERT_UNAWARE;
			}
		}
	}
}

_botPatrolFindNearestNode(points, origin)
{
	if (!isDefined(points) || !points.size)
		return 0;

	bestIdx = 0;
	bestDistSq = 999999999;

	for (i = 0; i < points.size; i++)
	{
		pt = points[i];
		if (!lethalbeats\utility::is_vector(pt))
			continue;

		dSq = distanceSquared(origin, pt);
		if (dSq < bestDistSq)
		{
			bestDistSq = dSq;
			bestIdx = i;
		}
	}

	return bestIdx;
}

/*
///DocStringBegin
detail: <Player> bot_patrol_task_run(task: <Struct>): <Bool>
summary: Core patrol task execution engine managing movement, scanning, perception alerts, and route resumption.
///DocStringEnd
*/
bot_patrol_task_run(task)
{
	if (!isDefined(task.points) || !task.points.size)
		return false;

	if (!isDefined(task.idx)) task.idx = 0;
	if (!isDefined(task.dir)) task.dir = 1;
	if (!isDefined(task.alert_state)) task.alert_state = PATROL_ALERT_UNAWARE;
	if (!isDefined(task.resume_combat)) task.resume_combat = true;
	if (!isDefined(task.reactive)) task.reactive = true;

	stopDist = isDefined(task.stop_dist) ? task.stop_dist : PATROL_DEFAULT_STOP_DIST;
	wpTimeout = isDefined(task.wp_timeout) ? task.wp_timeout : PATROL_DEFAULT_WP_TIMEOUT;
	goalTimeout = isDefined(task.goal_timeout) ? task.goal_timeout : PATROL_DEFAULT_GOAL_TIMEOUT;
	angleTime = isDefined(task.angle_time) ? task.angle_time : PATROL_DEFAULT_ANGLE_TIME;
	angleHold = isDefined(task.angle_hold) ? task.angle_hold : 0.5;

	routeMode = isDefined(task.loop) ? task.loop : "loop";
	if (routeMode == true) routeMode = "loop";
	else if (routeMode == false) routeMode = "once";

	self.actor[PATROL_ACTIVE] = true;
	self.actor[PATROL_LOOP] = (routeMode == "loop" || routeMode == "pingpong" || routeMode == "random");

	for (;;)
	{
		self.ba.runner_beat = gettime();
		self.actor[HEARTBEAT_NAV] = gettime();

		// --- COMBAT REACTION & RESUMPTION ---
		if (task.alert_state == PATROL_ALERT_COMBAT)
		{
			hasCombatTarget = isDefined(self.actor[CHASE_TARGET]) && isAlive(self.actor[CHASE_TARGET]);
			if (!hasCombatTarget)
			{
				if (!isDefined(task.combat_clear_until))
					task.combat_clear_until = gettime() + int(PATROL_POST_COMBAT_COOLDOWN * 1000);

				if (gettime() >= task.combat_clear_until)
				{
					task.alert_state = PATROL_ALERT_UNAWARE;
					task.combat_clear_until = undefined;
					task.perception_meter = 0;
					task.idx = _botPatrolFindNearestNode(task.points, self.origin);
					self bot_set_stance("stand");
					self notify("bot_patrol_resumed");
				}
			}
			else
			{
				task.combat_clear_until = undefined;
			}

			wait 0.2;
			continue;
		}

		// --- INVESTIGATION OF DISTURBANCE ---
		if (task.alert_state == PATROL_ALERT_INVESTIGATING)
		{
			if (isDefined(self.actor[CHASE_TARGET]) && isAlive(self.actor[CHASE_TARGET]))
			{
				task.alert_state = PATROL_ALERT_COMBAT;
				task.poi = undefined;
				continue;
			}

			if (isDefined(task.poi))
			{
				if (isDefined(task.poi_angles))
					self lethalbeats\botactor\movement::bot_look_at_angles(task.poi_angles, 600);

				reachedPoi = self lethalbeats\botactor\navigation::bot_go_to(task.poi, 48, 3.0, 8.0, true, false);
				self.ba.runner_beat = gettime();

				// Tactical scanning sweeps around POI
				curYaw = self.angles[1];
				self lethalbeats\botactor\movement::bot_look_at_angles((0, curYaw + 50, 0), 800);
				wait 0.8;
				self lethalbeats\botactor\movement::bot_look_at_angles((0, curYaw - 50, 0), 800);
				wait 0.8;
				task.poi = undefined;
			}

			if (gettime() >= task.investigate_until)
			{
				task.alert_state = PATROL_ALERT_UNAWARE;
				task.perception_meter = 0;
				task.idx = _botPatrolFindNearestNode(task.points, self.origin);
				self bot_set_stance("stand");
				self notify("bot_patrol_resumed");
			}
			else
			{
				wait 0.2;
				continue;
			}
		}

		// --- CURIOUS / BRIEF PERIPHERAL PAUSE ---
		if (task.alert_state == PATROL_ALERT_CURIOUS)
		{
			wait 0.5;
			self.ba.runner_beat = gettime();
			if (task.alert_state == PATROL_ALERT_CURIOUS)
				task.alert_state = PATROL_ALERT_UNAWARE;
		}

		// --- CALM PATROL EXECUTION ---
		if (task.reactive && isDefined(self.actor[CHASE_TARGET]) && isAlive(self.actor[CHASE_TARGET]))
		{
			task.alert_state = PATROL_ALERT_COMBAT;
			continue;
		}

		// Handle Route Bounds
		if (task.idx >= task.points.size || task.idx < 0)
		{
			self notify("bot_patrol_end");
			self notify("reached_path_end");

			if (routeMode == "once")
			{
				self.actor[PATROL_ACTIVE] = false;
				task.idx = 0;
				task.dir = 1;
				return true;
			}

			if (routeMode == "random")
			{
				task.idx = randomInt(task.points.size);
			}
			else if (routeMode == "pingpong")
			{
				if (task.points.size <= 1)
				{
					task.idx = 0;
				}
				else if (task.idx >= task.points.size)
				{
					task.dir = -1;
					task.idx = task.points.size - 2;
				}
				else
				{
					task.dir = 1;
					task.idx = 1;
				}
			}
			else
			{
				task.idx = 0;
				task.dir = 1;
			}
		}

		goal = task.points[task.idx];
		if (!lethalbeats\utility::is_vector(goal))
		{
			task.idx += task.dir;
			continue;
		}

		// Apply waypoint stance on approach if specified
		if (isDefined(task.stances) && isDefined(task.stances[task.idx]))
			self bot_set_stance(task.stances[task.idx]);

		reached = self lethalbeats\botactor\navigation::bot_go_to(goal, stopDist, wpTimeout, goalTimeout, true, false);
		self.ba.runner_beat = gettime();
		self.actor[HEARTBEAT_NAV] = gettime();

		if (!reached)
		{
			wait 0.5;
			task.idx += task.dir;
			continue;
		}

		// --- WAYPOINT ARRIVAL ACTIONS ---
		// Look angle orientation
		if (isDefined(task.angles) && isDefined(task.angles[task.idx]) && lethalbeats\utility::is_vector(task.angles[task.idx]))
		{
			self lethalbeats\botactor\movement::bot_look_at_angles(task.angles[task.idx], angleTime);
			if (angleHold > 0)
			{
				waitedAngle = 0.0;
				while (waitedAngle < angleHold)
				{
					wait 0.1;
					waitedAngle += 0.1;
					self.ba.runner_beat = gettime();
					if (task.alert_state != PATROL_ALERT_UNAWARE)
						break;
				}
			}
		}

		// Scanning sweeps if requested
		if (isDefined(task.scan_modes) && isDefined(task.scan_modes[task.idx]) && task.scan_modes[task.idx] == "sweep")
		{
			baseYaw = isDefined(task.angles) && isDefined(task.angles[task.idx]) ? task.angles[task.idx][1] : self.angles[1];
			self lethalbeats\botactor\movement::bot_look_at_angles((0, baseYaw + 50, 0), 700);
			wait 0.7;
			self lethalbeats\botactor\movement::bot_look_at_angles((0, baseYaw - 50, 0), 700);
			wait 0.7;
			self.ba.runner_beat = gettime();
		}

		// Waypoint pause duration
		if (isDefined(task.timers) && isDefined(task.timers[task.idx]) && lethalbeats\utility::is_number(task.timers[task.idx]) && task.timers[task.idx] > 0)
		{
			self bot_stop_move();
			hold = task.timers[task.idx];
			waited = 0.0;
			while (waited < hold)
			{
				wait 0.1;
				waited += 0.1;
				self.ba.runner_beat = gettime();
				if (task.alert_state != PATROL_ALERT_UNAWARE)
					break;
			}
		}

		// Restore stance to stand if a specialized stance was applied at this waypoint
		if (isDefined(task.stances) && isDefined(task.stances[task.idx]) && task.stances[task.idx] != "stand")
			self bot_set_stance("stand");

		if (routeMode == "random")
			task.idx = randomInt(task.points.size);
		else
			task.idx += task.dir;
	}
}
