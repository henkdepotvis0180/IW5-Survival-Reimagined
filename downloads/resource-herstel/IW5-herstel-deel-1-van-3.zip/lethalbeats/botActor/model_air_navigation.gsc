/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : model_air_navigation |
|Creator : LastDemon99	   |
|Type : Air Navigation API |
============================
*/

#include common_scripts\utility;

#define MODEL_AIR_TICK 0.05
#define MODEL_AIR_SPEED_MPH_TO_UNITS 17.6
#define MODEL_AIR_REF_SIZE 520.0
#define MODEL_AIR_DEFAULT_SPEED 1400
#define MODEL_AIR_DEFAULT_ACCEL 700
#define MODEL_AIR_DEFAULT_DECEL 450
#define MODEL_AIR_DEFAULT_YAW_SPEED 100
#define MODEL_AIR_DEFAULT_MAX_PITCH 35
#define MODEL_AIR_DEFAULT_MAX_ROLL 45
#define MODEL_AIR_DEFAULT_HOVER_AMP 12.0
#define MODEL_AIR_DEFAULT_HOVER_FREQ 1.3
#define MODEL_AIR_DEFAULT_NEAR_GOAL_DIST 512
#define MODEL_AIR_DEFAULT_GOAL_DIST 80
#define MODEL_AIR_DEFAULT_FLY_HEIGHT 850
#define MODEL_AIR_SYNTHETIC_SPACING 750
#define MODEL_AIR_HOVER_MAX_SPEED 90

/*
///DocStringBegin
detail: <Entity> model_air_create(modelName: <String>, origin: <Vector3>, angles: <Vector3>, speed: <Float>, accel: <Float>, decel: <Float>): <Entity>
summary: Spawns a script_model configured for 3D aerial vehicle navigation with automatic bounds inference.
///DocStringEnd
*/
model_air_create(modelName, origin, angles, speed, accel, decel)
{
	pos = isDefined(origin) ? origin : (0, 0, 0);
	ang = isDefined(angles) ? angles : (0, 0, 0);

	ent = spawn("script_model", pos);
	if (isDefined(modelName))
		ent setModel(modelName);

	ent.angles = ang;
	ent setCanDamage(true);
	ent.health = 999999;
	ent.maxHealth = 999999;

	ent model_air_nav_init(speed, accel, decel);
	return ent;
}

/*
///DocStringBegin
detail: <Entity> model_air_nav_init(speed: <Float>, accel: <Float>, decel: <Float>): <Void>
summary: Initializes aerial kinematics, physical bounds inference, and flight control state on a script_model entity.
///DocStringEnd
*/
model_air_nav_init(speed, accel, decel)
{
	if (!isDefined(self.model_air))
		self.model_air = spawnstruct();

	self.model_air.active = true;
	self.model_air.flying = true;
	self.model_air.hidden = false;

	self.model_air.custom_speed = isDefined(speed);
	self.model_air.custom_accel = isDefined(accel);
	self.model_air.custom_decel = isDefined(decel);
	self.model_air.custom_yaw = false;
	self.model_air.custom_pitch_roll = false;
	self.model_air.custom_hover = false;

	self.model_air.target_speed = MODEL_AIR_DEFAULT_SPEED;
	self.model_air.max_speed = MODEL_AIR_DEFAULT_SPEED;
	self.model_air.accel = MODEL_AIR_DEFAULT_ACCEL;
	self.model_air.decel = MODEL_AIR_DEFAULT_DECEL;
	self.model_air.yaw_speed = MODEL_AIR_DEFAULT_YAW_SPEED;
	self.model_air.max_pitch = MODEL_AIR_DEFAULT_MAX_PITCH;
	self.model_air.max_roll = MODEL_AIR_DEFAULT_MAX_ROLL;
	self.model_air.hover_amp = MODEL_AIR_DEFAULT_HOVER_AMP;
	self.model_air.hover_freq = MODEL_AIR_DEFAULT_HOVER_FREQ;
	self.model_air.angular_response = 6.0;

	self.model_air.mass_factor = 1.0;
	self.model_air.bounds_size = undefined;
	self.model_air.bounds_min = undefined;
	self.model_air.bounds_max = undefined;
	self.model_air.bounds_offset = (0, 0, 0);

	self model_air_infer_bounds_dynamics();

	if (isDefined(speed) || isDefined(accel) || isDefined(decel))
		self model_air_set_speed(speed, accel, decel);

	self.model_air.near_goal_dist = MODEL_AIR_DEFAULT_NEAR_GOAL_DIST;
	self.model_air.goal_dist = MODEL_AIR_DEFAULT_GOAL_DIST;

	self.model_air.velocity = (0, 0, 0);
	self.model_air.current_pitch = angleClamp180(self.angles[0]);
	self.model_air.current_yaw = angleClamp180(self.angles[1]);
	self.model_air.current_roll = angleClamp180(self.angles[2]);
	self.model_air.prev_speed = 0;

	self.model_air.hover_phase = randomFloatRange(0.0, 6.28);
	self.model_air.is_hovering = true;

	self.model_air.goal_pos = undefined;
	self.model_air.stop_at_goal = true;
	self.model_air.look_at_ent = undefined;
	self.model_air.look_at_pos = undefined;
	self.model_air.near_goal_notified = false;
	self.model_air.goal_notified = false;

	self.model_air.compass_icon = undefined;
	self.model_air.sound_loop = undefined;

	self thread _model_air_watch_death();
	self notify("model_air_restart_flight");
	self thread _model_air_flight_think();
}

/*
///DocStringBegin
detail: <Entity> model_air_infer_bounds_dynamics(): <Bool>
summary: Automatically queries getpointinbounds to infer physical size, centroid offset, and mass inertia.
///DocStringEnd
*/
model_air_infer_bounds_dynamics()
{
	if (!isDefined(self.model_air))
		return false;

	min = self getpointinbounds(-1, -1, -1);
	max = self getpointinbounds(1, 1, 1);

	if (!isDefined(min) || !isDefined(max))
		return false;

	size = (abs(max[0] - min[0]), abs(max[1] - min[1]), abs(max[2] - min[2]));
	diagSq = lengthSquared(size);

	if (diagSq < 100)
		return false;

	center = (min + max) * 0.5;
	boundOffset = center - self.origin;

	self.model_air.bounds_min = min;
	self.model_air.bounds_max = max;
	self.model_air.bounds_size = size;
	self.model_air.bounds_offset = boundOffset;

	effectiveSize = sqrt(diagSq);
	massFactor = effectiveSize / MODEL_AIR_REF_SIZE;
	massFactor = clamp(massFactor, 0.4, 4.5);

	self model_air_apply_mass_dynamics(massFactor);
	return true;
}

/*
///DocStringBegin
detail: <Entity> model_air_apply_mass_dynamics(massFactor: <Float>): <Void>
summary: Scales kinematics, inertia, angular responsiveness, and hover parameters based on aircraft mass.
///DocStringEnd
*/
model_air_apply_mass_dynamics(massFactor)
{
	if (!isDefined(self.model_air))
		return;

	self.model_air.mass_factor = massFactor;
	sqrtMass = sqrt(massFactor);

	if (!self.model_air.custom_accel)
		self.model_air.accel = max(MODEL_AIR_DEFAULT_ACCEL / sqrtMass, 50.0);

	if (!self.model_air.custom_decel)
		self.model_air.decel = max(MODEL_AIR_DEFAULT_DECEL / sqrtMass, 30.0);

	if (!self.model_air.custom_yaw)
		self.model_air.yaw_speed = max(MODEL_AIR_DEFAULT_YAW_SPEED / sqrtMass, 35.0);

	if (!self.model_air.custom_pitch_roll)
	{
		self.model_air.max_pitch = clamp(MODEL_AIR_DEFAULT_MAX_PITCH / sqrtMass, 16.0, 45.0);
		self.model_air.max_roll = clamp(MODEL_AIR_DEFAULT_MAX_ROLL / sqrtMass, 18.0, 50.0);
	}

	if (!self.model_air.custom_hover)
	{
		self.model_air.hover_freq = clamp(MODEL_AIR_DEFAULT_HOVER_FREQ / sqrtMass, 0.5, 2.0);
		self.model_air.hover_amp = clamp(MODEL_AIR_DEFAULT_HOVER_AMP * (0.65 + (0.35 * massFactor)), 6.0, 28.0);
	}

	self.model_air.angular_response = clamp(6.0 / sqrtMass, 2.5, 8.0);
}

/*
///DocStringBegin
detail: <Entity> model_air_set_mass_factor(massFactor: <Float>): <Void>
summary: Explicitly overrides the inferred mass factor and re-scales all un-customized kinematics.
///DocStringEnd
*/
model_air_set_mass_factor(massFactor)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	m = clamp(massFactor, 0.2, 10.0);
	self model_air_apply_mass_dynamics(m);
}

/*
///DocStringBegin
detail: <Entity> model_air_get_mass_factor(): <Float>
summary: Returns the effective mass multiplier inferred from bounds or set by developer.
///DocStringEnd
*/
model_air_get_mass_factor()
{
	if (!isDefined(self.model_air) || !isDefined(self.model_air.mass_factor))
		return 1.0;

	return self.model_air.mass_factor;
}

/*
///DocStringBegin
detail: <Entity> model_air_get_bounds_size(): <Vector3>
summary: Returns the dimensions (length, width, height) of the aircraft bounding box.
///DocStringEnd
*/
model_air_get_bounds_size()
{
	if (!isDefined(self.model_air) || !isDefined(self.model_air.bounds_size))
		return (0, 0, 0);

	return self.model_air.bounds_size;
}

/*
///DocStringBegin
detail: <Entity> model_air_get_bounds_offset(): <Vector3>
summary: Returns the 3D offset between entity origin pivot and visual/mass centroid.
///DocStringEnd
*/
model_air_get_bounds_offset()
{
	if (!isDefined(self.model_air) || !isDefined(self.model_air.bounds_offset))
		return (0, 0, 0);

	return self.model_air.bounds_offset;
}

/*
///DocStringBegin
detail: <Entity> model_air_get_bounds_center(): <Vector3>
summary: Returns the 3D world coordinates of the aircraft visual/mass centroid.
///DocStringEnd
*/
model_air_get_bounds_center()
{
	if (!isDefined(self.model_air) || !isDefined(self.model_air.bounds_offset))
		return self.origin;

	return self.origin + self.model_air.bounds_offset;
}

/*
///DocStringBegin
detail: <Entity> model_air_get_radius(): <Float>
summary: Returns the bounding radius of the aircraft for separation and proximity tests.
///DocStringEnd
*/
model_air_get_radius()
{
	if (!isDefined(self.model_air) || !isDefined(self.model_air.bounds_size))
		return 250.0;

	return length(self.model_air.bounds_size) * 0.5;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_speed(speed: <Float>, accel: <Float>, decel: <Float>): <Void>
summary: Configures cruising speed, acceleration, and deceleration (supports MPH or raw units/s).
///DocStringEnd
*/
model_air_set_speed(speed, accel, decel)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	if (isDefined(speed))
	{
		s = speed;
		if (s <= 250)
			s *= MODEL_AIR_SPEED_MPH_TO_UNITS;

		self.model_air.target_speed = s;
		self.model_air.max_speed = s;
		self.model_air.custom_speed = true;
	}

	if (isDefined(accel))
	{
		a = accel;
		if (a <= 250)
			a *= MODEL_AIR_SPEED_MPH_TO_UNITS;

		self.model_air.accel = max(a, 50.0);
		self.model_air.custom_accel = true;
	}

	if (isDefined(decel))
	{
		d = decel;
		if (d <= 250)
			d *= MODEL_AIR_SPEED_MPH_TO_UNITS;

		self.model_air.decel = max(d, 30.0);
		self.model_air.custom_decel = true;
	}
}

/*
///DocStringBegin
detail: <Entity> model_air_set_yaw_speed(yawSpeed: <Float>, accel: <Float>, decel: <Float>): <Void>
summary: Sets the angular yaw turning speed in degrees per second (overrides inferred default).
///DocStringEnd
*/
model_air_set_yaw_speed(yawSpeed, accel, decel)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.yaw_speed = isDefined(yawSpeed) ? yawSpeed : MODEL_AIR_DEFAULT_YAW_SPEED;
	self.model_air.custom_yaw = true;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_max_pitch_roll(maxPitch: <Float>, maxRoll: <Float>): <Void>
summary: Sets aerodynamic pitch tilting and banking roll limits in degrees (overrides inferred default).
///DocStringEnd
*/
model_air_set_max_pitch_roll(maxPitch, maxRoll)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.max_pitch = isDefined(maxPitch) ? maxPitch : MODEL_AIR_DEFAULT_MAX_PITCH;
	self.model_air.max_roll = isDefined(maxRoll) ? maxRoll : MODEL_AIR_DEFAULT_MAX_ROLL;
	self.model_air.custom_pitch_roll = true;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_near_goal_notify_dist(dist: <Float>): <Void>
summary: Sets the proximity threshold that triggers the 'near_goal' notify.
///DocStringEnd
*/
model_air_set_near_goal_notify_dist(dist)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.near_goal_dist = isDefined(dist) ? dist : MODEL_AIR_DEFAULT_NEAR_GOAL_DIST;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_goal_dist(dist: <Float>): <Void>
summary: Sets the arrival threshold that triggers the 'goal' notify.
///DocStringEnd
*/
model_air_set_goal_dist(dist)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.goal_dist = isDefined(dist) ? dist : MODEL_AIR_DEFAULT_GOAL_DIST;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_hover_params(amp: <Float>, freq: <Float>): <Void>
summary: Adjusts vertical bobbing amplitude (units) and frequency (Hz) while hovering (overrides inferred default).
///DocStringEnd
*/
model_air_set_hover_params(amp, freq)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.hover_amp = isDefined(amp) ? amp : MODEL_AIR_DEFAULT_HOVER_AMP;
	self.model_air.hover_freq = isDefined(freq) ? freq : MODEL_AIR_DEFAULT_HOVER_FREQ;
	self.model_air.custom_hover = true;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_goal_pos(goalPos: <Vector3>, stopAtGoal: <Bool>): <Void>
summary: Sets a 3D aerial destination point and resets arrival notifications.
///DocStringEnd
*/
model_air_set_goal_pos(goalPos, stopAtGoal)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.goal_pos = goalPos;
	self.model_air.stop_at_goal = !isDefined(stopAtGoal) || stopAtGoal;
	self.model_air.near_goal_notified = false;
	self.model_air.goal_notified = false;
}

/*
///DocStringBegin
detail: <Entity> model_air_clear_goal(): <Void>
summary: Clears current destination, transitioning flight into hover deceleration.
///DocStringEnd
*/
model_air_clear_goal()
{
	if (!isDefined(self.model_air))
		return;

	self.model_air.goal_pos = undefined;
	self.model_air.near_goal_notified = false;
	self.model_air.goal_notified = false;
}

/*
///DocStringBegin
detail: <Entity> model_air_stop(): <Void>
summary: Clears destination and brings the aircraft to an immediate smooth hover.
///DocStringEnd
*/
model_air_stop()
{
	if (!isDefined(self.model_air))
		return;

	self model_air_clear_goal();
	self.model_air.velocity = (0, 0, 0);
	self.model_air.prev_speed = 0;
	self.model_air.is_hovering = true;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_look_at_ent(ent: <Entity>): <Void>
summary: Locks aircraft yaw heading towards target entity while allowing omnidirectional flight.
///DocStringEnd
*/
model_air_set_look_at_ent(ent)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.look_at_ent = ent;
	self.model_air.look_at_pos = undefined;
}

/*
///DocStringBegin
detail: <Entity> model_air_set_look_at_pos(pos: <Vector3>): <Void>
summary: Locks aircraft yaw heading towards a 3D coordinate while allowing omnidirectional flight.
///DocStringEnd
*/
model_air_set_look_at_pos(pos)
{
	if (!isDefined(self.model_air))
		self model_air_nav_init();

	self.model_air.look_at_pos = pos;
	self.model_air.look_at_ent = undefined;
}

/*
///DocStringBegin
detail: <Entity> model_air_clear_look_at(): <Void>
summary: Clears look-at target, returning yaw alignment to forward flight direction.
///DocStringEnd
*/
model_air_clear_look_at()
{
	if (!isDefined(self.model_air))
		return;

	self.model_air.look_at_ent = undefined;
	self.model_air.look_at_pos = undefined;
}

/*
///DocStringBegin
detail: <Entity> model_air_fly_to(goalPos: <Vector3>, stopAtGoal: <Bool>, timeout: <Float>): <Bool>
summary: Synchronously commands flight to destination and blocks until arrival or timeout.
///DocStringEnd
*/
model_air_fly_to(goalPos, stopAtGoal, timeout)
{
	self endon("death");
	self endon("model_air_stop_flight");

	self model_air_set_goal_pos(goalPos, stopAtGoal);

	if (isDefined(timeout) && timeout > 0)
	{
		res = self model_air_waittill_any_timeout(timeout, "goal", "model_air_goal");
		return (res != "timeout");
	}

	self waittill_any("goal", "model_air_goal");
	return true;
}

/*
///DocStringBegin
detail: <Entity> model_air_circle_target(target: <Entity/Vector3>, radius: <Float>, altitude: <Float>, speed: <Float>, clockwise: <Bool>, duration: <Float>): <Void>
summary: Continuously orbits a target in 3D air space at designated radius and height.
///DocStringEnd
*/
model_air_circle_target(target, radius, altitude, speed, clockwise, duration)
{
	self endon("death");
	self endon("model_air_stop_flight");
	self endon("model_air_stop_circle");

	if (isDefined(speed))
		self model_air_set_speed(speed);

	rad = isDefined(radius) ? radius : 1200;
	alt = isDefined(altitude) ? altitude : MODEL_AIR_DEFAULT_FLY_HEIGHT;
	cw = !isDefined(clockwise) || clockwise;
	dirMult = cw ? 1 : -1;

	endTime = (isDefined(duration) && duration > 0) ? (getTime() + int(duration * 1000)) : 0;
	angle = 0;

	center = isDefined(target.origin) ? target.origin : target;
	initialOffset = self.origin - center;
	if (lengthSquared((initialOffset[0], initialOffset[1], 0)) > 100)
		angle = vectorToYaw(initialOffset);

	while (true)
	{
		if (endTime > 0 && getTime() >= endTime)
			break;

		center = isDefined(target.origin) ? target.origin : target;
		if (isDefined(target.origin))
			self model_air_set_look_at_ent(target);
		else
			self model_air_set_look_at_pos(target);

		angle = (angle + (18 * dirMult)) % 360;
		if (angle < 0)
			angle += 360;

		radAngle = angle * (3.14159 / 180.0);
		offset = (cos(radAngle) * rad, sin(radAngle) * rad, alt);
		goalPos = (center[0] + offset[0], center[1] + offset[1], center[2] + offset[2]);

		self model_air_set_goal_pos(goalPos, false);
		self model_air_waittill_any_timeout(0.6, "near_goal", "model_air_near_goal", "goal", "model_air_goal");
	}

	self model_air_clear_goal();
	self model_air_clear_look_at();
}

/*
///DocStringBegin
detail: <Entity> model_air_evade(evadeDir: <Vector3>, distance: <Float>, speed: <Float>): <Void>
summary: Executes an immediate high-speed evasive vector displacement.
///DocStringEnd
*/
model_air_evade(evadeDir, distance, speed)
{
	self endon("death");
	self endon("model_air_stop_flight");

	dist = isDefined(distance) ? distance : 600;
	if (isDefined(speed))
		self model_air_set_speed(speed);

	dir = vectorNormalize(evadeDir);
	evadePos = self.origin + (dir * dist);

	self model_air_set_goal_pos(evadePos, true);
	self model_air_waittill_any_timeout(1.5, "goal", "model_air_goal");
}

/*
///DocStringBegin
detail: <Entity> model_air_fly_simple_path(startNode: <Struct>): <Void>
summary: Traverses a linked aerial node path sequence, emitting arrival notifications at each node.
///DocStringEnd
*/
model_air_fly_simple_path(startNode)
{
	self endon("death");
	self endon("model_air_stop_flight");

	if (!isDefined(startNode))
		return;

	currentNode = startNode;
	while (isDefined(currentNode))
	{
		self.model_air.current_node = currentNode;
		stopAt = !isDefined(currentNode.target);
		self model_air_set_goal_pos(currentNode.origin, stopAt);

		self waittill_any("near_goal", "model_air_near_goal");

		if (isDefined(currentNode.target))
			currentNode = getstruct(currentNode.target, "targetname");
		else
			break;
	}

	self waittill_any("goal", "model_air_goal");
}

/*
///DocStringBegin
detail: <Entity> model_air_fly_loop_path(loopNode: <Struct>): <Void>
summary: Continually patrols an aerial loop sequence until interrupted.
///DocStringEnd
*/
model_air_fly_loop_path(loopNode)
{
	self endon("death");
	self endon("model_air_stop_flight");

	if (!isDefined(loopNode))
		return;

	currentNode = loopNode;
	while (true)
	{
		self.model_air.current_node = currentNode;
		self model_air_set_goal_pos(currentNode.origin, false);

		self waittill_any("near_goal", "model_air_near_goal");

		if (isDefined(currentNode.target))
			currentNode = getstruct(currentNode.target, "targetname");
		else
			break;
	}
}

/*
///DocStringBegin
detail: <Entity> model_air_reset(): <Void>
summary: Clears kinematics velocity, goals, and active targets without destroying the entity.
///DocStringEnd
*/
model_air_reset()
{
	if (!isDefined(self.model_air))
	{
		self model_air_nav_init();
		return;
	}

	self.model_air.velocity = (0, 0, 0);
	self.model_air.prev_speed = 0;
	self.model_air.goal_pos = undefined;
	self.model_air.stop_at_goal = true;
	self.model_air.look_at_ent = undefined;
	self.model_air.look_at_pos = undefined;
	self.model_air.near_goal_notified = false;
	self.model_air.goal_notified = false;
	self.model_air.is_hovering = true;
	self.model_air.path_nodes = [];
	self.model_air.path_idx = 0;
}

/*
///DocStringBegin
detail: <Entity> model_air_hide(): <Void>
summary: Hides the entity, stops flight processing, and puts it in standby for reuse.
///DocStringEnd
*/
model_air_hide()
{
	if (!isDefined(self.model_air))
		return;

	self model_air_stop();
	self.model_air.active = false;
	self.model_air.hidden = true;
	self hide();

	if (isDefined(self.model_air.compass_icon))
		self.model_air.compass_icon hide();

	self model_air_stop_sound();
	self notify("model_air_stop_flight");
}

/*
///DocStringBegin
detail: <Entity> model_air_show(origin: <Vector3>, angles: <Vector3>): <Void>
summary: Reactivates and unhides a pooled script_model entity at the specified position.
///DocStringEnd
*/
model_air_show(origin, angles)
{
	if (isDefined(origin))
		self.origin = origin;

	if (isDefined(angles))
		self.angles = angles;

	self show();

	if (!isDefined(self.model_air))
		self model_air_nav_init();
	else
	{
		self.model_air.active = true;
		self.model_air.hidden = false;
		self model_air_reset();

		if (isDefined(self.model_air.compass_icon))
			self.model_air.compass_icon show();

		if (isDefined(self.model_air.sound_loop))
			self playLoopSound(self.model_air.sound_loop);

		self.model_air.current_pitch = angleClamp180(self.angles[0]);
		self.model_air.current_yaw = angleClamp180(self.angles[1]);
		self.model_air.current_roll = angleClamp180(self.angles[2]);
		self notify("model_air_restart_flight");
		self thread _model_air_flight_think();
	}
}

/*
///DocStringBegin
detail: <Void> model_air_pool_init(poolName: <String>, modelName: <String>, maxCount: <Int>): <Void>
summary: Pre-allocates a pool of hidden script_models to eliminate vehicle allocation overflow.
///DocStringEnd
*/
model_air_pool_init(poolName, modelName, maxCount)
{
	if (!isDefined(level.model_air_pools))
		level.model_air_pools = [];

	pool = spawnstruct();
	pool.name = poolName;
	pool.model_name = modelName;
	pool.max_count = isDefined(maxCount) ? maxCount : 4;
	pool.items = [];

	level.model_air_pools[poolName] = pool;

	for (i = 0; i < pool.max_count; i++)
	{
		ent = model_air_create(modelName, (0, 0, -10000), (0, 0, 0));
		ent model_air_hide();
		ent.pool_name = poolName;
		pool.items[pool.items.size] = ent;
	}
}

/*
///DocStringBegin
detail: <Entity> model_air_pool_get(poolName: <String>, origin: <Vector3>, angles: <Vector3>): <Entity>
summary: Fetches an idle script_model from the pool or allocates a new one if pool expands.
///DocStringEnd
*/
model_air_pool_get(poolName, origin, angles)
{
	if (!isDefined(level.model_air_pools) || !isDefined(level.model_air_pools[poolName]))
		return undefined;

	pool = level.model_air_pools[poolName];
	foreach (item in pool.items)
	{
		if (isDefined(item) && item.model_air.hidden)
		{
			item model_air_show(origin, angles);
			return item;
		}
	}

	ent = model_air_create(pool.model_name, origin, angles);
	ent.pool_name = poolName;
	pool.items[pool.items.size] = ent;
	return ent;
}

/*
///DocStringBegin
detail: <Void> model_air_pool_release(ent: <Entity>): <Void>
summary: Recycles an active entity back into its pool, safely hiding it without deletion.
///DocStringEnd
*/
model_air_pool_release(ent)
{
	if (!isDefined(ent))
		return;

	ent model_air_hide();
}

/*
///DocStringBegin
detail: <Array> model_air_get_nodes(flyHeight: <Float>): <Array>
summary: Retrieves native aerial nodes, or synthesizes a 3D aerial grid from ground waypoints.
///DocStringEnd
*/
model_air_get_nodes(flyHeight)
{
	if (isDefined(level.air_node_mesh) && level.air_node_mesh.size > 0)
		return level.air_node_mesh;

	if (isDefined(level.heli_nodes) && level.heli_nodes.size > 0)
		return level.heli_nodes;

	if (isDefined(level.heli_start_nodes) && level.heli_start_nodes.size > 0)
		return level.heli_start_nodes;

	if (isDefined(level.model_air_synthetic_nodes) && level.model_air_synthetic_nodes.size > 0)
		return level.model_air_synthetic_nodes;

	return _model_air_build_synthetic_nodes(flyHeight);
}

/*
///DocStringBegin
detail: <Struct> model_air_get_closest_node(pos: <Vector3>, nodes: <Array>): <Struct>
summary: Finds the closest aerial node to the given position in 2D/3D space.
///DocStringEnd
*/
model_air_get_closest_node(pos, nodes)
{
	nodeList = isDefined(nodes) ? nodes : model_air_get_nodes();
	if (!isDefined(nodeList) || !nodeList.size)
		return undefined;

	bestNode = undefined;
	bestDistSq = 999999999;

	foreach (node in nodeList)
	{
		if (!isDefined(node) || !isDefined(node.origin))
			continue;

		dSq = distanceSquared((node.origin[0], node.origin[1], 0), (pos[0], pos[1], 0));
		if (dSq < bestDistSq)
		{
			bestDistSq = dSq;
			bestNode = node;
		}
	}

	return bestNode;
}

/*
///DocStringBegin
detail: <Struct> model_air_get_random_node(nodes: <Array>): <Struct>
summary: Returns a random node from the aerial mesh.
///DocStringEnd
*/
model_air_get_random_node(nodes)
{
	nodeList = isDefined(nodes) ? nodes : model_air_get_nodes();
	if (!isDefined(nodeList) || !nodeList.size)
		return undefined;

	return nodeList[randomInt(nodeList.size)];
}

/*
///DocStringBegin
detail: <Array> _model_air_build_synthetic_nodes(flyHeight: <Float>): <Array>
summary: Synthesizes aerial node structures by elevating spaced ground waypoints to flight height.
///DocStringEnd
*/
_model_air_build_synthetic_nodes(flyHeight)
{
	lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return [];

	alt = isDefined(flyHeight) ? flyHeight : MODEL_AIR_DEFAULT_FLY_HEIGHT;
	level.model_air_synthetic_nodes = [];

	spacingSq = MODEL_AIR_SYNTHETIC_SPACING * MODEL_AIR_SYNTHETIC_SPACING;

	for (i = 0; i < level.waypoints.size; i++)
	{
		wp = level.waypoints[i];
		if (!isDefined(wp) || !isDefined(wp.origin))
			continue;

		tooClose = false;
		foreach (existing in level.model_air_synthetic_nodes)
		{
			if (distanceSquared((existing.origin[0], existing.origin[1], 0), (wp.origin[0], wp.origin[1], 0)) < spacingSq)
			{
				tooClose = true;
				break;
			}
		}

		if (tooClose)
			continue;

		node = spawnstruct();
		node.origin = (wp.origin[0], wp.origin[1], wp.origin[2] + alt);
		node.angles = (0, randomInt(360), 0);
		node.neighbors = [];
		node.index = level.model_air_synthetic_nodes.size;

		level.model_air_synthetic_nodes[level.model_air_synthetic_nodes.size] = node;
	}

	foreach (nodeA in level.model_air_synthetic_nodes)
	{
		foreach (nodeB in level.model_air_synthetic_nodes)
		{
			if (nodeA == nodeB)
				continue;

			d = distance(nodeA.origin, nodeB.origin);
			if (d <= (MODEL_AIR_SYNTHETIC_SPACING * 2.2))
				nodeA.neighbors[nodeA.neighbors.size] = nodeB;
		}
	}

	return level.model_air_synthetic_nodes;
}

/*
///DocStringBegin
detail: <Entity> _model_air_flight_think(): <Void>
summary: 20Hz aerodynamic physics simulation loop handling velocity, banking, pitch, and hover.
///DocStringEnd
*/
_model_air_flight_think()
{
	self endon("death");
	self endon("model_air_stop_flight");
	self endon("model_air_restart_flight");

	dt = MODEL_AIR_TICK;

	while (self.model_air.active)
	{
		wait dt;

		if (self.model_air.hidden)
			continue;

		if (!isDefined(self.model_air.bounds_size))
			self model_air_infer_bounds_dynamics();

		currentSpeed = length(self.model_air.velocity);
		desiredVelocity = (0, 0, 0);
		desiredSpeed = 0;

		if (isDefined(self.model_air.goal_pos))
		{
			toGoal = self.model_air.goal_pos - self.origin;
			dist = length(toGoal);

			if (dist <= self.model_air.near_goal_dist && !self.model_air.near_goal_notified)
			{
				self.model_air.near_goal_notified = true;
				self notify("near_goal");
				self notify("model_air_near_goal");
			}

			if (dist <= self.model_air.goal_dist)
			{
				if (!self.model_air.goal_notified)
				{
					self.model_air.goal_notified = true;
					self notify("goal");
					self notify("model_air_goal");
				}

				if (self.model_air.stop_at_goal)
				{
					self.model_air.goal_pos = undefined;
					desiredSpeed = 0;
					desiredVelocity = (0, 0, 0);
				}
				else
				{
					desiredSpeed = self.model_air.target_speed;
					desiredVelocity = vectorNormalize(toGoal) * desiredSpeed;
				}
			}
			else
			{
				goalDir = vectorNormalize(toGoal);
				if (self.model_air.stop_at_goal)
				{
					brakingDist = (currentSpeed * currentSpeed) / (2.0 * max(self.model_air.decel, 20.0)) + self.model_air.goal_dist;
					if (dist <= brakingDist)
						desiredSpeed = max(currentSpeed - (self.model_air.decel * dt), 60.0);
					else
						desiredSpeed = min(currentSpeed + (self.model_air.accel * dt), self.model_air.target_speed);
				}
				else
					desiredSpeed = min(currentSpeed + (self.model_air.accel * dt), self.model_air.target_speed);

				desiredVelocity = goalDir * desiredSpeed;
			}
		}

		velDelta = desiredVelocity - self.model_air.velocity;
		velDeltaLen = length(velDelta);
		if (velDeltaLen > 0.01)
		{
			rate = (desiredSpeed >= currentSpeed) ? self.model_air.accel : self.model_air.decel;
			step = rate * dt;
			if (step >= velDeltaLen)
				self.model_air.velocity = desiredVelocity;
			else
				self.model_air.velocity += vectorNormalize(velDelta) * step;
		}

		currentSpeed = length(self.model_air.velocity);
		self.model_air.is_hovering = (currentSpeed < MODEL_AIR_HOVER_MAX_SPEED);

		desiredYaw = self.model_air.current_yaw;
		if (isDefined(self.model_air.look_at_ent) && isAlive(self.model_air.look_at_ent))
		{
			lookDelta = self.model_air.look_at_ent.origin - self.origin;
			if (lengthSquared((lookDelta[0], lookDelta[1], 0)) > 4)
				desiredYaw = vectorToYaw(lookDelta);
		}
		else if (isDefined(self.model_air.look_at_pos))
		{
			lookDelta = self.model_air.look_at_pos - self.origin;
			if (lengthSquared((lookDelta[0], lookDelta[1], 0)) > 4)
				desiredYaw = vectorToYaw(lookDelta);
		}
		else if (currentSpeed > 50)
		{
			horizontalVel = (self.model_air.velocity[0], self.model_air.velocity[1], 0);
			if (lengthSquared(horizontalVel) > 4)
				desiredYaw = vectorToYaw(horizontalVel);
		}

		yawDiff = angleClamp180(desiredYaw - self.model_air.current_yaw);
		maxYawStep = self.model_air.yaw_speed * dt;
		actualYawTurn = clamp(yawDiff, -maxYawStep, maxYawStep);
		self.model_air.current_yaw = angleClamp180(self.model_air.current_yaw + actualYawTurn);
		turnRate = actualYawTurn / dt;

		forwardDir = anglesToForward((0, self.model_air.current_yaw, 0));
		forwardSpeed = vectorDot(self.model_air.velocity, forwardDir);
		normForward = forwardSpeed / max(self.model_air.max_speed, 1.0);
		basePitch = normForward * 16.0;

		speedDelta = (currentSpeed - self.model_air.prev_speed) / dt;
		accelPitch = clamp((speedDelta / max(self.model_air.accel, 1.0)) * 12.0, -15.0, 15.0);
		targetPitch = clamp(basePitch + accelPitch, -self.model_air.max_pitch, self.model_air.max_pitch);

		angResp = isDefined(self.model_air.angular_response) ? self.model_air.angular_response : 6.0;
		self.model_air.current_pitch += (targetPitch - self.model_air.current_pitch) * min(1.0, dt * angResp);

		speedFactor = currentSpeed / max(self.model_air.max_speed, 1.0);
		turnRoll = (turnRate / max(self.model_air.yaw_speed, 1.0)) * self.model_air.max_roll * speedFactor;

		rightDir = anglesToRight((0, self.model_air.current_yaw, 0));
		lateralSpeed = vectorDot(self.model_air.velocity, rightDir);
		lateralRoll = (lateralSpeed / max(self.model_air.max_speed, 1.0)) * 25.0;

		targetRoll = clamp(turnRoll + lateralRoll, -self.model_air.max_roll, self.model_air.max_roll);
		self.model_air.current_roll += (targetRoll - self.model_air.current_roll) * min(1.0, dt * angResp);

		hoverBobZ = 0;
		swayPitch = 0;
		swayRoll = 0;

		if (self.model_air.is_hovering)
		{
			hoverDamp = 1.0 - clamp(currentSpeed / MODEL_AIR_HOVER_MAX_SPEED, 0.0, 1.0);
			t = getTime() * 0.001;
			phase = self.model_air.hover_phase;
			hoverBobZ = sin((t * self.model_air.hover_freq * 3.14159) + phase) * self.model_air.hover_amp * hoverDamp;
			swayPitch = cos((t * self.model_air.hover_freq * 2.3) + phase) * 1.5 * hoverDamp;
			swayRoll = sin((t * self.model_air.hover_freq * 1.8) + phase) * 2.2 * hoverDamp;
		}

		finalPitch = angleClamp180(self.model_air.current_pitch + swayPitch);
		finalYaw = angleClamp180(self.model_air.current_yaw);
		finalRoll = angleClamp180(self.model_air.current_roll + swayRoll);
		finalAngles = (finalPitch, finalYaw, finalRoll);

		displacement = self.model_air.velocity * dt;
		if (self.model_air.is_hovering)
			displacement += (0, 0, hoverBobZ * dt * 2.5);

		nextOrigin = self.origin + displacement;

		self.model_air.prev_speed = currentSpeed;

		self moveTo(nextOrigin, dt + 0.01);
		self rotateTo(finalAngles, dt + 0.01);
	}
}


/*
///DocStringBegin
detail: <Entity> model_air_waittill_any_timeout(timeout: <Float>, s1?: <String>, s2?: <String>, s3?: <String>, s4?: <String>, s5?: <String>): <String>
summary: Waits for any notify or timeout duration, safe for MP engines lacking waittill_any_timeout.
///DocStringEnd
*/
model_air_waittill_any_timeout(timeout, s1, s2, s3, s4, s5)
{
	self endon("death");

	ent = spawnstruct();
	if (isDefined(s1)) self thread _model_air_waittill_msg(s1, ent);
	if (isDefined(s2)) self thread _model_air_waittill_msg(s2, ent);
	if (isDefined(s3)) self thread _model_air_waittill_msg(s3, ent);
	if (isDefined(s4)) self thread _model_air_waittill_msg(s4, ent);
	if (isDefined(s5)) self thread _model_air_waittill_msg(s5, ent);

	ent thread _model_air_timeout_wait(timeout);
	ent waittill("returned", msg);
	ent notify("die");
	return msg;
}

_model_air_waittill_msg(msg, ent)
{
	self endon("death");
	ent endon("die");
	self waittill(msg);
	ent notify("returned", msg);
}

_model_air_timeout_wait(delay)
{
	self endon("die");
	wait delay;
	self notify("returned", "timeout");
}

/*
///DocStringBegin
detail: <Entity> model_air_setup_minimap_icon(owner?: <Entity>, iconFriendly?: <String>, iconEnemy?: <String>): <Entity>
summary: Spawns a spawnPlane entity linked to the model to display it on the minimap/compass.
///DocStringEnd
*/
model_air_setup_minimap_icon(owner, iconFriendly, iconEnemy)
{
	if (!isDefined(self.model_air))
		return undefined;

	if (isDefined(self.model_air.compass_icon))
		self.model_air.compass_icon delete();

	own = isDefined(owner) ? owner : (isDefined(self.owner) ? self.owner : level.players[0]);
	fIcon = isDefined(iconFriendly) ? iconFriendly : "compass_objicon_airdrop";
	eIcon = isDefined(iconEnemy) ? iconEnemy : fIcon;

	compassIcon = spawnPlane(own, "script_model", self.origin, fIcon, eIcon);
	if (isDefined(compassIcon))
	{
		compassIcon notSolid();
		compassIcon linkTo(self, "tag_origin", (0, 0, 0), (0, 0, 0));
		self.model_air.compass_icon = compassIcon;
	}

	return compassIcon;
}

/*
///DocStringBegin
detail: <Void> model_air_remove_minimap_icon(): <Void>
summary: Deletes the linked minimap compass icon.
///DocStringEnd
*/
model_air_remove_minimap_icon()
{
	if (!isDefined(self.model_air))
		return;

	if (isDefined(self.model_air.compass_icon))
	{
		self.model_air.compass_icon delete();
		self.model_air.compass_icon = undefined;
	}
}

/*
///DocStringBegin
detail: <Void> model_air_start_sound(soundAlias?: <String>): <Void>
summary: Starts an engine rotor flight sound loop on the aircraft.
///DocStringEnd
*/
model_air_start_sound(soundAlias)
{
	if (!isDefined(self.model_air))
		return;

	if (isDefined(self.model_air.sound_loop))
		self stopLoopSound();

	sound = isDefined(soundAlias) ? soundAlias : self _model_air_resolve_sound();
	self.model_air.sound_loop = sound;
	self playLoopSound(sound);
}

/*
///DocStringBegin
detail: <Void> model_air_stop_sound(): <Void>
summary: Stops active engine rotor sound loop.
///DocStringEnd
*/
model_air_stop_sound()
{
	if (!isDefined(self.model_air))
		return;

	self stopLoopSound();
	self.model_air.sound_loop = undefined;
}

_model_air_resolve_sound()
{
	m = isDefined(self.model) ? self.model : "";
	if (isSubStr(m, "pavelow") || isSubStr(m, "mi17"))
		return "mp_pavelow_engine_loop";
	if (isSubStr(m, "uav") || isSubStr(m, "ac130") || isSubStr(m, "c130"))
		return "airdrop_plane_flyby";
	if (isSubStr(m, "apache") || isSubStr(m, "hind") || isSubStr(m, "cobra"))
		return "cobra_helicopter_run";

	return "mp_warig_heli_loop";
}

/*
///DocStringBegin
detail: <Void> model_air_start_lights_fx(): <Void>
summary: Spawns blinking navigation strobe light FX attached to the aircraft model.
///DocStringEnd
*/
model_air_start_lights_fx()
{
	self endon("death");
	self endon("model_air_stop_flight");

	if (!isDefined(level._model_air_fx_init))
	{
		level._model_air_fx_init = true;
		level._model_air_fx_white = loadfx("misc/aircraft_light_white_blink");
		level._model_air_fx_red = loadfx("misc/aircraft_light_red_blink_occ");
	}

	if (isDefined(level._model_air_fx_white))
		playFXOnTag(level._model_air_fx_white, self, "tag_origin");

	if (isDefined(level._model_air_fx_red))
	{
		playFXOnTag(level._model_air_fx_red, self, "tag_light_belly");
		playFXOnTag(level._model_air_fx_red, self, "tag_light_tail1");
	}
}

_model_air_watch_death()
{
	self waittill("death");
	if (isDefined(self.model_air))
	{
		if (isDefined(self.model_air.compass_icon))
			self.model_air.compass_icon delete();

		self stopLoopSound();
	}
}
