/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : config           |
|Creator : LastDemon99	   |
|Type : Configuration      |
============================
*/

_botConfigSpec()
{
	if (isDefined(level.botactor_config_spec))
		return level.botactor_config_spec;

	spec = [];
	spec = _botConfigDefine(spec, "move_tick_ms", 50, 50, 200);
	spec = _botConfigDefine(spec, "move_block_trace_ms", 150, 50, 2000);
	spec = _botConfigDefine(spec, "lite_move_ms", 100, 50, 500);
	spec = _botConfigDefine(spec, "chase_tick_ms", 200, 80, 2000);
	spec = _botConfigDefine(spec, "chase_repath_dist", 160, 64, 4000);
	spec = _botConfigDefine(spec, "edge_fail_ttl_ms", 9000, 2000, 120000);
	spec = _botConfigDefine(spec, "path_searches_per_tick", 3, 0, 64);
	spec = _botConfigDefine(spec, "escape_backstep", 1, 0, 1);
	spec = _botConfigDefine(spec, "cover_nodes", 1, 0, 1);
	spec = _botConfigDefine(spec, "lite_target_ms", 100, 50, 500);
	spec = _botConfigDefine(spec, "lite_simple_sight", 1, 0, 1);
	spec = _botConfigDefine(spec, "enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "full_max_per_target", 6, 0, 64);
	spec = _botConfigDefine(spec, "cover_max_per_target", 2, 0, 64);
	spec = _botConfigDefine(spec, "cover_congestion_start", 2, 0, 64);
	spec = _botConfigDefine(spec, "plan_interval_ms", 500, 100, 10000);
	spec = _botConfigDefine(spec, "lite_update_ms", 700, 250, 10000);
	spec = _botConfigDefine(spec, "lite_nav_stale_ms", 900, 300, 10000);
	spec = _botConfigDefine(spec, "cover_search_ms", 1200, 250, 20000);
	spec = _botConfigDefine(spec, "cover_searches_per_tick", 2, 0, 32);
	spec = _botConfigDefine(spec, "route_memory_ms", 7000, 1000, 120000);
	spec = _botConfigDefine(spec, "flank_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "flank_mode", 1, 0, 2);
	spec = _botConfigDefine(spec, "corridor_refresh_ms", 4000, 500, 60000);
	spec = _botConfigDefine(spec, "corridor_move_dist", 512, 64, 8000);
	spec = _botConfigDefine(spec, "flank_max_per_side", 1, 0, 16);
	spec = _botConfigDefine(spec, "flank_priority", 90, 0, 1000);
	spec = _botConfigDefine(spec, "flank_hold_ms", 5500, 500, 60000);
	spec = _botConfigDefine(spec, "flank_after_ms", 2600, 500, 60000);
	spec = _botConfigDefine(spec, "hunt_route_steps", 3, 0, 8);
	spec = _botConfigDefine(spec, "contact_dot", 72, 0, 100);
	spec = _botConfigDefine(spec, "contact_dist", 520, 256, 20000);
	spec = _botConfigDefine(spec, "pressure_dist", 900, 384, 20000);
	spec = _botConfigDefine(spec, "cover_max_dist", 650, 256, 20000);

	spec = _botConfigDefine(spec, "grenade_flee", 1, 0, 1);
	spec = _botConfigDefine(spec, "grenade_flee_pct", 75, 0, 100);
	spec = _botConfigDefine(spec, "grenade_radius", 420, 96, 2000);
	spec = _botConfigDefine(spec, "grenade_same_threat_dist", 220, 32, 2000);
	spec = _botConfigDefine(spec, "grenade_flee_dist", 320, 128, 4000);
	spec = _botConfigDefine(spec, "grenade_tick_ms", 250, 50, 2000);
	spec = _botConfigDefine(spec, "grenade_windup_min_ms", 150, 0, 5000);
	spec = _botConfigDefine(spec, "grenade_windup_max_ms", 900, 0, 5000);
	spec = _botConfigDefine(spec, "grenade_cooldown_ms", 3000, 0, 30000);
	spec = _botConfigDefine(spec, "grenade_debug", 0, 0, 1);
	spec = _botConfigDefine(spec, "goap_debug", 0, 0, 1);

	spec = _botConfigDefine(spec, "claymore_enabled", 0, 0, 1);
	spec = _botConfigDefine(spec, "claymore_tick_ms", 900, 200, 10000);
	spec = _botConfigDefine(spec, "claymore_node_dist", 160, 32, 1024);
	spec = _botConfigDefine(spec, "claymore_cooldown_ms", 20000, 1000, 300000);
	spec = _botConfigDefine(spec, "claymore_max_per_life", 2, 0, 10);

	spec = _botConfigDefine(spec, "hunter_assign_ms", 700, 100, 10000);
	spec = _botConfigDefine(spec, "hunter_corridors", 1, 0, 1);

	// Smart Bot sensory options
	spec = _botConfigDefine(spec, "sense_fov_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "sense_audio_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "sense_audio_range", 750, 100, 5000);
	spec = _botConfigDefine(spec, "sense_cqc_spot_dist", 140, 0, 1000);

	// Smart Bot tactical reload options
	spec = _botConfigDefine(spec, "reload_tactical_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "reload_clip_threshold", 50, 10, 90);
	spec = _botConfigDefine(spec, "reload_quiet_time_ms", 2000, 500, 10000);
	spec = _botConfigDefine(spec, "reload_evade_strafe_chance", 50, 0, 100);
	spec = _botConfigDefine(spec, "switch_secondary_on_empty", 1, 0, 1);

	// Smart Bot suppression fire options
	spec = _botConfigDefine(spec, "suppress_fire_enabled", 1, 0, 1);

	// Smart Bot stun & flashbang reaction options
	spec = _botConfigDefine(spec, "stun_reaction_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "stun_spray_chance", 35, 0, 100);

	// Smart Bot damage alert & critical health options
	spec = _botConfigDefine(spec, "damage_alert_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "health_critical_pct", 30, 0, 100);

	// Smart Bot CQC spacing & backpedal options
	spec = _botConfigDefine(spec, "cqc_backpedal_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "cqc_backpedal_dist", 200, 64, 600);

	// Spatial Cells & Congestion Avoidance
	spec = _botConfigDefine(spec, "cell_rules_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "cell_grid_size", 400, 150, 1200);
	spec = _botConfigDefine(spec, "cell_congestion_penalty", 150, 0, 500);
	spec = _botConfigDefine(spec, "cell_max_bots_per_cell", 2, 1, 8);

	// Macro-Zones & Portal Flanking
	spec = _botConfigDefine(spec, "zone_nav_enabled", 1, 0, 1);
	spec = _botConfigDefine(spec, "zone_cluster_size", 800, 400, 2000);
	spec = _botConfigDefine(spec, "zone_macro_dist", 650, 250, 3000);
	spec = _botConfigDefine(spec, "zone_union_max_bots", 2, 1, 8);
	spec = _botConfigDefine(spec, "zone_flank_random_pct", 50, 0, 100);

	level.botactor_config_spec = spec;
	return spec;
}

_botConfigDefine(spec, name, defaultValue, minValue, maxValue)
{
	entry = spawnstruct();
	entry.name = name;
	entry.def = defaultValue;
	entry.min = minValue;
	entry.max = maxValue;
	spec[name] = entry;
	return spec;
}

/*
///DocStringBegin
detail: bot_config_spec(name: <String>): <Struct | Undefined>
summary: Returns option metadata specification or undefined if not found.
///DocStringEnd
*/
bot_config_spec(name)
{
	if (!isDefined(name)) return undefined;
	spec = _botConfigSpec();
	return spec[name];
}

/*
///DocStringBegin
detail: bot_config_clamp(name: <String>, value: <Int>): <Int | Undefined>
summary: Clamps a value to the option's configured bounds.
///DocStringEnd
*/
bot_config_clamp(name, value)
{
	entry = bot_config_spec(name);
	if (!isDefined(entry) || !isDefined(value))
		return undefined;

	v = int(value);
	if (v < entry.min) v = entry.min;
	if (entry.max >= 0 && v > entry.max) v = entry.max;
	return v;
}

/*
///DocStringBegin
detail: bot_config_get(name: <String>): <Int>
summary: Returns current global value for an option or its default.
///DocStringEnd
*/
bot_config_get(name)
{
	entry = bot_config_spec(name);
	if (!isDefined(entry))
		return 0;

	if (isDefined(level.botactor_config) && isDefined(level.botactor_config[name]))
		return level.botactor_config[name];

	return entry.def;
}

/*
///DocStringBegin
detail: bot_config_set(name: <String>, value: <Int | Undefined>): <Bool>
summary: Sets an option globally within its bounds. Passing undefined resets to default.
///DocStringEnd
*/
bot_config_set(name, value)
{
	entry = bot_config_spec(name);
	if (!isDefined(entry))
		return false;

	if (!isDefined(level.botactor_config))
		level.botactor_config = [];

	if (!isDefined(value))
	{
		level.botactor_config[name] = undefined;
		return true;
	}

	clamped = bot_config_clamp(name, value);
	level.botactor_config[name] = clamped;
	return true;
}

/*
///DocStringBegin
detail: bot_config_reset(): <Void>
summary: Resets all global overrides back to code defaults.
///DocStringEnd
*/
bot_config_reset()
{
	level.botactor_config = [];
}

/*
///DocStringBegin
detail: bot_config_from_dvar(name: <String>, dvarName: <String>): <Bool>
summary: Reads a dvar value once and stores it as an option if defined.
///DocStringEnd
*/
bot_config_from_dvar(name, dvarName)
{
	if (!isDefined(name) || !isDefined(dvarName))
		return false;

	if (getDvar(dvarName) == "")
		return false;

	return bot_config_set(name, getDvarInt(dvarName));
}

/*
///DocStringBegin
detail: bot_config_print(): <Void>
summary: Prints current values for all configuration options.
///DocStringEnd
*/
bot_config_print()
{
	spec = _botConfigSpec();
	print("=== BOTACTOR_CONFIG ===");

	foreach (name in getArrayKeys(spec))
	{
		entry = spec[name];
		source = "default";
		if (isDefined(level.botactor_config) && isDefined(level.botactor_config[name]))
			source = "set";

		print("BOTACTOR_CONFIG", name, bot_config_get(name), source, "range", entry.min, entry.max);
	}
}
