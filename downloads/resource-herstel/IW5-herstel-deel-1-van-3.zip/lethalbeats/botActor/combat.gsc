/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : combat           |
|Creator : LastDemon99	   |
|Type : AI                 |
============================
*/

#include lethalbeats\botactor\utility;

#define SCRIPT_MOVE 3
#define MOVE_LOOK_MODE 46
#define MOVE_LOOK_DIR 45
#define MELEE_CHARGE 33
#define CHASE_TARGET 22
#define BEHAVIOR_STRAFE 100
#define BEHAVIOR_NADE 101
#define BEHAVIOR_SPRINT 102
#define BEHAVIOR_CROUCH 103
#define BEHAVIOR_JUMP 104
#define BEHAVIOR_QUICKSCOPE 105
#define BEHAVIOR_DROPSHOT 118
#define FIRE_TIME 110
#define MIN_SHOTS 111
#define MAX_SHOTS 112
#define MIN_PAUSE 113
#define MAX_PAUSE 114
#define WIND_UP_TIME 115
#define LAST_FIRE_TIME 116
#define PATH_LOCK 4

#define SKILL_REACTION_TIME 62
#define SKILL_SEMI_TIME 79

/*
///DocStringBegin
detail: _botCombatGetWeaponClass(currentWeapon): <String>
summary: Returns weapon class for combat decisions.
///DocStringEnd
*/
_botCombatGetWeaponClass(currentWeapon)
{
	if (!isDefined(currentWeapon) || currentWeapon == "none")
		return "";

	baseName = lethalbeats\weapon::weapon_get_baseName(currentWeapon);
	return lethalbeats\weapon::weapon_get_class(baseName);
}

/*
///DocStringBegin
detail: _botCombatTryMelee(state, now, target, distSq, weaponClass, canAttackByFov): <Bool>
summary: Evaluates and executes melee attacks; returns true if melee action was taken.
///DocStringEnd
*/
_botCombatTryMelee(state, now, target, distSq, weaponClass, canAttackByFov)
{
	if (isPlayer(target) && (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand)))
		return false;

	isRiot = (weaponClass == "riot");
	trueMeleeDist = isRiot ? 96 : 72;
	meleeSq = trueMeleeDist * trueMeleeDist;

	if (distSq > meleeSq)
		return false;

	if (self.actor[PATH_LOCK])
		return false;

	if (!canAttackByFov)
		return false;

	if (!isDefined(state.nextMeleeTime))
		state.nextMeleeTime = 0;
	if (!isDefined(state.nextReactTime))
		state.nextReactTime = 0;

	if (now >= state.nextReactTime && now >= state.nextMeleeTime)
	{
		self bot_release_fire();
		self bot_press_melee();
		state.nextMeleeTime = now + 650;

		reactionRaw = self bot_get_skill(SKILL_REACTION_TIME, 0);
		reactionMs = isDefined(reactionRaw) && reactionRaw > 50 ? int(reactionRaw) : int(float(reactionRaw) * 1000);
		state.nextReactTime = now + max(reactionMs, 0);
		return true;
	}

	if (isRiot)
	{
		self bot_release_fire();
		return true;
	}

	return false;
}

/*
///DocStringBegin
detail: _botCombatTryBehaviors(state, now, target, hasLos): <Void>
summary: Executes probabilistic combat behaviors such as strafing, grenades, or jumping.
///DocStringEnd
*/
_botCombatTryBehaviors(state, now, target, hasLos)
{
	if (!isDefined(self) || !isPlayer(self))
		return;

	alive = isAlive(self);
	if (!isDefined(alive) || !alive)
		return;

	if (!isDefined(self.actor) || !isDefined(state))
		return;

	if (!isDefined(target) || !isDefined(target.origin))
		return;

	if (!isDefined(hasLos) || !hasLos)
		return;

	if (!isDefined(now))
		now = gettime();

	if (!isDefined(state.nextBehaviorStrafe)) state.nextBehaviorStrafe = 0;
	if (!isDefined(state.nextBehaviorNade)) state.nextBehaviorNade = 0;
	if (!isDefined(state.nextBehaviorSprint)) state.nextBehaviorSprint = 0;
	if (!isDefined(state.nextBehaviorCrouch)) state.nextBehaviorCrouch = 0;
	if (!isDefined(state.nextBehaviorJump)) state.nextBehaviorJump = 0;
	if (!isDefined(state.nextBehaviorDropshot)) state.nextBehaviorDropshot = 0;

	strafePct = int(isDefined(self.actor[BEHAVIOR_STRAFE]) ? self.actor[BEHAVIOR_STRAFE] : 0);
	nadePct = int(isDefined(self.actor[BEHAVIOR_NADE]) ? self.actor[BEHAVIOR_NADE] : 0);
	sprintPct = int(isDefined(self.actor[BEHAVIOR_SPRINT]) ? self.actor[BEHAVIOR_SPRINT] : 0);
	crouchPct = int(isDefined(self.actor[BEHAVIOR_CROUCH]) ? self.actor[BEHAVIOR_CROUCH] : 0);
	jumpPct = int(isDefined(self.actor[BEHAVIOR_JUMP]) ? self.actor[BEHAVIOR_JUMP] : 0);
	dropshotPct = int(isDefined(self.actor[BEHAVIOR_DROPSHOT]) ? self.actor[BEHAVIOR_DROPSHOT] : 0);

	goapControlsMove = isDefined(self.goap) && isDefined(self.goap.current_action);
	curStance = isDefined(self.ba) && isDefined(self.ba.stance) ? self.ba.stance : self getStance();
	distSq = distanceSquared(self.origin, target.origin);

	if (self lethalbeats\botactor\utility::bot_is_stunned())
	{
		self bot_release_ads();
		return;
	}

	if (self lethalbeats\botactor\utility::bot_is_reloading())
	{
		evadeChance = lethalbeats\botactor\config::bot_config_get("reload_evade_strafe_chance");
		if (!goapControlsMove && evadeChance > 0 && randomint(100) < evadeChance && !isDefined(self.actor["strafe_active"]))
		{
			strafeDir = (randomint(2) * 2 - 1) * 127;
			self thread _botCombatDoStrafe(strafeDir);
		}
		return;
	}

	// Strafe behavior: evaluate pacing window once per cooldown
	if (!goapControlsMove && strafePct > 0 && now >= state.nextBehaviorStrafe)
	{
		state.nextBehaviorStrafe = now + randomIntRange(3000, 5000);
		if (randomint(100) < strafePct)
		{
			strafeDir = (randomint(2) * 2 - 1) * 127;
			self thread _botCombatDoStrafe(strafeDir);
		}
	}

	// Dropshot behavior: evaluate in medium range window
	if (!goapControlsMove && dropshotPct > 0 && now >= state.nextBehaviorDropshot && distSq >= 200 * 200 && distSq <= 900 * 900)
	{
		state.nextBehaviorDropshot = now + randomIntRange(5000, 8000);
		if (randomint(100) < dropshotPct)
		{
			self thread _botCombatDoDropshot();
		}
	}

	// Nade behavior
	if (nadePct > 0 && now >= state.nextBehaviorNade)
	{
		state.nextBehaviorNade = now + randomIntRange(6000, 10000);
		if (randomint(100) < nadePct)
		{
			self bot_press_frag(0.2);
			self notify("bot_behavior_nade", target);
		}
	}

	// Sprint behavior
	if (sprintPct > 0 && now >= state.nextBehaviorSprint && !self.actor[SCRIPT_MOVE])
	{
		state.nextBehaviorSprint = now + randomIntRange(3000, 5500);
		if (randomint(100) < sprintPct)
		{
			self bot_press_sprint(0.2);
			self notify("bot_behavior_sprint", target);
		}
	}

	// Crouch behavior
	if (crouchPct > 0 && dropshotPct == 0 && now >= state.nextBehaviorCrouch)
	{
		state.nextBehaviorCrouch = now + randomIntRange(3000, 5500);
		if (randomint(100) < crouchPct)
		{
			self bot_press_crouch(0.15);
		}
	}

	// Jump behavior: only while standing, not while dropshotting/crouching, and pace evaluations
	curWeap = self getCurrentWeapon();
	isSniper = self _botCombatGetWeaponClass(curWeap) == "sniper";
	if (jumpPct > 0 && !isSniper && curStance == "stand" && now >= state.nextBehaviorJump)
	{
		state.nextBehaviorJump = now + randomIntRange(4500, 7500);
		if (randomint(100) < jumpPct)
		{
			self bot_press_jump(0.2);
		}
	}
}

_botCombatDoDropshot()
{
	self notify("bot_dropshot");
	self endon("bot_dropshot");
	self endon("disconnect");
	self endon("death");

	self lethalbeats\botactor\movement::bot_set_stance("prone");
	wait 1.6;
	self lethalbeats\botactor\movement::bot_set_stance("stand");
}

_botSetStrafeActive(active)
{
	self.actor["strafe_active"] = active;
}

_botCombatDoStrafe(dir)
{
	self notify("bot_strafe");
	self endon("bot_strafe");
	self endon("disconnect");
	self endon("death");
	self endon("bot_stop_move");

	self _botSetStrafeActive(true);

	side = 1;
	if (dir < 0) side = -1;

	moveAngles = self getPlayerAngles();
	if (isDefined(moveAngles) && isDefined(moveAngles[1]))
	{
		right = anglesToRight((0, moveAngles[1], 0));
		probeStart = self.origin + (0, 0, 20);
		probeEnd = probeStart + (right * (side * 70));
		if (!bulletTracePassed(probeStart, probeEnd, false, self))
		{
			side = 0 - side;
			probeEnd = probeStart + (right * (side * 70));
			if (!bulletTracePassed(probeStart, probeEnd, false, self))
			{
				self _botSetStrafeActive(false);
				return;
			}
		}
	}

	holdMs = 850;
	self lethalbeats\botactor\movement::bot_strafe(side, holdMs);

	wait float(holdMs) * 0.001;

	self lethalbeats\botactor\movement::bot_strafe(0, 0);
	self _botSetStrafeActive(false);
}

/*
///DocStringBegin
detail: bot_combat_init_reload_watcher(): <Void>
summary: Initializes tracking thread for bot weapon reloading state.
///DocStringEnd
*/
bot_combat_init_reload_watcher()
{
	self notify("bot_reload_watcher");
	self endon("bot_reload_watcher");
	self endon("disconnect");
	self endon("death");

	if (!isDefined(self.bot))
		self.bot = spawnStruct();
	self.bot.isreloading = false;

	for (;;)
	{
		self waittill("reload_start");
		self.bot.isreloading = true;
		self thread _botReloadTimeoutGuard();
		self lethalbeats\utility::waittill_any("reload", "weapon_change", "reload_timeout");
		self.bot.isreloading = false;
	}
}

_botReloadTimeoutGuard()
{
	self endon("reload");
	self endon("weapon_change");
	self endon("disconnect");
	self endon("death");
	wait 6.0;
	self notify("reload_timeout");
}

/*
///DocStringBegin
detail: bot_combat_check_tactical_reload(): <Bool>
summary: Evaluates and triggers a proactive tactical reload when safe and clip is below threshold.
///DocStringEnd
*/
bot_combat_check_tactical_reload()
{
	if (!lethalbeats\botactor\config::bot_config_get("reload_tactical_enabled"))
		return false;

	if (self lethalbeats\botactor\utility::bot_is_reloading())
		return false;

	curWeap = self getCurrentWeapon();
	if (!isDefined(curWeap) || curWeap == "" || curWeap == "none")
		return false;

	if (isWeaponClipOnly(curWeap))
		return false;

	stock = self getWeaponAmmoStock(curWeap);
	if (stock <= 0)
		return false;

	clip = self getWeaponAmmoClip(curWeap);
	maxClip = weaponClipSize(curWeap);
	if (maxClip <= 0)
		return false;

	threshold = lethalbeats\botactor\config::bot_config_get("reload_clip_threshold");
	clipPct = (clip * 100) / maxClip;
	if (clipPct >= threshold)
		return false;

	self bot_press_reload(0.2);
	return true;
}

/*
///DocStringBegin
detail: bot_combat_try_switch_secondary(): <Bool>
summary: Switches to secondary sidearm if primary weapon clip is completely empty during active combat.
///DocStringEnd
*/
bot_combat_try_switch_secondary()
{
	if (!lethalbeats\botactor\config::bot_config_get("switch_secondary_on_empty"))
		return false;

	primaries = self getWeaponsListPrimaries();
	if (!isDefined(primaries) || primaries.size < 2)
		return false;

	curWeap = self getCurrentWeapon();
	otherWeap = undefined;
	for (i = 0; i < primaries.size; i++)
	{
		if (primaries[i] != curWeap)
		{
			otherWeap = primaries[i];
			break;
		}
	}

	if (!isDefined(otherWeap))
		return false;

	otherClip = self getWeaponAmmoClip(otherWeap);
	if (otherClip <= 0)
		return false;

	self switchToWeapon(otherWeap);
	return true;
}

/*
///DocStringBegin
detail: _botCombatFire(state, now, weaponClass): <Void>
summary: Triggers weapon fire action and updates fire pacing timers.
///DocStringEnd
*/
_botCombatFire(state, now, weaponClass)
{
	fireTime = float(self.actor[FIRE_TIME]);
	if (fireTime <= 0) fireTime = 0.05;

	self bot_press_fire(fireTime);
	self.actor[LAST_FIRE_TIME] = now;
	state.fireShotsRemaining--;

	minFireDelay = max(50, int(fireTime * 1000));
	semiTimeRaw = self bot_get_skill(SKILL_SEMI_TIME, 0);
	semiTimeMs = isDefined(semiTimeRaw) && semiTimeRaw > 50 ? int(semiTimeRaw) : int(float(semiTimeRaw) * 1000);

	if (semiTimeMs > minFireDelay && (weaponClass == "pistol" || weaponClass == "machine_pistol" || weaponClass == "shotgun" || weaponClass == "sniper" || weaponClass == "projectile"))
		minFireDelay = semiTimeMs;

	state.nextFireTime = now + minFireDelay;

	if (state.fireShotsRemaining <= 0)
	{
		minPauseRaw = self.actor[MIN_PAUSE];
		maxPauseRaw = self.actor[MAX_PAUSE];
		minPauseMs = 0;
		maxPauseMs = 0;
		if (isDefined(minPauseRaw))
			minPauseMs = minPauseRaw > 50 ? int(minPauseRaw) : int(float(minPauseRaw) * 1000);
		if (isDefined(maxPauseRaw))
			maxPauseMs = maxPauseRaw > 50 ? int(maxPauseRaw) : int(float(maxPauseRaw) * 1000);
		if (maxPauseMs < minPauseMs) maxPauseMs = minPauseMs;

		if (minPauseMs > 0)
		{
			pauseDuration = randomIntRange(minPauseMs, maxPauseMs + 1);
			state.firePauseUntil = now + pauseDuration;
			self.bot_fire_pause_until = state.firePauseUntil;
			self notify("bot_combat_fire_pause", pauseDuration);
			if (pauseDuration >= 1000)
				self bot_combat_check_tactical_reload();
		}
		else
		{
			state.firePauseUntil = 0;
			self.bot_fire_pause_until = 0;
		}
	}
}

/*
///DocStringBegin
detail: _botCombatTryFire(state, now, target, distSq, weaponClass, conedot, canAttackByFov): <Void>
summary: High-level weapon trigger logic handling bursts, windup delays, and aim cone precision.
///DocStringEnd
*/
_botCombatTryFire(state, now, target, distSq, weaponClass, conedot, canAttackByFov)
{
	if (isPlayer(target) && (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand)))
		return;

	if (now < state.nextReactTime || now < state.nextFireTime)
		return;

	if (self lethalbeats\botactor\utility::bot_is_reloading())
		return;

	if (self lethalbeats\botactor\utility::bot_is_stunned())
		return;

	curWeap = self getCurrentWeapon();
	if (isDefined(curWeap) && curWeap != "" && !isWeaponClipOnly(curWeap))
	{
		if (self getWeaponAmmoClip(curWeap) <= 0)
		{
			if (self bot_combat_try_switch_secondary())
				return;
		}
	}

	if (!canAttackByFov)
		return;

	if (state.fireShotsRemaining <= 0)
	{
		if (now < state.firePauseUntil)
			return;

		minShots = int(self.actor[MIN_SHOTS]);
		maxShots = int(self.actor[MAX_SHOTS]);
		if (minShots <= 0) minShots = 1;
		if (maxShots < minShots) maxShots = minShots;

		state.fireShotsRemaining = randomIntRange(minShots, maxShots + 1);

		windUpRaw = self.actor[WIND_UP_TIME];
		windUpMs = 0;
		if (isDefined(windUpRaw))
			windUpMs = windUpRaw > 50 ? int(windUpRaw) : int(float(windUpRaw) * 1000);
		if (windUpMs > 0)
		{
			state.fireWindUpUntil = now + windUpMs;
			return;
		}
	}

	if (now < state.fireWindUpUntil)
		return;

	adsAmount = self playerAds();
	precision = 0.94;
	if (adsAmount > 0)
		precision = lethalbeats\math::math_lerp(precision, 0.985, adsAmount);

	if (weaponClass == "sniper")
	{
		if (self.actor[BEHAVIOR_QUICKSCOPE]) precision = (adsAmount >= 0.80) ? 0.98 : 0.992;
		else precision = (adsAmount >= 0.85) ? 0.985 : 0.995;
	}
	else if (weaponClass == "projectile")
	{
		precision = 0.91;
	}
	else if (weaponClass == "shotgun")
	{
		precision = 0.82;
	}

	if (conedot < precision)
		return;

	self _botCombatFire(state, now, weaponClass);
}

_botIsExplosiveDamage(meansOfDeath)
{
	if (!isDefined(meansOfDeath)) return false;
	switch (meansOfDeath)
	{
		case "MOD_GRENADE":
		case "MOD_GRENADE_SPLASH":
		case "MOD_PROJECTILE":
		case "MOD_PROJECTILE_SPLASH":
		case "MOD_EXPLOSIVE":
			return true;
	}
	return false;
}

/*
///DocStringBegin
detail: <Player> bot_apply_stun(weapon?: <String>, meansOfDeath?: <String>, customStunSeconds?: <Float>): <Bool>
summary: Applies flash/concussion/heavy-burst stun effect to bot, resetting fire cycle and updating reaction state.
///DocStringEnd
*/
bot_apply_stun(weapon, meansOfDeath, customStunSeconds)
{
	if (!isAlive(self)) return false;
	if (!lethalbeats\botactor\config::bot_config_get("stun_reaction_enabled")) return false;

	stunTime = isDefined(customStunSeconds) ? customStunSeconds : 0;

	if (_botIsExplosiveDamage(meansOfDeath))
		stunTime = max(stunTime, 2.0);
	else if (isDefined(weapon))
	{
		switch (weapon)
		{
			case "artillery_mp":
			case "flash_grenade_mp":
				stunTime = max(stunTime, 4.0);
				break;
			case "concussion_grenade_mp":
				stunTime = max(stunTime, 5.0);
				break;
		}
	}

	if (stunTime <= 0) return false;

	newStunEnd = getTime() + int(stunTime * 1000);
	if (!isDefined(self.stunEndTime) || self.stunEndTime < newStunEnd)
		self.stunEndTime = newStunEnd;

	remainingStun = float(self.stunEndTime - getTime()) / 1000.0;
	if (remainingStun < 0.05) remainingStun = 0.05;

	self shellShock("concussion_grenade_mp", remainingStun);

	if (isDefined(self.bot)) self.bot.fireCycleData = undefined;

	if (isDefined(self.stuned) && self.stuned) return true;

	self.stuned = true;
	self thread _botStunWatcher();
	return true;
}

_botStunWatcher()
{
	self endon("disconnect");
	self endon("death");

	while (isDefined(self.stunEndTime) && getTime() < self.stunEndTime)
		wait 0.05;

	self.stuned = false;
	self.stunEndTime = undefined;
}

/*
///DocStringBegin
detail: <Player> bot_cqc_should_backpedal(target: <Entity>): <Bool>
summary: Returns true if the bot carries a long-range weapon and target is dangerously close for backpedaling.
///DocStringEnd
*/
bot_cqc_should_backpedal(target)
{
	if (!isDefined(target) || !isAlive(target)) return false;
	if (!lethalbeats\botactor\config::bot_config_get("cqc_backpedal_enabled")) return false;
	if (self lethalbeats\botactor\utility::bot_is_charging()) return false;

	curWeap = self getCurrentWeapon();
	weaponClass = _botCombatGetWeaponClass(curWeap);
	if (weaponClass != "sniper" && weaponClass != "projectile") return false;

	cqcDist = lethalbeats\botactor\config::bot_config_get("cqc_backpedal_dist");
	return distanceSquared(self.origin, target.origin) < cqcDist * cqcDist;
}

/*
///DocStringBegin
detail: <Player> bot_cqc_get_backpedal_point(target: <Entity>, distance?: <Float>): <Vector3 | Undefined>
summary: Calculates and verifies an unobstructed backward reposition point away from target.
///DocStringEnd
*/
bot_cqc_get_backpedal_point(target, distance)
{
	if (!isDefined(target) || !isDefined(target.origin)) return undefined;
	if (!isDefined(distance)) distance = 96;

	backDir = vectorNormalize(self.origin - target.origin);
	flatBack = (backDir[0], backDir[1], 0);
	if (lengthSquared(flatBack) <= 0.01) return undefined;

	probe = self.origin + (vectorNormalize(flatBack) * distance);
	if (bulletTracePassed(self.origin + (0, 0, 20), probe + (0, 0, 20), false, self))
		return probe;

	return undefined;
}
