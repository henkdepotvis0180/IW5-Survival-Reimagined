/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : ai_goap_attacker |
|Creator : LastDemon99	   |
|Type : AI / Behavior      |
============================
*/

#include lethalbeats\botactor\utility;

#define SCRIPT_MOVE 3
#define PATH_LOCK 4
#define CHASE_TARGET 22
#define AIM_POS 41
#define MOVE_LOOK_DIR 45
#define MOVE_LOOK_MODE 46
#define SKILL_CHASE_DIST_MIN 76

#define GOAP_TICK 0.1
#define GOAP_CHASE_LEG 1.0
#define GOAP_FLANK_LEG 2.0
#define GOAP_LANE_WINDOW_MS 1000
#define GOAP_REPATH_BACKOFF_MS 600

/*
///DocStringBegin
detail: bot_goap_create(members?: <Entity[]>, name?: <String>): <Struct>
summary: Creates a tactical group sharing configuration options and flank budget.
///DocStringEnd
*/
bot_goap_create(members, name)
{
	group = spawnstruct();
	group.name = isDefined(name) ? name : "goap";
	group.active = true;
	group.enabled = true;
	group.members = [];
	group.options = [];
	group.lane_left = 0;
	group.lane_right = 0;
	group.lane_window = 0;

	if (isDefined(members))
	{
		foreach (bot in members)
			group bot_goap_add_member(bot);
	}

	return group;
}

/*
///DocStringBegin
detail: goap_default_group(): <Struct>
summary: Returns or creates the default shared tactical group.
///DocStringEnd
*/
goap_default_group()
{
	if (!isDefined(level.botactor_goap_default) || !isDefined(level.botactor_goap_default.active) || !level.botactor_goap_default.active)
		level.botactor_goap_default = bot_goap_create(undefined, "default");

	return level.botactor_goap_default;
}

/*
///DocStringBegin
detail: <Player> bot_goap_group(): <Struct | Undefined>
summary: Returns the tactical group this bot is currently attached to.
///DocStringEnd
*/
bot_goap_group()
{
	if (!isDefined(self.goap))
		return undefined;

	return self.goap.group;
}

/*
///DocStringBegin
detail: <Struct> bot_goap_set_option(name: <String>, value: <Int>): <Bool>
summary: Sets an option override for this tactical group.
///DocStringEnd
*/
bot_goap_set_option(name, value)
{
	if (!isDefined(name))
		return false;

	if (!isDefined(lethalbeats\botactor\config::bot_config_spec(name)))
		return false;

	if (!isDefined(self.options))
		self.options = [];

	self.options[name] = lethalbeats\botactor\config::bot_config_clamp(name, value);
	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_goap_get_option(name: <String>): <Int>
summary: Returns group option value if overridden, otherwise falls back to global config.
///DocStringEnd
*/
bot_goap_get_option(name)
{
	if (isDefined(self.options) && isDefined(self.options[name]))
		return self.options[name];

	return lethalbeats\botactor\config::bot_config_get(name);
}

/*
///DocStringBegin
detail: <Struct> bot_goap_set_enabled(enabled: <Bool>): <Void>
summary: Enables or pauses tactical group decision making.
///DocStringEnd
*/
bot_goap_set_enabled(enabled)
{
	self.enabled = isDefined(enabled) ? enabled : true;
}

/*
///DocStringBegin
detail: <Struct> bot_goap_add_member(bot: <Entity>): <Bool>
summary: Subscribes a bot to the tactical group.
///DocStringEnd
*/
bot_goap_add_member(bot)
{
	if (!isDefined(bot) || !isPlayer(bot))
		return false;

	if (!isDefined(self.members))
		self.members = [];

	foreach (member in self.members)
	{
		if (isDefined(member) && member == bot)
			return true;
	}

	self.members[self.members.size] = bot;
	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_goap_remove_member(bot: <Entity>): <Void>
summary: Removes a bot from the tactical group and clears its tactical state.
///DocStringEnd
*/
bot_goap_remove_member(bot)
{
	if (!isDefined(self.members) || !isDefined(bot))
		return;

	self.members = lethalbeats\array::array_remove(self.members, bot);

	if (isDefined(bot.goap) && isDefined(bot.goap.group) && bot.goap.group == self)
		bot.goap = undefined;
}

/*
///DocStringBegin
detail: <Struct> bot_goap_members(): <Entity[]>
summary: Returns array of active living members in the group.
///DocStringEnd
*/
bot_goap_members()
{
	if (!isDefined(self.members))
	{
		self.members = [];
		return self.members;
	}

	kept = [];
	foreach (bot in self.members)
	{
		if (!isDefined(bot) || !isPlayer(bot))
			continue;

		if (!isAlive(bot))
		{
			if (isDefined(bot.goap) && isDefined(bot.goap.group) && bot.goap.group == self)
				bot.goap = undefined;
			continue;
		}

		kept[kept.size] = bot;
	}

	self.members = kept;
	return self.members;
}

/*
///DocStringBegin
detail: <Struct> bot_goap_delete(): <Void>
summary: Deletes the tactical group and clears tactical references from all members.
///DocStringEnd
*/
bot_goap_delete()
{
	self.active = false;

	if (isDefined(self.members))
	{
		foreach (bot in self.members)
		{
			if (isDefined(bot) && isDefined(bot.goap) && isDefined(bot.goap.group) && bot.goap.group == self)
				bot.goap = undefined;
		}
	}

	self.members = [];
}

/*
///DocStringBegin
detail: <Player> bot_goap_attach(group?: <Struct>): <Void>
summary: Attaches this bot to a tactical group.
///DocStringEnd
*/
bot_goap_attach(group)
{
	if (!isDefined(group))
		group = goap_default_group();

	if (!isDefined(group))
		return;

	group bot_goap_add_member(self);

	if (isDefined(self.goap) && isDefined(self.goap.group) && self.goap.group == group)
		return;

	state = spawnstruct();
	state.group = group;
	state.current_action = undefined;
	state.full_allowed = true;
	state.flank_allowed = false;
	state.flank_side = 0;
	state.flank_lane = 0;
	state.flank_corridor = -1;
	state.flank_until = 0;
	state.flank_goal = undefined;
	state.marked = undefined;
	state.chase_next = 0;
	state.cached_cover_node = undefined;

	self.goap = state;
}

/*
///DocStringBegin
detail: <Player> bot_goap_detach(): <Void>
summary: Detaches the bot from its tactical group and releases tactical locks.
///DocStringEnd
*/
bot_goap_detach()
{
	if (!isDefined(self.goap))
		return;

	group = self.goap.group;
	self.goap = undefined;

	if (isDefined(self.actor))
	{
		self.actor[PATH_LOCK] = false;
		self.actor[SCRIPT_MOVE] = false;
	}

	if (isDefined(group))
		group bot_goap_remove_member(self);
}

/*
///DocStringBegin
detail: <Player> bot_goap_is_attached(): <Bool>
summary: Returns true if the bot is currently managed by a tactical group.
///DocStringEnd
*/
bot_goap_is_attached()
{
	return isDefined(self.goap);
}

/*
///DocStringBegin
detail: <Player> bot_goap_run(group?: <Struct>): <Bool>
summary: Tactical execution task loop; plans and takes short movement legs.
///DocStringEnd
*/
bot_goap_run(group)
{
	self bot_goap_attach(group);

	for (;;)
	{
		if (!isDefined(self.goap) || !isAlive(self))
			return true;

		grp = self.goap.group;
		if (!isDefined(grp) || !isDefined(grp.active) || !grp.active)
			return true;

		self.ba.runner_beat = gettime();

		if (self lethalbeats\botactor\utility::bot_is_reacting())
			self _goapAct(undefined);
		else if (isDefined(grp.enabled) && !grp.enabled)
		{
			self _goapAct(undefined);
			self bot_stop_move();
		}
		else
		{
			target = self _goapTarget();
			if (!isDefined(target))
			{
				self _goapAct(undefined);
				self bot_stop_move();
			}
			else
			{
				self _goapMark(target);
				self _goapStep(grp, target);
			}
		}

		wait GOAP_TICK;
	}
}

_goapDebug()
{
	return getDvarInt("botactor_debug", 0) > 0 || (lethalbeats\botactor\config::bot_config_get("goap_debug") != 0);
}

_goapStep(grp, target)
{
	contact = grp bot_goap_get_option("contact_dist");
	distSq = distanceSquared(self.origin, target.origin);
	hasSight = self lethalbeats\botactor\targeting::_botHasTargetSight(target);

	if (self _goapDebug())
	{
		backoff = 0;
		if (isDefined(self.goap.chase_next) && self.goap.chase_next > gettime())
			backoff = self.goap.chase_next - gettime();

		print("BT_GOAP " + self.name
			+ " dist=" + int(distance(self.origin, target.origin))
			+ " contact=" + contact
			+ " sight=" + (hasSight ? "Y" : "n")
			+ " lane=" + (isDefined(self.goap.flank_allowed) && self.goap.flank_allowed ? "Y" : "n")
			+ " backoff=" + backoff + "ms");
	}

	if (self lethalbeats\botactor\combat::bot_cqc_should_backpedal(target))
	{
		probe = self lethalbeats\botactor\combat::bot_cqc_get_backpedal_point(target, 96);
		if (isDefined(probe))
		{
			self _goapAct("cqc_backpedal");
			self.bot.moveto = probe;
			wait GOAP_TICK;
			return;
		}
	}

	if (hasSight && distSq <= contact * contact)
	{
		self _goapAttack(target);
		return;
	}

	if (self _goapLaneWanted(grp, target, distSq))
	{
		self _goapFlank(grp, target);
		return;
	}

	self _goapChase(target);
}

_goapAct(name)
{
	if (!isDefined(self.goap))
		return;

	if (!isDefined(name))
	{
		self.goap.current_action = undefined;
		if (isDefined(self.actor))
		{
			self.actor[SCRIPT_MOVE] = false;
			self.actor[PATH_LOCK] = false;
		}
		return;
	}

	if (isDefined(self.goap.current_action) && self.goap.current_action.name == name)
		return;

	action = spawnstruct();
	action.name = name;
	action.started_at = gettime();
	self.goap.current_action = action;
}

_goapMark(target)
{
	self lethalbeats\botactor\targeting::bot_mark_chase_target(target);

	if (isDefined(self.goap.marked) && self.goap.marked == target)
		return;

	self.goap.marked = target;
}

_goapTarget()
{
	return self lethalbeats\botactor\targeting::bot_get_effective_target();
}

_goapAttack(target)
{
	self _goapAct("attack_target");
	self bot_stop_move();

	self.actor[MOVE_LOOK_MODE] = 1;
	self lethalbeats\botactor\movement::bot_set_look_dir(target.origin - self.origin);

	wait GOAP_TICK;
}

_goapChase(target)
{
	self _goapAct("chase_target");

	if (isDefined(self.goap.chase_next) && gettime() < self.goap.chase_next)
		return;

	stopDist = self.actor[SKILL_CHASE_DIST_MIN];
	if (!isDefined(stopDist) || stopDist <= 0)
		stopDist = 192;

	self.actor[SCRIPT_MOVE] = true;
	self.actor[MOVE_LOOK_MODE] = 1;

	started = gettime();
	startPos = self.origin;
	ok = self lethalbeats\botactor\navigation::bot_go_to(target.origin, stopDist, 3.0, GOAP_CHASE_LEG, false, false);
	elapsed = gettime() - started;

	self.actor[SCRIPT_MOVE] = false;
	self.ba.runner_beat = gettime();

	self.actor[CHASE_TARGET] = target;

	if (self _goapDebug())
	{
		reached = "NO";
		if (isDefined(ok) && ok)
			reached = "YES";

		wps = 0;
		if (isDefined(level.waypoints))
			wps = level.waypoints.size;

		print("BT_GOAP chase " + self.name + " reached=" + reached
			+ " moved=" + int(distance(startPos, self.origin)) + "u"
			+ " in " + elapsed + "ms stopDist=" + stopDist + " waypoints=" + wps);
	}

	if (elapsed < 200)
		self.goap.chase_next = gettime() + GOAP_REPATH_BACKOFF_MS;
	else
		self.goap.chase_next = 0;
}

_goapFlank(grp, target)
{
	self _goapAct("move_to_flank");

	goal = self.goap.flank_goal;
	if (!isDefined(goal))
	{
		goal = self _goapLanePoint(grp, target);
		self.goap.flank_goal = goal;
	}

	if (!isDefined(goal))
	{
		self _goapLaneDrop();
		self _goapChase(target);
		return;
	}

	self.actor[SCRIPT_MOVE] = true;
	self.actor[PATH_LOCK] = true;
	self.actor[MOVE_LOOK_MODE] = 1;

	self lethalbeats\botactor\navigation::bot_go_to(goal, 96, 3.0, GOAP_FLANK_LEG, false, false);

	self.actor[SCRIPT_MOVE] = false;
	self.actor[PATH_LOCK] = false;
	self.ba.runner_beat = gettime();

	contact = grp bot_goap_get_option("contact_dist");
	if (distanceSquared(self.origin, target.origin) <= contact * contact)
		self _goapLaneDrop();
}

_goapLaneWanted(grp, target, distSq)
{
	if (!grp bot_goap_get_option("flank_enabled"))
		return false;

	pressure = grp bot_goap_get_option("pressure_dist");
	if (distSq > pressure * pressure)
		return false;

	contact = grp bot_goap_get_option("contact_dist");
	if (distSq <= contact * contact)
		return false;

	now = gettime();

	if (isDefined(self.goap.flank_allowed) && self.goap.flank_allowed && now < self.goap.flank_until)
		return true;

	self _goapLaneDrop();
	grp _goapLaneWindow(now);

	cap = grp bot_goap_get_option("flank_max_per_side");
	side = self _goapLaneSide(target);

	if (!(grp _goapLaneTake(side, cap)))
	{
		side = 0 - side;
		if (!(grp _goapLaneTake(side, cap)))
			return false;
	}

	self.goap.flank_allowed = true;
	self.goap.flank_side = side;
	self.goap.flank_lane = (side < 0) ? grp.lane_left : grp.lane_right;
	self.goap.flank_until = now + grp bot_goap_get_option("flank_hold_ms");

	self.goap.flank_goal = undefined;
	return true;
}

_goapLaneDrop()
{
	if (!isDefined(self.goap))
		return;

	self.goap.flank_allowed = false;
	self.goap.flank_side = 0;
	self.goap.flank_goal = undefined;
}

_goapLaneTake(side, cap)
{
	if (side < 0)
	{
		if (self.lane_left >= cap)
			return false;

		self.lane_left++;
		return true;
	}

	if (self.lane_right >= cap)
		return false;

	self.lane_right++;
	return true;
}

_goapLaneWindow(now)
{
	if (now < self.lane_window)
		return;

	self.lane_left = 0;
	self.lane_right = 0;
	self.lane_window = now + GOAP_LANE_WINDOW_MS;
}

_goapLaneSide(target)
{
	toTarget = target.origin - self.origin;
	forward = anglesToForward((0, vectorToYaw(toTarget), 0));
	right = (0 - forward[1], forward[0], 0);

	if (vectorDot(self.origin - target.origin, right) < 0)
		return -1;

	return 1;
}

_goapLanePoint(grp, target)
{
	if (!isDefined(self.goap))
		return undefined;

	self.goap.flank_corridor = -1;

	if (grp bot_goap_get_option("flank_mode") >= 2)
	{
		map = self lethalbeats\botactor\corridors::bot_corridor_map(target);
		if (isDefined(map))
		{
			usable = self lethalbeats\botactor\corridors::bot_corridor_usable(map);
			if (isDefined(usable) && usable.size > 1)
			{
				mine = self lethalbeats\botactor\corridors::bot_corridor_of_position(map, self.origin);
				if (isDefined(mine) && mine >= 0)
				{
					self.goap.flank_corridor = mine;
					point = self lethalbeats\botactor\corridors::bot_corridor_far_point(map, mine, 2);
					if (isDefined(point))
						return point;
				}
			}
		}
	}

	toTarget = target.origin - self.origin;
	dist = length(toTarget);
	if (dist < 1)
		return undefined;

	forward = anglesToForward((0, vectorToYaw(toTarget), 0));
	right = (0 - forward[1], forward[0], 0);

	offset = grp bot_goap_get_option("corridor_move_dist");
	if (offset > dist)
		offset = dist;

	side = self.goap.flank_side;
	if (side == 0)
		side = 1;

	wanted = self.origin + (forward * (dist * 0.5)) + (right * (offset * side));

	self lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	idx = self lethalbeats\botactor\navigation::_botgetNearestWaypoint(wanted, true);
	if (!isDefined(idx) || !isDefined(level.waypoints[idx]))
		return undefined;

	return level.waypoints[idx].origin;
}
