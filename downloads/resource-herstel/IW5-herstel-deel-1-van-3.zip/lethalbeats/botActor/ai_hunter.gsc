/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : ai_hunter        |
|Creator : LastDemon99	   |
|Type : AI / Behavior      |
============================
*/

#include lethalbeats\botactor\utility;

#define LOCK 0
#define SCRIPT_MOVE 3
#define PATH_LOCK 4
#define CHASE_TARGET 22
#define AIM_POS 41
#define MOVE_LOOK_MODE 46
#define SKILL_CHASE_DIST_MIN 76

#define HUNT_TICK 0.1
#define HUNT_REPATH_MS 1500
#define HUNT_REPATH_DIST_SQ 400 * 400
#define HUNT_NODE_REACHED_SQ 48 * 48
#define HUNT_STUCK_TIME 1.2
#define HUNT_STUCK_DIST_SQ 12 * 12
#define HUNT_GATE_REACHED_SQ 220 * 220
#define HUNT_DIRECT_DIST_SQ 700 * 700

#define HUNT_PROGRESS_MS 3000
#define HUNT_PROGRESS_MIN 96
#define HUNT_GATE_BAN_MS 8000

#define HUNT_RESUME_LOOKAHEAD 4
#define HUNT_WALK_STEP_Z 18

#define HUNT_URGENT_MS 6000
#define HUNT_URGENT_MAX 3
#define HUNT_URGENT_TICK 0.05
#define HUNT_URGENT_REPATH_MS 400
#define HUNT_URGENT_LOOKAHEAD 8

#define HUNT_CLAIM_MS 6000
#define HUNT_CLAIM_LOOKAHEAD 6

#define HUNT_TRAVERSAL_ENGAGE_SQ 220 * 220
#define HUNT_TRAVERSAL_MS 4000
#define HUNT_TRAVERSAL_PRESS_MS 350
#define HUNT_TRAVERSAL_CLEAR_Z 32
#define HUNT_TRAVERSAL_FAIL_TTL 9000
#define HUNT_TRAVERSAL_BACK 48
#define HUNT_TRAVERSAL_LATERAL 20
#define HUNT_TRAVERSAL_DOT 0.9
#define HUNT_TRAVERSAL_THROUGH 64
#define HUNT_TRAVERSAL_PUSH 190
#define HUNT_TRAVERSAL_TOP_Z 16
#define HUNT_TRAVERSAL_CLIMB_GAIN 8

/*
///DocStringBegin
detail: bot_hunter_start(botsFunc: <Function>, targetsFunc: <Function>): <Void>
summary: Starts the level-side hunter assignment service loop.
///DocStringEnd
*/
bot_hunter_start(botsFunc, targetsFunc)
{
	if (!isDefined(botsFunc) || !isDefined(targetsFunc))
		return;

	level notify("bot_hunter_service");
	level thread _botHunterService(botsFunc, targetsFunc);
}

/*
///DocStringBegin
detail: bot_hunter_stop(): <Void>
summary: Stops the hunter assignment service loop.
///DocStringEnd
*/
bot_hunter_stop()
{
	level notify("bot_hunter_service");
}

_botHunterService(botsFunc, targetsFunc)
{
	level endon("game_ended");
	level endon("bot_hunter_service");

	for (;;)
	{
		wait (lethalbeats\botactor\config::bot_config_get("hunter_assign_ms") / 1000);

		bots = [[botsFunc]]();
		targets = [[targetsFunc]]();

		if (!isDefined(bots) || !bots.size || !isDefined(targets) || !targets.size)
			continue;

		self _botHunterAssign(bots, targets);
	}
}

/*
///DocStringBegin
detail: <Level> _botHunterAssign(bots: <Entity[]>, targets: <Entity[]>): <Void>
summary: Balances hunters across available living targets and corridor approaches.
///DocStringEnd
*/
_botHunterAssign(bots, targets)
{
	live = [];
	for (t = 0; t < targets.size; t++)
	{
		target = targets[t];
		if (isDefined(target) && isDefined(target.origin) && isAlive(target))
			live[live.size] = target;
	}

	if (!live.size)
		return;

	quota = [];
	taken = [];
	mine = [];

	base = int(bots.size / live.size);
	remainder = bots.size - (base * live.size);

	for (t = 0; t < live.size; t++)
	{
		quota[t] = base;
		if (t < remainder)
			quota[t] = quota[t] + 1;

		taken[t] = 0;
		mine[t] = [];
	}

	for (b = 0; b < bots.size; b++)
	{
		bot = bots[b];
		if (!isDefined(bot) || !isAlive(bot) || !isDefined(bot.origin))
			continue;

		idx = _botHunterNearestTarget(bot, live, taken, quota);

		if (idx < 0)
			idx = _botHunterNearestTarget(bot, live, undefined, undefined);

		if (idx < 0)
			continue;

		taken[idx] = taken[idx] + 1;

		list = mine[idx];
		list[list.size] = bot;
		mine[idx] = list;
	}

	for (t = 0; t < live.size; t++)
		self _botHunterSpreadCorridors(live[t], mine[t]);
}

_botHunterNearestTarget(bot, live, taken, quota)
{
	best = -1;
	bestDistSq = 0;

	for (t = 0; t < live.size; t++)
	{
		if (isDefined(taken) && isDefined(quota) && taken[t] >= quota[t])
			continue;

		distSq = distanceSquared(bot.origin, live[t].origin);
		if (best < 0 || distSq < bestDistSq)
		{
			best = t;
			bestDistSq = distSq;
		}
	}

	return best;
}

/*
///DocStringBegin
detail: <Level> _botHunterSpreadCorridors(target: <Entity>, group: <Entity[]>): <Void>
summary: Distributes assigned bots across usable corridor entrances for the target.
///DocStringEnd
*/
_botHunterSpreadCorridors(target, group)
{
	if (!isDefined(group) || !group.size)
		return;

	map = undefined;
	usable = undefined;

	if (lethalbeats\botactor\config::bot_config_get("hunter_corridors"))
	{
		map = self lethalbeats\botactor\corridors::bot_corridor_map(target);
		if (isDefined(map))
			usable = self lethalbeats\botactor\corridors::bot_corridor_usable(map);
	}

	if (!isDefined(usable) || usable.size <= 1)
	{
		for (b = 0; b < group.size; b++)
			group[b] _botHunterSetSlot(target, undefined, -1);

		return;
	}

	gates = [];
	for (u = 0; u < usable.size; u++)
		gates[u] = self lethalbeats\botactor\corridors::bot_corridor_gate(map, usable[u]);

	cQuota = int(group.size / usable.size);
	if (cQuota * usable.size < group.size)
		cQuota++;
	if (cQuota < 1)
		cQuota = 1;

	cTaken = [];
	for (u = 0; u < usable.size; u++)
		cTaken[u] = 0;

	for (b = 0; b < group.size; b++)
	{
		bot = group[b];

		pick = _botHunterNearestGate(bot, gates, cTaken, cQuota);
		if (pick < 0)
			pick = _botHunterNearestGate(bot, gates, undefined, 0);

		if (pick < 0)
		{
			bot _botHunterSetSlot(target, undefined, -1);
			continue;
		}

		cTaken[pick] = cTaken[pick] + 1;
		bot _botHunterSetSlot(target, gates[pick], usable[pick]);
	}
}

_botHunterNearestGate(bot, gates, cTaken, cQuota)
{
	best = -1;
	bestDistSq = 0;

	for (u = 0; u < gates.size; u++)
	{
		if (!isDefined(gates[u]))
			continue;

		if (isDefined(cTaken) && cTaken[u] >= cQuota)
			continue;

		distSq = distanceSquared(bot.origin, gates[u]);
		if (best < 0 || distSq < bestDistSq)
		{
			best = u;
			bestDistSq = distSq;
		}
	}

	return best;
}

_botHunterSetSlot(target, gate, corridor)
{
	if (!isDefined(self.hunter))
		self.hunter = spawnstruct();

	changed = !isDefined(self.hunter.corridor) || self.hunter.corridor != corridor;
	if (!changed)
		changed = isDefined(self.hunter.target) != isDefined(target);
	if (!changed && isDefined(target) && isDefined(self.hunter.target))
		changed = self.hunter.target != target;

	self.hunter.target = target;
	self.hunter.gate = gate;
	self.hunter.corridor = corridor;

	if (changed)
	{
		name = "none";
		if (isDefined(target))
			name = target.name;

		self bot_hunter_trace("slot target=" + name + " corridor=" + corridor + " gate=" + isDefined(gate));
	}
}

/*
///DocStringBegin
detail: <Player> bot_hunter_trace_on(ms: <Int>): <Void>
summary: Enables debug tracing for this bot for the specified duration.
///DocStringEnd
*/
bot_hunter_trace_on(ms)
{
	if (!isDefined(self.hunter))
		self.hunter = spawnstruct();

	self.hunter.trace = gettime() + ms;
	self.hunter.trace_last = undefined;
	self.hunter.trace_next = 0;
	self.hunter.tick_next = 0;
}

_botHunterTracing()
{
	if (getDvarInt("botactor_debug", 0) <= 0)
		return false;

	if (!isDefined(self.hunter) || !isDefined(self.hunter.trace))
		return false;

	if (gettime() > self.hunter.trace)
	{
		self.hunter.trace = undefined;
		return false;
	}

	return true;
}

/*
///DocStringBegin
detail: <Player> bot_hunter_trace(msg: <String>): <Void>
summary: Logs a throttled decision trace message for this hunter.
///DocStringEnd
*/
bot_hunter_trace(msg)
{
	if (!self _botHunterTracing())
		return;

	now = gettime();
	same = isDefined(self.hunter.trace_last) && self.hunter.trace_last == msg;
	if (same && isDefined(self.hunter.trace_next) && now < self.hunter.trace_next)
		return;

	self.hunter.trace_last = msg;
	self.hunter.trace_next = now + 500;
	print("BT_HUNT|" + self.name + "|" + now + "| " + msg);
}

_botHunterTraceTick(target)
{
	if (!self _botHunterTracing())
		return;

	now = gettime();
	if (isDefined(self.hunter.tick_next) && now < self.hunter.tick_next)
		return;

	self.hunter.tick_next = now + 500;

	nodes = 0;
	if (isDefined(self.hunter.path))
		nodes = self.hunter.path.size;

	moveD = -1;
	if (isDefined(self.bot) && isDefined(self.bot.moveto))
		moveD = int(distance(self.origin, self.bot.moveto));

	tgtD = -1;
	if (isDefined(target) && isDefined(target.origin))
		tgtD = int(distance(self.origin, target.origin));

	step = 0;
	if (isDefined(self.hunter.tick_origin))
		step = int(distance(self.origin, self.hunter.tick_origin));
	self.hunter.tick_origin = self.origin;

	print("BT_HUNT|" + self.name + "|" + now
		+ "| tick node=" + self.hunter.idx + "/" + nodes
		+ " moveto_d=" + moveD
		+ " tgt_d=" + tgtD
		+ " step=" + step
		+ " stuck=" + self.hunter.stuck
		+ " stop=" + self.bot.stop_move);
}

/*
///DocStringBegin
detail: <Player> bot_hunter_run(): <Bool>
summary: Main task body for the hunter behavior, updating destination directly to self.bot.moveto.
///DocStringEnd
*/
bot_hunter_run()
{
	self _botHunterResetPath();
	self bot_hunter_trace("hunter task started");

	for (;;)
	{
		if (!isAlive(self))
			return true;

		self.ba.runner_beat = gettime();

		if (self lethalbeats\botactor\utility::bot_is_reacting())
		{
			self bot_hunter_trace("reflex active, body yield");
			wait HUNT_TICK;
			continue;
		}

		target = self _botHunterTarget();
		if (!isDefined(target))
		{
			self bot_hunter_trace("no target -> idle");
			self.bot.moveto = undefined;
			if (isDefined(self.hunter))
			{
				self.hunter.standoff_start = undefined;
				self.hunter.standoff_push_until = undefined;
			}
			wait 0.25;
			continue;
		}

		self _botHunterMark(target);

		if (self _botHunterInStandoff(target))
		{
			now = gettime();

			if (self lethalbeats\botactor\combat::bot_cqc_should_backpedal(target))
			{
				probe = self lethalbeats\botactor\combat::bot_cqc_get_backpedal_point(target, 96);
				if (isDefined(probe))
				{
					self _botHunterAdvance(probe, target);
					self _botHunterTraceTick(target);
					wait HUNT_TICK;
					continue;
				}
			}

			inFirePause = isDefined(self.bot_fire_pause_until) && now < self.bot_fire_pause_until;

			if (inFirePause)
			{
				self lethalbeats\botactor\combat::bot_combat_check_tactical_reload();

				if (!isDefined(self.hunter.repo_goal) || (isDefined(self.hunter.repo_until) && now >= self.hunter.repo_until))
				{
					wp = self lethalbeats\botactor\navigation::bot_find_radial_waypoint(target, 200, 480, -120, 120, undefined, true, target);
					if (isDefined(wp) && isDefined(wp.origin))
					{
						self.hunter.repo_goal = wp.origin;
						self.hunter.repo_until = (self.bot_fire_pause_until < now + 3000) ? self.bot_fire_pause_until : (now + 3000);
						self bot_hunter_trace("standoff: radial reposition to " + int(distance(self.origin, wp.origin)) + "u");
					}
					else
					{
						self.hunter.repo_goal = undefined;
						self.hunter.repo_until = now + 1500;
					}
				}

				if (isDefined(self.hunter.repo_goal))
				{
					if (distanceSquared(self.origin, self.hunter.repo_goal) > 40 * 40)
					{
						self _botHunterAdvance(self.hunter.repo_goal, target);
						self _botHunterTraceTick(target);
						wait HUNT_TICK;
						continue;
					}
					else
					{
						self.hunter.repo_goal = undefined;
					}
				}
			}
			else
			{
				self.hunter.repo_goal = undefined;
			}

			self bot_hunter_trace("standoff: in range with LOS, holding position");
			self.bot.moveto = undefined;
			self.actor[MOVE_LOOK_MODE] = 1;

			if (isDefined(self.bot_current_wp_idx))
			{
				self lethalbeats\botactor\navigation::bot_wp_release(self.bot_current_wp_idx);
				self.bot_current_wp_idx = undefined;
			}

			lookDir = target.origin - self.origin;
			self lethalbeats\botactor\movement::bot_set_look_dir(vectorNormalize((lookDir[0], lookDir[1], 0)));

			targetEye = target getEye();
			if (!isDefined(targetEye))
				targetEye = target.origin + (0, 0, 50);
			if (!isDefined(self.actor[AIM_POS]))
				self lethalbeats\botactor\movement::bot_set_aim_pos(targetEye);

			self _botHunterResetPath();
			wait HUNT_TICK;
			continue;
		}

		goal = self _botHunterGoal(target);
		self _botHunterAdvance(goal, target);
		self _botHunterTraceTick(target);

		// Unconditional yield prevents engine script runaway crash
		if (self bot_hunter_is_urgent())
			wait HUNT_URGENT_TICK;
		else
			wait HUNT_TICK;
	}
}

_botHunterInStandoff(target)
{
	if (self lethalbeats\botactor\utility::bot_is_charging())
		return false;

	now = gettime();
	if (isDefined(self.hunter.standoff_push_until) && now < self.hunter.standoff_push_until)
		return false;

	minDist = self bot_get_skill(SKILL_CHASE_DIST_MIN, 192);
	if (!isDefined(minDist) || minDist <= 0)
	{
		self.hunter.standoff_start = undefined;
		return false;
	}

	eye = self getEye();
	if (!isDefined(eye))
		eye = self.origin + (0, 0, 60);

	chestPos = target getTagOrigin("j_spine4");
	if (!isDefined(chestPos))
		chestPos = target getTagOrigin("j_spineupper");
	if (!isDefined(chestPos))
		chestPos = target.origin + (0, 0, 38);

	hasClearBody = bulletTracePassed(eye, chestPos, false, self);
	if (!hasClearBody && minDist > 160)
		minDist = 160;

	distSq = distanceSquared(self.origin, target.origin);
	if (distSq > minDist * minDist)
	{
		self.hunter.standoff_start = undefined;
		return false;
	}

	hasSight = self lethalbeats\botactor\targeting::_botHasTargetSight(target);
	if (!hasSight)
	{
		self.hunter.standoff_start = undefined;
		return false;
	}

	if (!isDefined(self.hunter.standoff_start))
		self.hunter.standoff_start = now;
	else if (now - self.hunter.standoff_start >= 2000)
	{
		self.hunter.standoff_push_until = now + 3500;
		self.hunter.standoff_start = undefined;
		self bot_hunter_trace("standoff: timeout reached, pushing target position for 3.5s");
		return false;
	}

	return true;
}

_botHunterGoal(target)
{
	// Priority 1: Macro-Zone Portal Navigation (Approaching target's zone from multiple flank entrances)
	if (lethalbeats\botactor\config::bot_config_get("zone_nav_enabled"))
	{
		macroDist = lethalbeats\botactor\config::bot_config_get("zone_macro_dist");
		distSq = distanceSquared(self.origin, target.origin);

		if (distSq > (macroDist * macroDist))
		{
			targetZone = lethalbeats\botactor\zones::bot_zone_get_player_zone(target);
			myZone = lethalbeats\botactor\zones::bot_zone_get_player_zone(self);

			if (isDefined(targetZone) && targetZone != myZone)
			{
				if (!isDefined(self.hunter.zone_portal) || !isDefined(self.hunter.zone_portal_target) || self.hunter.zone_portal_target != targetZone)
				{
					self.hunter.zone_portal = lethalbeats\botactor\zones::bot_zone_pick_approach_union(self, target, targetZone);
					self.hunter.zone_portal_target = targetZone;
				}

				if (isDefined(self.hunter.zone_portal) && isDefined(self.hunter.zone_portal.origin))
				{
					portalZ = abs(self.origin[2] - self.hunter.zone_portal.origin[2]);
					if (distanceSquared(self.origin, self.hunter.zone_portal.origin) <= HUNT_GATE_REACHED_SQ && portalZ <= 80)
					{
						self.hunter.zone_portal = undefined;
						self.hunter.zone_portal_target = undefined;
						return target.origin;
					}

					return self.hunter.zone_portal.origin;
				}
			}
			else
			{
				self.hunter.zone_portal = undefined;
				self.hunter.zone_portal_target = undefined;
			}
		}
		else
		{
			self.hunter.zone_portal = undefined;
			self.hunter.zone_portal_target = undefined;
		}
	}

	if (!isDefined(self.hunter) || !isDefined(self.hunter.gate))
	{
		self bot_hunter_trace("goal=target (no gate assigned)");
		return target.origin;
	}

	if (distanceSquared(self.origin, self.hunter.gate) <= HUNT_GATE_REACHED_SQ)
	{
		self bot_hunter_trace("goal=target (gate reached)");
		return target.origin;
	}

	if (isDefined(self.hunter.gate_ban) && gettime() < self.hunter.gate_ban)
	{
		self bot_hunter_trace("goal=target (gate discarded due to lack of progress)");
		return target.origin;
	}

	self bot_hunter_trace("goal=gate c" + self.hunter.corridor + " d=" + int(distance(self.origin, self.hunter.gate)));
	return self.hunter.gate;
}

_botHunterMark(target)
{
	self lethalbeats\botactor\targeting::bot_mark_chase_target(target);

	if (isDefined(self.hunter) && isDefined(self.hunter.marked) && self.hunter.marked == target)
		return;

	if (!isDefined(self.hunter))
		self.hunter = spawnstruct();

	self.hunter.marked = target;
	self.hunter.standoff_start = undefined;
	self.hunter.standoff_push_until = undefined;
	self bot_hunter_trace("marked target " + target.name + " d=" + int(distance(self.origin, target.origin)));
}

_botHunterTarget()
{
	if (isDefined(self.hunter) && isDefined(self.hunter.target))
	{
		t = self.hunter.target;
		if (isDefined(t) && isPlayer(t) && isAlive(t) && (!isDefined(t.sessionState) || t.sessionState == "playing") && (!isDefined(t.inLastStand) || !t.inLastStand))
			return t;
	}

	return self lethalbeats\botactor\targeting::bot_get_effective_target();
}

_botHunterResetPath()
{
	if (!isDefined(self.hunter))
		self.hunter = spawnstruct();

	self.hunter.path = [];
	self.hunter.idx = 0;
	self.hunter.path_time = 0;
	self.hunter.path_goal = undefined;
	self.hunter.stuck = 0;
	self.hunter.stuck_logged = undefined;
	self.hunter.last_origin = self.origin;
	self.hunter.prog_next = undefined;
	self.hunter.prog_origin = undefined;
	self.hunter.nodes = [];
	self.hunter.trav_until = undefined;
	self.hunter.trav_phase = undefined;
	self.hunter.trav_onladder = false;
	self.hunter.repo_goal = undefined;
	self.hunter.repo_until = 0;
}

/*
///DocStringBegin
detail: <Player> _botHunterProgressWatch(): <Bool>
summary: Returns true if the bot has failed to make net progress within the monitoring window.
///DocStringEnd
*/
_botHunterProgressWatch()
{
	now = gettime();

	if (!isDefined(self.hunter.prog_next) || !isDefined(self.hunter.prog_origin))
	{
		self.hunter.prog_origin = self.origin;
		self.hunter.prog_next = now + HUNT_PROGRESS_MS;
		return false;
	}

	if (now < self.hunter.prog_next)
		return false;

	net = distance(self.origin, self.hunter.prog_origin);
	self.hunter.prog_origin = self.origin;
	self.hunter.prog_next = now + HUNT_PROGRESS_MS;

	if (net >= HUNT_PROGRESS_MIN)
	{
		self _botHunterUrgentDrop();
		return false;
	}

	self bot_hunter_trace("no progress: " + int(net) + "u net in window");
	return true;
}

/*
///DocStringBegin
detail: <Player> _botHunterEscape(): <Void>
summary: Handles unstuck escape logic, using authored stuck zones or direct pathing escalation.
///DocStringEnd
*/
_botHunterEscape()
{
	zone = lethalbeats\botactor\stuckzones::stuckzone_find(self.origin);
	if (isDefined(zone))
	{
		self.hunter.path = [];
		self.hunter.idx = 0;
		self.hunter.path_goal = undefined;

		self bot_hunter_trace("known stuck zone, using scripted exit");
		escape = lethalbeats\botactor\behavior::bot_task_custom(lethalbeats\botactor\stuckzones::stuckzone_exit, zone);
		self lethalbeats\botactor\behavior::bot_do_now(escape);
		return;
	}

	self.hunter.path = [];
	self.hunter.idx = 0;
	self.hunter.path_goal = undefined;
	self.hunter.gate_ban = gettime() + HUNT_GATE_BAN_MS;

	corridor = -1;
	if (isDefined(self.hunter.corridor))
		corridor = self.hunter.corridor;

	self bot_hunter_trace("escape: dropping gate c" + corridor + " routing directly to target");
	self _botHunterUrgentTake();
}

bot_hunter_is_urgent()
{
	if (!isDefined(self.hunter) || !isDefined(self.hunter.urgent_until))
		return false;

	return gettime() < self.hunter.urgent_until;
}

/*
///DocStringBegin
detail: <Player> _botHunterUrgentTake(): <Bool>
summary: Requests an escalated compute slot for unstuck repathing within global quota.
///DocStringEnd
*/
_botHunterUrgentTake()
{
	now = gettime();

	if (self bot_hunter_is_urgent())
	{
		self.hunter.urgent_until = now + HUNT_URGENT_MS;
		return true;
	}

	if (!isDefined(level.botactor_hunt_urgent))
		level.botactor_hunt_urgent = [];

	live = [];
	foreach (bot in level.botactor_hunt_urgent)
	{
		if (!isDefined(bot) || !isAlive(bot))
			continue;
		if (!(bot bot_hunter_is_urgent()))
			continue;

		live[live.size] = bot;
	}

	if (live.size >= HUNT_URGENT_MAX)
	{
		level.botactor_hunt_urgent = live;
		self bot_hunter_trace("urgency denied, quota full (" + live.size + "/" + HUNT_URGENT_MAX + ")");
		return false;
	}

	self.hunter.urgent_until = now + HUNT_URGENT_MS;
	live[live.size] = self;
	level.botactor_hunt_urgent = live;

	self bot_hunter_trace("urgency ON (" + live.size + "/" + HUNT_URGENT_MAX + "): repath " + HUNT_URGENT_REPATH_MS + "ms, lookahead " + HUNT_URGENT_LOOKAHEAD + ", bypassing path budget");
	return true;
}

_botHunterUrgentDrop()
{
	if (!(self bot_hunter_is_urgent()))
		return;

	self.hunter.urgent_until = undefined;
	self bot_hunter_trace("urgency OFF, resuming progress");
}

_botHunterNeedsPath(goal)
{
	self.hunter.repath_why = undefined;

	stale = HUNT_REPATH_MS;
	if (self bot_hunter_is_urgent())
		stale = HUNT_URGENT_REPATH_MS;

	if (!isDefined(self.hunter.path) || !self.hunter.path.size)
		self.hunter.repath_why = "no path";
	else if (self.hunter.idx >= self.hunter.path.size)
		self.hunter.repath_why = "path exhausted";
	else if (gettime() - self.hunter.path_time >= stale)
		self.hunter.repath_why = "path stale";
	else if (isDefined(self.hunter.path_goal) && distanceSquared(self.hunter.path_goal, goal) >= HUNT_REPATH_DIST_SQ)
		self.hunter.repath_why = "goal moved";
	else if (self.hunter.stuck >= HUNT_STUCK_TIME)
		self.hunter.repath_why = "stuck";

	return isDefined(self.hunter.repath_why);
}

_botHunterBuildPath(goal)
{
	why = "?";
	if (isDefined(self.hunter.repath_why))
		why = self.hunter.repath_why;

	lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
	{
		self bot_hunter_trace("repath(" + why + ") FAILED: map has no waypoints");
		return false;
	}

	if (!(self bot_hunter_is_urgent()) && !lethalbeats\botactor\navigation::_botNavigationUsePathBudget(gettime()))
	{
		self bot_hunter_trace("repath(" + why + ") deferred: search budget exhausted");
		return false;
	}

	raw = self lethalbeats\botactor\navigation::bot_astar_search(self.origin, goal, self.team, false);
	if (!isDefined(raw) || !raw.size)
	{
		self bot_hunter_trace("repath(" + why + ") FAILED: A* no solution to d=" + int(distance(self.origin, goal)));
		return false;
	}

	self bot_hunter_trace("repath(" + why + ") ok nodes=" + raw.size + " at d=" + int(distance(self.origin, goal)));

	positions = [];
	nodes = [];
	for (i = raw.size - 1; i >= 0; i--)
	{
		idx = raw[i];
		if (!isDefined(level.waypoints[idx]))
			continue;

		nodes[positions.size] = idx;
		positions[positions.size] = level.waypoints[idx].origin;
	}

	positions[positions.size] = goal;

	self.hunter.path = positions;
	self.hunter.nodes = nodes;
	self.hunter.idx = self _botHunterResumeIndex(positions, goal);
	self.hunter.path_time = gettime();
	self.hunter.path_goal = goal;
	self.hunter.stuck = 0;

	if (self.hunter.idx)
		self bot_hunter_trace("resume at node " + self.hunter.idx);

	self _botHunterClaimTraversals(nodes);
	return true;
}

bot_hunter_in_traversal()
{
	if (!isDefined(self.hunter) || !isDefined(self.hunter.trav_until))
		return false;

	return gettime() < self.hunter.trav_until;
}

_botHunterCurrentWp()
{
	if (!isDefined(self.hunter.nodes) || self.hunter.idx >= self.hunter.nodes.size)
		return -1;

	wpIdx = self.hunter.nodes[self.hunter.idx];
	if (!isDefined(wpIdx))
		return -1;

	return wpIdx;
}

/*
///DocStringBegin
detail: <Player> _botHunterTraversalDir(wpIdx: <Int>, pos: <Vector3>): <Vector3>
summary: Returns normalized flat entry vector into the traversal waypoint.
///DocStringEnd
*/
_botHunterTraversalDir(wpIdx, pos)
{
	if (self.hunter.idx > 0 && isDefined(self.hunter.path[self.hunter.idx - 1]))
	{
		prev = self.hunter.path[self.hunter.idx - 1];
		dir = (pos[0] - prev[0], pos[1] - prev[1], 0);
		if (lengthSquared(dir) > 1)
			return vectorNormalize(dir);
	}

	wp = level.waypoints[wpIdx];
	if (isDefined(wp.angles))
	{
		fwd = anglesToForward((0, wp.angles[1], 0));
		flat = (fwd[0], fwd[1], 0);
		if (lengthSquared(flat) > 0.01)
			return vectorNormalize(flat);
	}

	dir = (pos[0] - self.origin[0], pos[1] - self.origin[1], 0);
	if (lengthSquared(dir) > 1)
		return vectorNormalize(dir);

	fwd = anglesToForward((0, self.angles[1], 0));
	return vectorNormalize((fwd[0], fwd[1], 0));
}

/*
///DocStringBegin
detail: <Player> _botHunterTraversalEngage(): <Bool>
summary: Engages traversal approach and locks heading to traversal entry vector.
///DocStringEnd
*/
_botHunterTraversalEngage()
{
	wpIdx = self _botHunterCurrentWp();
	if (wpIdx < 0)
		return false;

	wp = level.waypoints[wpIdx];
	if (!lethalbeats\botactor\navigation::bot_wp_is_traversal(wp))
		return false;

	if (distanceSquared(self.origin, wp.origin) > HUNT_TRAVERSAL_ENGAGE_SQ)
		return false;

	dir = self _botHunterTraversalDir(wpIdx, wp.origin);

	self.hunter.trav_wp = wpIdx;
	self.hunter.trav_pos = wp.origin;
	self.hunter.trav_dir = dir;
	self.hunter.trav_approach = (wp.origin[0] - dir[0] * HUNT_TRAVERSAL_BACK, wp.origin[1] - dir[1] * HUNT_TRAVERSAL_BACK, self.origin[2]);
	self.hunter.trav_phase = "align";
	self.hunter.trav_until = gettime() + HUNT_TRAVERSAL_MS;
	self.hunter.trav_onladder = false;
	self.hunter.trav_z = self.origin[2];
	self.hunter.jump_next = 0;

	self.hunter.trav_top = undefined;
	if (self.hunter.idx + 1 < self.hunter.path.size)
		self.hunter.trav_top = self.hunter.path[self.hunter.idx + 1];

	self bot_hunter_trace("traversal wp" + wpIdx + " (" + wp.type + ") engaged, aligning");
	return true;
}

_botHunterTraversalTopReached()
{
	pos = self.hunter.trav_pos;

	if (isDefined(self.hunter.trav_top))
	{
		top = self.hunter.trav_top;
		if (distance2d(self.origin, top) <= 48 && abs(self.origin[2] - top[2]) <= 68)
			return true;
		if (distanceSquared(self.origin, top) <= HUNT_NODE_REACHED_SQ)
			return true;

		if (top[2] > pos[2] + HUNT_TRAVERSAL_CLEAR_Z && self.origin[2] >= top[2] - HUNT_TRAVERSAL_TOP_Z)
			return true;
	}

	if (distance2d(self.origin, pos) <= 48 && abs(self.origin[2] - pos[2]) <= 68)
		return true;
	if (distanceSquared(self.origin, pos) <= HUNT_NODE_REACHED_SQ)
		return true;

	return self.origin[2] >= pos[2] + HUNT_TRAVERSAL_CLEAR_Z;
}

_botHunterTraversalRun()
{
	pos = self.hunter.trav_pos;
	dir = self.hunter.trav_dir;
	through = (pos[0] + dir[0] * HUNT_TRAVERSAL_THROUGH, pos[1] + dir[1] * HUNT_TRAVERSAL_THROUGH, pos[2]);

	self.bot.stop_move = false;
	onLadder = self isOnLadder();

	if (self _botHunterTraversalTopReached())
	{
		self _botHunterTraversalDone(true);
		return;
	}

	if (gettime() >= self.hunter.trav_until)
	{
		self _botHunterTraversalDone(false);
		return;
	}

	self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(dir), 400);

	if (onLadder)
	{
		self notify("hunt_jump_boost");
		self.hunter.trav_onladder = true;
		self.bot.moveto = through;

		if (self.origin[2] > self.hunter.trav_z + HUNT_TRAVERSAL_CLIMB_GAIN)
		{
			self.hunter.trav_z = self.origin[2];
			self.hunter.trav_until = gettime() + HUNT_TRAVERSAL_MS;
		}

		self bot_hunter_trace("on ladder: advance without jumping");
		return;
	}

	if (self.hunter.trav_onladder)
	{
		self.hunter.trav_onladder = false;
		self.hunter.trav_phase = "align";
		self bot_hunter_trace("ladder climb interrupted, re-aligning");
	}

	offset = (self.origin[0] - pos[0], self.origin[1] - pos[1], 0);
	along = offset[0] * dir[0] + offset[1] * dir[1];
	lateral = (offset[0] - dir[0] * along, offset[1] - dir[1] * along, 0);
	offAxis = lengthSquared(lateral);

	fwd = anglesToForward((0, self.angles[1], 0));
	facing = fwd[0] * dir[0] + fwd[1] * dir[1];

	if (self.hunter.trav_phase == "align")
	{
		self.bot.moveto = self.hunter.trav_approach;

		if (offAxis <= HUNT_TRAVERSAL_LATERAL * HUNT_TRAVERSAL_LATERAL && along <= 0 && facing >= HUNT_TRAVERSAL_DOT)
		{
			self.hunter.trav_phase = "climb";
			self bot_hunter_trace("traversal aligned, entering");
		}

		return;
	}

	self.bot.moveto = through;

	now = gettime();
	if (!isDefined(self.hunter.jump_next) || now >= self.hunter.jump_next)
	{
		self.hunter.jump_next = now + HUNT_TRAVERSAL_PRESS_MS;
		self lethalbeats\botactor\utility::bot_press_sprint(0.25);
		self lethalbeats\botactor\utility::bot_press_jump(0.2);
		self thread _botHunterJumpBoost(dir);
	}

	if (offAxis > HUNT_TRAVERSAL_LATERAL * HUNT_TRAVERSAL_LATERAL * 4 || facing < HUNT_TRAVERSAL_DOT)
	{
		self.hunter.trav_phase = "align";
		self bot_hunter_trace("traversal off-axis, re-aligning");
	}
}

/*
///DocStringBegin
detail: <Player> _botHunterJumpBoost(dir: <Vector3>): <Void>
summary: Applies horizontal velocity along entry axis upon jump execution.
///DocStringEnd
*/
_botHunterJumpBoost(dir)
{
	self endon("death");
	self endon("disconnect");
	self notify("hunt_jump_boost");
	self endon("hunt_jump_boost");

	self common_scripts\utility::waittill_notify_or_timeout("jumped", 1);

	if (!isAlive(self))
		return;

	vel = self getVelocity();

	if (vel[2] <= 0)
		return;

	self setVelocity((dir[0] * HUNT_TRAVERSAL_PUSH, dir[1] * HUNT_TRAVERSAL_PUSH, vel[2]));
	self bot_hunter_trace("jump boost applied");
}

_botHunterTraversalDone(ok)
{
	wpIdx = self.hunter.trav_wp;

	self.hunter.trav_until = undefined;
	self.hunter.trav_pos = undefined;
	self.hunter.trav_dir = undefined;
	self.hunter.trav_approach = undefined;
	self.hunter.trav_phase = undefined;
	self.hunter.trav_top = undefined;
	self.hunter.trav_onladder = false;

	if (ok)
	{
		self.hunter.idx++;
		self bot_hunter_trace("traversal wp" + wpIdx + " cleared");
		return;
	}

	self lethalbeats\botactor\navigation::bot_wp_release(wpIdx);
	self lethalbeats\botactor\navigation::bot_wp_mark_fail(wpIdx, HUNT_TRAVERSAL_FAIL_TTL);
	self.hunter.path = [];
	self.hunter.idx = 0;
	self.hunter.path_goal = undefined;

	self bot_hunter_trace("traversal wp" + wpIdx + " FAILED, discarded, repathing");
	self _botHunterUrgentTake();
}

/*
///DocStringBegin
detail: <Player> _botHunterClaimTraversals(nodes: <Int[]>): <Void>
summary: Claims upcoming traversal nodes along the route lookahead window.
///DocStringEnd
*/
_botHunterClaimTraversals(nodes)
{
	if (isDefined(self.hunter.claims))
	{
		foreach (held in self.hunter.claims)
			self lethalbeats\botactor\navigation::bot_wp_release(held);
	}

	self.hunter.claims = [];

	if (!isDefined(nodes) || !nodes.size)
		return;

	last = self.hunter.idx + HUNT_CLAIM_LOOKAHEAD;
	if (last > nodes.size)
		last = nodes.size;

	for (i = self.hunter.idx; i < last; i++)
	{
		wpIdx = nodes[i];
		if (!lethalbeats\botactor\navigation::bot_wp_is_traversal(level.waypoints[wpIdx]))
			continue;

		if (!(self lethalbeats\botactor\navigation::bot_wp_claim(wpIdx, HUNT_CLAIM_MS)))
			continue;

		self.hunter.claims[self.hunter.claims.size] = wpIdx;
		self bot_hunter_trace("claimed traversal wp" + wpIdx + " (" + level.waypoints[wpIdx].type + ")");
	}
}

/*
///DocStringBegin
detail: <Player> _botHunterResumeIndex(positions: <Vector3[]>, goal: <Vector3>): <Int>
summary: Calculates optimal resume waypoint index along rebuilt path.
///DocStringEnd
*/
_botHunterResumeIndex(positions, goal)
{
	best = 0;
	bestCost = distance(self.origin, positions[0]) + distance(positions[0], goal);

	lookahead = HUNT_RESUME_LOOKAHEAD;
	if (self bot_hunter_is_urgent())
		lookahead = HUNT_URGENT_LOOKAHEAD;

	limit = positions.size;
	if (limit > lookahead)
		limit = lookahead;

	from = self _botHunterRaise(self.origin);

	for (i = 1; i < limit; i++)
	{
		cost = distance(self.origin, positions[i]) + distance(positions[i], goal);
		if (cost >= bestCost)
			continue;

		if (!(self _botHunterCanWalkTo(from, positions[i])))
			continue;

		best = i;
		bestCost = cost;
	}

	return best;
}

_botHunterRaise(pos)
{
	raised = playerPhysicsTrace(pos, pos + (0, 0, HUNT_WALK_STEP_Z), false, self);
	if (!isDefined(raised))
		return pos;

	return raised;
}

/*
///DocStringBegin
detail: <Player> _botHunterCanWalkTo(from: <Vector3>, pos: <Vector3>): <Bool>
summary: Tests player physics capsule walkability between points.
///DocStringEnd
*/
_botHunterCanWalkTo(from, pos)
{
	if (!isDefined(from) || !isDefined(pos))
		return false;

	if (lethalbeats\botactor\stuckzones::stuckzone_is_ignored(pos))
		return false;

	end = self _botHunterRaise(pos);
	hit = playerPhysicsTrace(from, end, false, self);
	if (!isDefined(hit))
		return false;

	return hit == end;
}

_botHunterAdvance(goal, target)
{
	if (self bot_hunter_in_traversal())
	{
		self _botHunterTraversalRun();
		self _botHunterStuckWatch();
		return;
	}

	if (self _botHunterProgressWatch())
		self _botHunterEscape();

	if (self _botHunterNeedsPath(goal))
		self _botHunterBuildPath(goal);

	self.bot.stop_move = false;
	if (isDefined(self.ba))
		self.ba.move_stop_dist = 16;

	if (!isDefined(self.hunter.path) || !self.hunter.path.size || self.hunter.idx >= self.hunter.path.size)
	{
		self.bot.moveto = self _botHunterFallback(goal);
		self _botHunterStuckWatch();
		return;
	}

	node = self.hunter.path[self.hunter.idx];

	dist_2d = distance2d(self.origin, node);
	z_diff = abs(self.origin[2] - node[2]);

	if ((dist_2d <= 48 && z_diff <= 68) || distanceSquared(self.origin, node) <= HUNT_NODE_REACHED_SQ)
	{
		self.hunter.idx++;
		if (self.hunter.idx < self.hunter.path.size)
			node = self.hunter.path[self.hunter.idx];
		else
			node = goal;

		self bot_hunter_trace("node reached -> " + self.hunter.idx + "/" + self.hunter.path.size + " next d=" + int(distance(self.origin, node)));
	}

	if (self _botHunterTraversalEngage())
	{
		self _botHunterTraversalRun();
		self _botHunterStuckWatch();
		return;
	}

	self.bot.moveto = node;
	self.actor[MOVE_LOOK_MODE] = 1;

	self _botHunterStuckWatch();
}

_botHunterFallback(goal)
{
	if (distanceSquared(self.origin, goal) <= HUNT_DIRECT_DIST_SQ)
	{
		from = self _botHunterRaise(self.origin);
		if (self _botHunterCanWalkTo(from, goal))
		{
			self bot_hunter_trace("fallback: direct push, line clear");
			return goal;
		}

		if (distanceSquared(self.origin, goal) <= 180 * 180)
		{
			now = gettime();
			if (!isDefined(self.hunter.last_vault_time) || now >= self.hunter.last_vault_time + 1200)
			{
				self.hunter.last_vault_time = now;
				self lethalbeats\botactor\utility::bot_press_sprint(0.3);
				self lethalbeats\botactor\utility::bot_press_jump(0.2);
			}
		}

		lookDir = goal - self.origin;
		self lethalbeats\botactor\movement::bot_set_look_dir(vectorNormalize((lookDir[0], lookDir[1], 0)));
		self bot_hunter_trace("fallback: close to goal, holding line to target");
		return goal;
	}

	lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (isDefined(level.waypoints) && level.waypoints.size)
	{
		idx = self lethalbeats\botactor\navigation::_botgetNearestWaypoint(self.origin, true);
		if (isDefined(idx) && isDefined(level.waypoints[idx]) && isDefined(level.waypoints[idx].origin))
		{
			wp = level.waypoints[idx].origin;

			if (distanceSquared(self.origin, wp) > HUNT_NODE_REACHED_SQ)
			{
				self bot_hunter_trace("fallback: reconnecting to graph, wp" + idx + " d=" + int(distance(self.origin, wp)));
				return wp;
			}
		}
	}

	self bot_hunter_trace("fallback: pushing directly to goal d=" + int(distance(self.origin, goal)));
	return goal;
}

_botHunterStuckWatch()
{
	if (!isDefined(self.hunter.last_origin))
		self.hunter.last_origin = self.origin;

	if (distanceSquared(self.origin, self.hunter.last_origin) <= HUNT_STUCK_DIST_SQ)
	{
		tick = HUNT_TICK;
		if (self bot_hunter_is_urgent())
			tick = HUNT_URGENT_TICK;

		self.hunter.stuck += tick;
		self bot_hunter_trace("progress stalled, accumulating stuck time");

		if (self.hunter.stuck >= HUNT_STUCK_TIME)
			self _botHunterUrgentTake();

		if (self.hunter.stuck >= 3.0 && !isDefined(self.hunter.stuck_logged))
		{
			self.hunter.stuck_logged = true;

			hasPath = 0;
			if (isDefined(self.hunter.path))
				hasPath = self.hunter.path.size;

			if (getDvarInt("botactor_debug", 0) > 0)
				print("BT_HUNT stuck " + self.name
					+ " " + int(self.hunter.stuck) + "s"
					+ " pathNodes=" + hasPath
					+ " idx=" + self.hunter.idx
					+ " corridor=" + self.hunter.corridor
					+ " distToGoal=" + (isDefined(self.bot.moveto) ? int(distance(self.origin, self.bot.moveto)) : -1));
		}

		return;
	}

	self.hunter.stuck = 0;
	self.hunter.stuck_logged = undefined;
	self.hunter.last_origin = self.origin;
}
