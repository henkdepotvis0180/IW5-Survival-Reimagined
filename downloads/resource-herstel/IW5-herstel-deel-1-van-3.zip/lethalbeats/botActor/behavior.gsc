/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : behavior         |
|Creator : LastDemon99	   |
|Type : AI / Behavior      |
============================
*/

#include lethalbeats\botActor\utility;
#include lethalbeats\botActor\navigation;
#include lethalbeats\botActor\movement;
#include lethalbeats\botActor\ai_goap_attacker;
#include lethalbeats\utility;

#define SCRIPT_MOVE 3
#define PATH_LOCK 4
#define CHASE_TARGET 22
#define ENABLED_TARGETS 40
#define AIM_POS 41
#define MOVE_LOOK_MODE 46
#define SKILL_CHASE_DIST_MIN 76
#define SKILL_CHASE_DIST_MAX 77
#define HEARTBEAT_NAV 7
#define PATROL_ACTIVE 20

#define RUNNER_BEAT_TIMEOUT 400

/*
///DocStringBegin
detail: bot_behavior_init(): <Void>
summary: Initializes task scheduler queue and starts the supervisor thread.
///DocStringEnd
*/
bot_behavior_init()
{
	if (!isDefined(self.ba))
		self lethalbeats\botactor\movement::bot_drive_init();

	self.ba.tasks = [];

	if (!isDefined(self.ba.engage))
		self.ba.engage = "free";

	self.ba.task = undefined;
	self.ba.gen = 0;
	self.ba.runner_beat = 0;
	self.ba.last_result = false;
	self.ba.task_retry_kind = undefined;
	self.ba.task_retry_time = 0;
	self.ba.task_retry_count = 0;
	self.ba.standing_next = 0;

	self thread _botTaskSupervisor();
}

_botMakeTask(kind)
{
	task = spawnstruct();
	task.kind = kind;

	if (!isDefined(level.botactor_task_id))
		level.botactor_task_id = 0;

	level.botactor_task_id++;
	task.id = level.botactor_task_id;
	task.priority = 0;
	task.interruptible = true;
	task.resume = true;
	task.category = undefined;
	task.pos = undefined;
	task.ent = undefined;
	task.a = undefined;
	task.b = undefined;
	task.c = undefined;
	task.func = undefined;
	task.points = undefined;
	task.timers = undefined;
	task.angles = undefined;
	task.loop = false;
	task.idx = undefined;
	task.dir = undefined;
	return task;
}

/*
///DocStringBegin
detail: bot_task_goto(pos: <Vector3>, stop_dist?: <Float>, timeout?: <Float>): <Struct>
summary: Creates a task to navigate to a target world position.
///DocStringEnd
*/
bot_task_goto(pos, stop_dist, timeout)
{
	task = _botMakeTask("goto");
	task.pos = pos;
	task.a = isDefined(stop_dist) ? stop_dist : 32;
	task.b = isDefined(timeout) ? timeout : 20;
	return task;
}

/*
///DocStringBegin
detail: bot_task_goto_ent(ent: <Entity>, stop_dist?: <Float>, timeout?: <Float>): <Struct>
summary: Creates a task to navigate to an entity's current position.
///DocStringEnd
*/
bot_task_goto_ent(ent, stop_dist, timeout)
{
	task = _botMakeTask("goto_ent");
	task.ent = ent;
	task.a = isDefined(stop_dist) ? stop_dist : 64;
	task.b = isDefined(timeout) ? timeout : 20;
	return task;
}

/*
///DocStringBegin
detail: bot_task_patrol(points: <Vector3[]>, timers?: <Float[]>, angles?: <Vector3[]>, loop?: <Bool | String>, stances?: <String[]>, scan_modes?: <String[]>): <Struct>
summary: Creates a patrol task along an ordered set of waypoints.
///DocStringEnd
*/
bot_task_patrol(points, timers, angles, loop, stances, scan_modes)
{
	task = _botMakeTask("patrol");
	task.points = points;
	task.timers = timers;
	task.angles = angles;
	task.loop = isDefined(loop) ? loop : true;
	task.stances = stances;
	task.scan_modes = scan_modes;
	return task;
}

/*
///DocStringBegin
detail: bot_task_follow(ent: <Entity>, dist_min?: <Float>, dist_max?: <Float>, timeout?: <Float>): <Struct>
summary: Creates a non-combat follow/escort task following a target entity.
///DocStringEnd
*/
bot_task_follow(ent, dist_min, dist_max, timeout)
{
	task = _botMakeTask("follow");
	task.ent = ent;
	task.a = isDefined(dist_min) ? dist_min : 96;
	task.b = isDefined(dist_max) ? dist_max : 220;
	task.c = timeout;
	return task;
}

/*
///DocStringBegin
detail: bot_task_hunt(ent: <Entity>): <Struct>
summary: Creates an aggressive chase and engage task for a target entity.
///DocStringEnd
*/
bot_task_hunt(ent)
{
	task = _botMakeTask("hunt");
	task.ent = ent;
	return task;
}

/*
///DocStringBegin
detail: bot_task_hold(seconds?: <Float>, angles?: <Vector3>): <Struct>
summary: Creates a stationary hold task, optionally maintaining a look angle.
///DocStringEnd
*/
bot_task_hold(seconds, angles)
{
	task = _botMakeTask("hold");
	task.a = seconds;
	task.angles = angles;
	return task;
}

/*
///DocStringBegin
detail: bot_task_face(angles: <Vector3>, seconds?: <Float>): <Struct>
summary: Creates a task to face a direction for a given duration without moving.
///DocStringEnd
*/
bot_task_face(angles, seconds)
{
	task = _botMakeTask("face");
	task.angles = angles;
	task.a = isDefined(seconds) ? seconds : 1.0;
	return task;
}

/*
///DocStringBegin
detail: bot_task_wait(seconds: <Float>): <Struct>
summary: Creates a task that stops the bot and waits for the specified duration.
///DocStringEnd
*/
bot_task_wait(seconds)
{
	task = _botMakeTask("wait");
	task.a = isDefined(seconds) ? seconds : 1.0;
	return task;
}

/*
///DocStringBegin
detail: bot_task_goap(group?: <Struct>): <Struct>
summary: Creates a task that attaches the bot to a GOAP tactical planner group.
///DocStringEnd
*/
bot_task_goap(group)
{
	task = _botMakeTask("goap");
	task.a = group;
	return task;
}

/*
///DocStringBegin
detail: bot_task_custom(func: <Function>, a1?, a2?, a3?): <Struct>
summary: Creates a custom script task executing the provided function on the bot.
///DocStringEnd
*/
bot_task_custom(func, a1, a2, a3)
{
	task = _botMakeTask("custom");
	task.func = func;
	task.a = a1;
	task.b = a2;
	task.c = a3;
	return task;
}

/*
///DocStringBegin
detail: bot_task_reposition_radial(center?: <Vector|Entity>, minRadius?: <Float>, maxRadius?: <Float>, minAngle?: <Float>, maxAngle?: <Float>, baseAngle?: <Float>, timeout?: <Float>, stopDist?: <Float>): <Struct>
summary: Creates a repositioning task to find and move to a radial waypoint sector.
///DocStringEnd
*/
bot_task_reposition_radial(center, minRadius, maxRadius, minAngle, maxAngle, baseAngle, timeout, stopDist)
{
	task = _botMakeTask("reposition_radial");
	task.pos = center;
	task.a = minRadius;
	task.b = maxRadius;
	task.c = minAngle;
	task.angles = isDefined(maxAngle) ? maxAngle : undefined;
	task.idx = baseAngle;
	task.timers = isDefined(timeout) ? timeout : 4.0;
	task.stop_dist = isDefined(stopDist) ? stopDist : 32;
	return task;
}

/*
///DocStringBegin
detail: bot_do(task: <Struct>): <Void>
summary: Clears the queue and immediately starts executing the given task.
///DocStringEnd
*/
bot_do(task)
{
	if (!isDefined(self.ba))
		self bot_behavior_init();

	self.ba.tasks = [];
	self _botTaskInterrupt(false, "bot_do(" + (isDefined(task) ? task.kind : "none") + ")");

	if (isDefined(task))
	{
		self.ba.tasks[0] = task;
		self _botTaskWake();
	}
}

/*
///DocStringBegin
detail: bot_do_now(task: <Struct>): <Void>
summary: Interrupts the current task to run this task immediately, resuming previous on finish.
///DocStringEnd
*/
bot_do_now(task)
{
	if (!isDefined(self.ba))
		self bot_behavior_init();

	if (!isDefined(task))
		return;

	self _botTaskInterrupt(true, "bot_do_now(" + task.kind + ")");
	self _botTaskPushFront(task);
	self _botTaskWake();
}

/*
///DocStringBegin
detail: <Player> bot_catchup_to(target: <Entity|Vector3>, stopDist?: <Float>, timeout?: <Float>): <Void>
summary: Executes high-priority sprint catchup towards target, stopping cleanly upon direct sight or adjacent graph arrival.
///DocStringEnd
*/
bot_catchup_to(target, stopDist, timeout)
{
	self endon("disconnect");
	self endon("death");

	if (!isDefined(target)) return;
	if (isPlayer(target) && (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand))) return;
	if (isDefined(self.is_catching_up) && self.is_catching_up) return;
	self.is_catching_up = true;

	if (!isDefined(stopDist)) stopDist = 220;
	if (!isDefined(timeout)) timeout = 14.0;

	targetPos = isDefined(target.origin) ? target.origin : target;

	self lethalbeats\botactor\utility::bot_set_route_sprint(true);
	task = self bot_task_goto(targetPos, stopDist, timeout);
	self bot_do(task);

	startTime = getTime();
	timeoutMs = timeout * 1000;

	while (isDefined(self.ba) && isDefined(self.ba.task) && self.ba.task == task)
	{
		wait 0.25;

		if (!isAlive(self)) break;
		if (isDefined(self.stuned) && self.stuned) break;
		if (isPlayer(target) && (!isAlive(target) || (isDefined(target.sessionState) && target.sessionState != "playing") || (isDefined(target.inLastStand) && target.inLastStand))) break;

		targetCurPos = isDefined(target.origin) ? target.origin : target;
		distSq = distanceSquared(self.origin, targetCurPos);
		hasSight = bullettracepassed(self.origin + (0, 0, 55), targetCurPos + (0, 0, 55), false, self);

		// Disengage sprint upon direct combat line-of-sight within engagement range
		if (distSq <= 600 * 600 && hasSight) break;

		// Close quarters: only stop if visual is confirmed or arrived at adjacent waypoints
		if (distSq <= 350 * 350)
		{
			if (hasSight) break;

			hops = lethalbeats\botactor\navigation::bot_get_waypoint_hops(self.origin, targetCurPos, 3);
			if (hops >= 0 && hops <= 2) break;
		}

		if (getTime() - startTime >= timeoutMs) break;
	}

	self.is_catching_up = false;
	if (isDefined(self.ba)) self.ba.move_stop_dist = 16;

	if (isAlive(self) && isDefined(self.ba) && isDefined(self.ba.standing))
		self bot_do(self.ba.standing);
}

_botTaskWake()
{
	self thread _botTaskRunner();
}

/*
///DocStringBegin
detail: bot_queue(task: <Struct>): <Void>
summary: Adds a task to the back of the queue.
///DocStringEnd
*/
bot_queue(task)
{
	if (!isDefined(self.ba))
		self bot_behavior_init();

	if (!isDefined(task))
		return;

	self.ba.tasks[self.ba.tasks.size] = task;
}

/*
///DocStringBegin
detail: bot_clear(): <Void>
summary: Clears all queued tasks and halts current movement.
///DocStringEnd
*/
bot_clear()
{
	if (!isDefined(self.ba))
		return;

	self.ba.tasks = [];
	self _botTaskInterrupt(false, "bot_clear");
}

_botTaskInterrupt(requeueRunning, reason)
{
	if (!isDefined(requeueRunning))
		requeueRunning = false;

	running = self.ba.task;

	if (isDefined(reason) && self lethalbeats\botactor\utility::bot_is_reacting() && self lethalbeats\botactor\utility::_botGrenadeDebug())
		print("BT_NADE INTERRUPT bot=" + self.name + " during reaction, by " + reason + ", running=" + (isDefined(running) ? running.kind : "none"));

	if (isDefined(running) && isDefined(running.resume) && !running.resume)
		requeueRunning = false;

	// Detach GOAP when interrupting a running goap task to prevent orphaned state
	if (isDefined(running) && running.kind == "goap")
		self lethalbeats\botactor\ai_goap_attacker::bot_goap_detach();

	self.ba.gen++;
	self.ba.task = undefined;
	if (isDefined(self.ba))
		self.ba.move_stop_dist = 16;

	if (requeueRunning)
		self _botTaskPushFront(running);

	self.ba.runner_beat = 0;
	if (isDefined(self.actor))
		self.actor[HEARTBEAT_NAV] = 0;

	self notify("bot_task_break");
	self notify("bot_go_to");
	self notify("bot_chase");
	self notify("bot_patrol");
	self notify("bot_patrol_loop");

	self bot_stop_move();
}

/*
///DocStringBegin
detail: <Player> bot_set_standing_task(task: <Struct | Undefined>): <Void>
summary: Sets the default standing task executed whenever the queue is empty.
///DocStringEnd
*/
bot_set_standing_task(task)
{
	if (!isDefined(self.ba))
		self bot_behavior_init();

	self.ba.standing = task;
	self.ba.standing_next = 0;
}

/*
///DocStringBegin
detail: bot_task_active(): <Bool>
summary: Returns true if a task is currently executing or queued.
///DocStringEnd
*/
bot_task_active()
{
	if (!isDefined(self.ba))
		return false;

	return isDefined(self.ba.task) || self.ba.tasks.size > 0;
}

/*
///DocStringBegin
detail: bot_task_kind(): <String | Undefined>
summary: Returns kind of the currently running task, or undefined if idle.
///DocStringEnd
*/
bot_task_kind()
{
	if (!isDefined(self.ba) || !isDefined(self.ba.task))
		return undefined;

	return self.ba.task.kind;
}

/*
///DocStringBegin
detail: bot_wait_task(timeout?: <Float>): <Bool>
summary: Blocks until the bot finishes all tasks or timeout expires.
///DocStringEnd
*/
bot_wait_task(timeout)
{
	waited = 0.0;
	for (;;)
	{
		if (!isDefined(self) || !isAlive(self))
			return false;

		if (!self bot_task_active())
			return true;

		if (isDefined(timeout) && waited >= timeout)
			return false;

		wait 0.1;
		waited += 0.1;
	}
}

/*
///DocStringBegin
detail: bot_set_engagement(mode: <String>): <Void>
summary: Sets engagement mode ("free", "hold", "none").
///DocStringEnd
*/
bot_set_engagement(mode)
{
	if (!isDefined(self.ba))
		self bot_behavior_init();

	if (!isDefined(mode))
		mode = "free";

	self.ba.engage = mode;

	if (mode == "none")
	{
		self bot_stop_attack();
		self.actor[AIM_POS] = undefined;
	}

	self.actor[PATH_LOCK] = (mode != "free");
}

/*
///DocStringBegin
detail: bot_get_engagement(): <String>
summary: Returns current engagement policy string.
///DocStringEnd
*/
bot_get_engagement()
{
	if (!isDefined(self.ba) || !isDefined(self.ba.engage))
		return "free";

	return self.ba.engage;
}

/*
///DocStringBegin
detail: bot_engagement_allows_targets(): <Bool>
summary: Returns true if the engagement policy allows acquiring targets.
///DocStringEnd
*/
bot_engagement_allows_targets()
{
	return self bot_get_engagement() != "none";
}

/*
///DocStringBegin
detail: bot_engagement_allows_chase(): <Bool>
summary: Returns true if the bot is allowed to abandon task to pursue targets.
///DocStringEnd
*/
bot_engagement_allows_chase()
{
	return self bot_get_engagement() == "free";
}

_botTaskSupervisor()
{
	self notify("bot_task_supervisor");
	self endon("bot_task_supervisor");
	self endon("disconnect");
	self endon("death");

	for (;;)
	{
		wait 0.1;

		if (!isDefined(self.ba))
			continue;
		if (!isDefined(self.ba.tasks))
			continue;
		if (!self.ba.tasks.size && !isDefined(self.ba.task))
			continue;

		beat = self.ba.runner_beat;
		if (isDefined(self.actor[HEARTBEAT_NAV]) && self.actor[HEARTBEAT_NAV] > beat)
			beat = self.actor[HEARTBEAT_NAV];

		if (gettime() - beat < RUNNER_BEAT_TIMEOUT)
			continue;

		self thread _botTaskRunner();
	}
}

_botTaskRunner()
{
	self notify("bot_task_runner");
	self endon("bot_task_runner");
	self endon("disconnect");
	self endon("death");

	for (;;)
	{
		self.ba.runner_beat = gettime();

		if (!isDefined(self.ba.task))
			self.ba.task = self _botTaskPop();

		if (!isDefined(self.ba.task) && isDefined(self.ba.standing))
		{
			if (!isDefined(self.ba.standing_next))
				self.ba.standing_next = 0;

			if (gettime() >= self.ba.standing_next)
			{
				self.ba.standing_next = gettime() + 1000;
				self.ba.task = self.ba.standing;
			}
		}

		task = self.ba.task;
		if (!isDefined(task))
		{
			wait 0.1;
			continue;
		}

		if (isDefined(self.ba.task_retry_kind) && isDefined(task.id) && self.ba.task_retry_kind == task.id && gettime() - self.ba.task_retry_time < 1000)
		{
			self.ba.task_retry_count++;
			if (self.ba.task_retry_count > 4)
			{
				print("BOTACTOR: task '" + task.kind + "' kept dying on restart, dropping it");
				self.ba.task = undefined;
				self.ba.task_retry_count = 0;
				continue;
			}
		}
		else
		{
			self.ba.task_retry_count = 0;
		}

		self.ba.task_retry_kind = task.id;
		self.ba.task_retry_time = gettime();

		gen = self.ba.gen;
		self notify("bot_task_start", task.kind);

		ok = self _botTaskExec(task);

		self.ba.runner_beat = gettime();

		if (self.ba.gen != gen)
			continue;

		self.ba.task = undefined;
		self.ba.last_result = ok;
		if (isDefined(self.ba))
			self.ba.move_stop_dist = 16;
		self notify("bot_task_done", task.kind, ok);
	}
}

_botTaskPop()
{
	if (!isDefined(self.ba.tasks) || !self.ba.tasks.size)
		return undefined;

	front = self.ba.tasks[0];

	kept = [];
	for (i = 1; i < self.ba.tasks.size; i++)
		kept[kept.size] = self.ba.tasks[i];

	self.ba.tasks = kept;
	return front;
}

_botTaskPushFront(task)
{
	if (!isDefined(task))
		return;

	pushed = [];
	pushed[0] = task;
	for (i = 0; i < self.ba.tasks.size; i++)
		pushed[pushed.size] = self.ba.tasks[i];

	self.ba.tasks = pushed;
}

_botTaskExec(task)
{
	self.ba.runner_beat = gettime();

	switch (task.kind)
	{
		case "goto":
			return self _botTaskDoGoto(task);

		case "goto_ent":
			if (!isDefined(task.ent) || !isDefined(task.ent.origin))
				return false;
			task.pos = task.ent.origin;
			return self _botTaskDoGoto(task);

		case "patrol":
			return self _botTaskDoPatrol(task);

		case "follow":
			return self _botTaskDoFollow(task);

		case "hunt":
			return self _botTaskDoHunt(task);

		case "goap":
			return self _botTaskDoGoap(task);

		case "hold":
			return self _botTaskDoHold(task);

		case "face":
			return self _botTaskDoFace(task);

		case "wait":
			self bot_stop_move();
			if (isDefined(task.a) && task.a > 0)
				wait task.a;
			return true;

		case "reposition_radial":
			return self _botTaskDoRepositionRadial(task);

		case "custom":
			if (!isDefined(task.func))
				return false;

			if (isDefined(task.c))
				return self [[task.func]](task.a, task.b, task.c);
			if (isDefined(task.b))
				return self [[task.func]](task.a, task.b);
			if (isDefined(task.a))
				return self [[task.func]](task.a);

			return self [[task.func]]();
	}

	return false;
}

_botTaskDoRepositionRadial(task)
{
	timeout = isDefined(task.timers) ? task.timers : 4.0;
	stopDist = isDefined(task.stop_dist) ? task.stop_dist : 32;
	return self lethalbeats\botactor\navigation::bot_reposition_radial(task.pos, task.a, task.b, task.c, task.angles, task.idx, timeout, stopDist);
}

_botTaskDoGoto(task)
{
	if (!isDefined(task.pos))
		return false;

	self.actor[MOVE_LOOK_MODE] = 1;
	res = self lethalbeats\botactor\navigation::bot_go_to(task.pos, task.a, 3.0, task.b, false, false);
	if (isDefined(self.ba))
		self.ba.move_stop_dist = 16;
	return res;
}

_botTaskDoPatrol(task)
{
	return self lethalbeats\botactor\ai_patrol::bot_patrol_task_run(task);
}

_botTaskDoFollow(task)
{
	if (!isDefined(task.ent))
		return false;

	elapsed = 0.0;

	for (;;)
	{
		self.ba.runner_beat = gettime();

		if (!isDefined(task.ent) || !isDefined(task.ent.origin))
			return true;

		if (isDefined(task.c) && elapsed >= task.c)
			return true;

		distSq = distanceSquared(self.origin, task.ent.origin);

		if (distSq > task.b * task.b)
		{
			self lethalbeats\botactor\navigation::bot_go_to(task.ent.origin, task.a, 3.0, 6.0, true, false);
			self.ba.runner_beat = gettime();
			elapsed += 1.0;
			continue;
		}

		self bot_stop_move();
		wait 0.25;
		elapsed += 0.25;
	}
}

_botTaskDoHunt(task)
{
	if (!isDefined(task.ent) || !isDefined(task.ent.origin))
		return false;

	if (isDefined(self.goap))
		return false;

	self bot_set_target(task.ent);
	self.actor[CHASE_TARGET] = task.ent;
	self.actor[MOVE_LOOK_MODE] = 1;

	self lethalbeats\botactor\navigation::_botChaseLoop(task.ent);

	self.ba.runner_beat = gettime();
	return true;
}

// GOAP drives movement from its own runtime; task wrapper holds the runner lock
_botTaskDoGoap(task)
{
	self lethalbeats\botactor\ai_goap_attacker::bot_goap_attach(task.a);

	for (;;)
	{
		self.ba.runner_beat = gettime();

		if (!self lethalbeats\botactor\ai_goap_attacker::bot_goap_is_attached())
			return true;

		wait 0.2;
	}
}

_botTaskDoHold(task)
{
	self bot_stop_move();

	if (isDefined(task.angles) && lethalbeats\utility::is_vector(task.angles))
		self lethalbeats\botactor\movement::bot_look_at_angles(task.angles, 60000);

	if (!isDefined(task.a))
	{
		for (;;)
		{
			self.ba.runner_beat = gettime();
			wait 0.2;
		}
	}

	waited = 0.0;
	while (waited < task.a)
	{
		wait 0.1;
		waited += 0.1;
		self.ba.runner_beat = gettime();
	}

	self lethalbeats\botactor\movement::bot_look_clear();
	return true;
}

_botTaskDoFace(task)
{
	if (!isDefined(task.angles) || !lethalbeats\utility::is_vector(task.angles))
		return false;

	self bot_stop_move();

	hold = task.a;
	if (!isDefined(hold) || hold <= 0)
		hold = 1.0;

	self lethalbeats\botactor\movement::bot_look_at_angles(task.angles, int(hold * 1000) + 200);

	waited = 0.0;
	while (waited < hold)
	{
		wait 0.1;
		waited += 0.1;
		self.ba.runner_beat = gettime();
	}

	return true;
}
