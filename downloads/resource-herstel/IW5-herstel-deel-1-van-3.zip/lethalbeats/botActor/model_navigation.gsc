/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : model_navigation |
|Creator : LastDemon99	   |
|Type : Navigation API     |
============================
*/

#include common_scripts\utility;

#define MODEL_NAV_DEFAULT_SPEED 330
#define MODEL_NAV_DEFAULT_TICK 0.08
#define MODEL_NAV_REPATH_TIME 800
#define MODEL_NAV_REPATH_DIST_SQ 128 * 128
#define MODEL_NAV_GOAL_REACHED_SQ 44 * 44
#define MODEL_NAV_STUCK_DIST_SQ 12 * 12
#define MODEL_NAV_MIN_GROUND_NORMAL_Z 0.62
#define MODEL_NAV_MAX_ORIENT_PITCH 28
#define MODEL_NAV_MAX_ORIENT_ROLL 28
#define MODEL_NAV_SEPARATION_RADIUS 35
#define MODEL_NAV_STEP_Z 18
#define MODEL_NAV_STEP_SLOP_SQ 20 * 20
#define MODEL_NAV_BLOCKED_TICKS 3
#define MODEL_NAV_DEFLECT_ANGLES [35, -35, 70, -70, 110, -110]

/*
///DocStringBegin
detail: <Entity> model_nav_init(speed: <Float>, tick: <Float>, ignoreEnt: <Entity>): <Void>
summary: Initializes navigation state struct on a script_model entity.
///DocStringEnd
*/
model_nav_init(speed, tick, ignoreEnt)
{
	if (!isDefined(self.model_nav))
		self.model_nav = spawnstruct();

	self.model_nav.speed = isDefined(speed) ? speed : MODEL_NAV_DEFAULT_SPEED;
	self.model_nav.tick = isDefined(tick) ? tick : MODEL_NAV_DEFAULT_TICK;
	self.model_nav.ignore_ent = ignoreEnt;
	self.model_nav.path = [];
	self.model_nav.path_idx = 0;
	self.model_nav.last_path_time = 0;
	self.model_nav.last_target_origin = self.origin;
	self.model_nav.last_origin = self.origin;
	self.model_nav.stuck_time = 0;
}

/*
///DocStringBegin
detail: <Entity> model_nav_reset_path(): <Void>
summary: Resets the current path and stuck progress for the script_model.
///DocStringEnd
*/
model_nav_reset_path()
{
	if (!isDefined(self.model_nav))
		self model_nav_init();

	self.model_nav.path = [];
	self.model_nav.path_idx = 0;
	self.model_nav.last_path_time = 0;
	self.model_nav.last_target_origin = self.origin;
	self.model_nav.stuck_time = 0;
	self.model_nav.last_origin = self.origin;
}

/*
///DocStringBegin
detail: <Entity> model_nav_should_repath(targetPos: <Vector3>, repathTime: <Int>, repathDistSq: <Float>, maxStuckTime: <Float>): <Bool>
summary: Evaluates whether the script_model needs to calculate a new path to the target.
///DocStringEnd
*/
model_nav_should_repath(targetPos, repathTime, repathDistSq, maxStuckTime)
{
	if (!isDefined(self.model_nav) || !isDefined(self.model_nav.path) || !self.model_nav.path.size)
		return true;

	if (self.model_nav.path_idx >= self.model_nav.path.size)
		return true;

	rTime = isDefined(repathTime) ? repathTime : MODEL_NAV_REPATH_TIME;
	if (gettime() - self.model_nav.last_path_time >= rTime)
		return true;

	rDistSq = isDefined(repathDistSq) ? repathDistSq : MODEL_NAV_REPATH_DIST_SQ;
	if (isDefined(targetPos) && isDefined(self.model_nav.last_target_origin))
	{
		if (distanceSquared(self.model_nav.last_target_origin, targetPos) >= rDistSq)
			return true;
	}

	mStuck = isDefined(maxStuckTime) ? maxStuckTime : 1.2;
	if (self.model_nav.stuck_time >= mStuck)
		return true;

	return false;
}

/*
///DocStringBegin
detail: <Entity> model_nav_build_path(dest: <Vector3>, team: <String>): <Bool>
summary: Calculates an A* path from the model origin to dest using botActor waypoints.
///DocStringEnd
*/
model_nav_build_path(dest, team)
{
	if (!isDefined(self.model_nav))
		self model_nav_init();

	lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return false;

	if (!lethalbeats\botactor\navigation::_botNavigationUsePathBudget(gettime()))
		return false;

	searchTeam = isDefined(team) ? team : "axis";
	rawPath = self lethalbeats\botactor\navigation::bot_astar_search(self.origin, dest, searchTeam, false);
	if (!isDefined(rawPath) || !rawPath.size)
	{
		self model_nav_reset_path();
		return false;
	}

	positions = [];
	for (i = rawPath.size - 1; i >= 0; i--)
	{
		idx = rawPath[i];
		if (!isDefined(level.waypoints[idx]))
			continue;

		positions[positions.size] = level.waypoints[idx].origin;
	}
	positions[positions.size] = dest;

	self.model_nav.path = positions;
	self.model_nav.path_idx = 1;
	self.model_nav.last_path_time = gettime();
	self.model_nav.last_target_origin = dest;
	self.model_nav.stuck_time = 0;
	return positions.size > 1;
}

/*
///DocStringBegin
detail: <Entity> model_nav_step_trace(from: <Vector3>, to: <Vector3>, stepZ: <Float>, ignoreEnt: <Entity>): <Vector3 | Undefined>
summary: Performs a raised player physics capsule trace between two points to test step clearance.
///DocStringEnd
*/
model_nav_step_trace(from, to, stepZ, ignoreEnt)
{
	liftZ = isDefined(stepZ) ? stepZ : MODEL_NAV_STEP_Z;
	lift = (0, 0, liftZ);

	ign = ignoreEnt;
	if (!isDefined(ign) && isDefined(self.model_nav) && isDefined(self.model_nav.ignore_ent))
		ign = self.model_nav.ignore_ent;
	if (!isDefined(ign))
		ign = self;

	start = playerPhysicsTrace(from, from + lift, false, ign);
	if (!isDefined(start))
		start = from + lift;

	end = playerPhysicsTrace(to, to + lift, false, ign);
	if (!isDefined(end))
		end = to + lift;

	hit = playerPhysicsTrace(start, end, false, ign);
	if (!isDefined(hit))
		return undefined;

	return hit;
}

/*
///DocStringBegin
detail: <Entity> model_nav_can_step(from: <Vector3>, to: <Vector3>, stepZ: <Float>, slopSq: <Float>, ignoreEnt: <Entity>): <Bool>
summary: Returns true if the model can physics-step from point from to to without collision blocking.
///DocStringEnd
*/
model_nav_can_step(from, to, stepZ, slopSq, ignoreEnt)
{
	hit = self model_nav_step_trace(from, to, stepZ, ignoreEnt);
	if (!isDefined(hit))
		return false;

	liftZ = isDefined(stepZ) ? stepZ : MODEL_NAV_STEP_Z;
	sSq = isDefined(slopSq) ? slopSq : MODEL_NAV_STEP_SLOP_SQ;
	return distanceSquared(hit, to + (0, 0, liftZ)) <= sSq;
}

/*
///DocStringBegin
detail: <Entity> model_nav_deflect(dir: <Vector3>, stepDist: <Float>, stepZ: <Float>, slopSq: <Float>, ignoreEnt: <Entity>, anglesList: <Float[]>): <Vector3 | Undefined>
summary: Finds an alternate clear direction by rotating yaw along deflection angles.
///DocStringEnd
*/
model_nav_deflect(dir, stepDist, stepZ, slopSq, ignoreEnt, anglesList)
{
	yaw = vectorToYaw(dir);
	deflections = isDefined(anglesList) ? anglesList : MODEL_NAV_DEFLECT_ANGLES;

	for (i = 0; i < deflections.size; i++)
	{
		test = anglesToForward((0, yaw + deflections[i], 0));
		test = vectorNormalize((test[0], test[1], 0));

		probe = self.origin + (test * stepDist);
		if (self model_nav_can_step(self.origin, probe, stepZ, slopSq, ignoreEnt))
			return test;
	}

	return undefined;
}

/*
///DocStringBegin
detail: <Entity> model_nav_get_ground(point: <Vector3>, ignoreEnt: <Entity>, minNormalZ: <Float>): <Struct | Undefined>
summary: Traces downward to find walkable ground position and normal under point.
///DocStringEnd
*/
model_nav_get_ground(point, ignoreEnt, minNormalZ)
{
	if (!isDefined(point))
		return undefined;

	ign = ignoreEnt;
	if (!isDefined(ign) && isDefined(self.model_nav) && isDefined(self.model_nav.ignore_ent))
		ign = self.model_nav.ignore_ent;
	if (!isDefined(ign))
		ign = self;

	minZ = isDefined(minNormalZ) ? minNormalZ : MODEL_NAV_MIN_GROUND_NORMAL_Z;

	start = point + (0, 0, 24);
	end = point - (0, 0, 96);
	trace = bulletTrace(start, end, false, ign);

	if (isDefined(trace) && isDefined(trace["position"]) && trace["surfacetype"] != "none" && trace["normal"][2] >= minZ)
	{
		if (trace["position"][2] < self.origin[2] - 15)
			trace["position"] = playerPhysicsTrace(start, end, false, ign);
		return trace;
	}

	step = 12;
	radius = 36;
	bestDist = 999999;
	bestTrace = undefined;

	for (x = -radius; x <= radius; x += step)
	{
		for (y = -radius; y <= radius; y += step)
		{
			start = point + (x, y, 24);
			end = point + (x, y, -96);
			trace = bulletTrace(start, end, false, ign);

			if (!isDefined(trace)) continue;
			if (!isDefined(trace["position"])) continue;
			if (trace["surfacetype"] == "none") continue;
			if (trace["normal"][2] < minZ) continue;

			if (trace["position"][2] < self.origin[2] - 15)
				trace["position"] = playerPhysicsTrace(start, end, false, ign);

			dist = distanceSquared(point, trace["position"]);
			if (dist < bestDist)
			{
				bestDist = dist;
				bestTrace = trace;
			}
		}
	}

	return bestTrace;
}

/*
///DocStringBegin
detail: <Entity> model_nav_get_ground_angles(ground: <Struct>, targetYaw: <Float>, maxPitch: <Float>, maxRoll: <Float>, minNormalZ: <Float>): <Vector3>
summary: Computes aligned pitch, yaw, and roll orientation for an entity on a slope.
///DocStringEnd
*/
model_nav_get_ground_angles(ground, targetYaw, maxPitch, maxRoll, minNormalZ)
{
	flatAngles = (0, targetYaw, 0);
	if (!isDefined(ground) || !isDefined(ground["normal"]))
		return flatAngles;

	minZ = isDefined(minNormalZ) ? minNormalZ : MODEL_NAV_MIN_GROUND_NORMAL_Z;
	if (ground["normal"][2] < minZ)
		return flatAngles;

	groundAngles = lethalbeats\vector::vector_angles_orient_to_normal(ground["normal"], targetYaw);
	pitch = angleClamp180(groundAngles[0]);
	roll = angleClamp180(groundAngles[2]);

	mPitch = isDefined(maxPitch) ? maxPitch : MODEL_NAV_MAX_ORIENT_PITCH;
	mRoll = isDefined(maxRoll) ? maxRoll : MODEL_NAV_MAX_ORIENT_ROLL;

	if (abs(pitch) > mPitch || abs(roll) > mRoll)
		return flatAngles;

	return (pitch, targetYaw, roll);
}

/*
///DocStringBegin
detail: <Entity> model_nav_can_move_direct(goalPos: <Vector3>, ignoreEnt: <Entity>, maxZDelta: <Float>): <Bool>
summary: Tests if a direct line to goalPos is walkable and on navigable ground.
///DocStringEnd
*/
model_nav_can_move_direct(goalPos, ignoreEnt, maxZDelta)
{
	if (!isDefined(goalPos))
		return false;

	maxZ = isDefined(maxZDelta) ? maxZDelta : 48;
	if (abs(goalPos[2] - self.origin[2]) > maxZ)
		return false;

	if (!self model_nav_can_step(self.origin, goalPos, undefined, undefined, ignoreEnt))
		return false;

	return self model_nav_path_is_navigable(self.origin, goalPos);
}

/*
///DocStringBegin
detail: <Entity> model_nav_path_is_navigable(start: <Vector3>, end: <Vector3>, maxDistSq: <Float>, maxZ: <Float>): <Bool>
summary: Verifies that samples along start-end segment stay within reach of waypoint graph.
///DocStringEnd
*/
model_nav_path_is_navigable(start, end, maxDistSq, maxZ)
{
	lethalbeats\botactor\navigation::_botactorEnsureWaypoints();
	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return true;

	distSq = distanceSquared(start, end);
	if (distSq < 64 * 64)
		return true;

	dist = sqrt(distSq);
	dir = (end[0] - start[0], end[1] - start[1], end[2] - start[2]);
	dir = (dir[0] / dist, dir[1] / dist, dir[2] / dist);

	step = 64;
	samples = int(dist / step);
	if (samples < 1)
		samples = 1;

	mDistSq = isDefined(maxDistSq) ? maxDistSq : (140 * 140);
	mZ = isDefined(maxZ) ? maxZ : 64;

	for (i = 1; i <= samples; i++)
	{
		samplePos = start + (dir[0] * (step * i), dir[1] * (step * i), dir[2] * (step * i));
		nearest = lethalbeats\botactor\navigation::_botgetNearestWaypoint(samplePos, true);

		if (!isDefined(nearest) || !isDefined(level.waypoints[nearest]))
			return false;

		wpOrigin = level.waypoints[nearest].origin;
		if (distanceSquared((wpOrigin[0], wpOrigin[1], samplePos[2]), samplePos) > mDistSq)
			return false;

		if (abs(wpOrigin[2] - samplePos[2]) > mZ)
			return false;
	}

	return true;
}

/*
///DocStringBegin
detail: <Entity> model_nav_apply_separation(dir: <Vector3>, targetOrigin: <Vector3>, prevPos: <Vector3>, groupList: <Entity[]>, radius: <Float>): <Vector3>
summary: Computes boids separation steering vector against members of groupList.
///DocStringEnd
*/
model_nav_apply_separation(dir, targetOrigin, prevPos, groupList, radius)
{
	if (!isDefined(groupList) || groupList.size <= 1)
		return dir;

	separationRadius = isDefined(radius) ? radius : MODEL_NAV_SEPARATION_RADIUS;
	separationRadiusSq = separationRadius * separationRadius;
	separationForce = (0, 0, 0);
	nearbyCount = 0;

	myDistToTarget = distance(self.origin, targetOrigin);
	isMoving = distanceSquared(self.origin, prevPos) > 4;

	if (!isMoving)
		return dir;

	foreach (other in groupList)
	{
		if (!isDefined(other) || other == self)
			continue;

		distToOtherSq = distanceSquared(self.origin, other.origin);
		if (distToOtherSq < separationRadiusSq && distToOtherSq > 1)
		{
			awayDir = (self.origin[0] - other.origin[0], self.origin[1] - other.origin[1], 0);
			if (awayDir[0] == 0 && awayDir[1] == 0)
				awayDir = (1, 0, 0);
			else
				awayDir = vectorNormalize(awayDir);

			strength = 1.0 - (sqrt(distToOtherSq) / separationRadius);
			separationForce = separationForce + (awayDir * strength);
			nearbyCount++;
		}
	}

	if (nearbyCount > 0)
	{
		separationForce = vectorNormalize(separationForce);
		separationWeight = 0.0;
		if (myDistToTarget > 200)
		{
			if (myDistToTarget > 600)
				separationWeight = 0.4;
			else
				separationWeight = ((myDistToTarget - 200) / 400) * 0.4;
		}

		desiredWeight = 1.0 - separationWeight;
		return vectorNormalize((dir * desiredWeight) + (separationForce * separationWeight));
	}

	return dir;
}

/*
///DocStringBegin
detail: <Entity> model_nav_step_towards(dest: <Vector3>, target?: <Entity>, separationEnts?: <Entity[]>): <Struct>
summary: Performs one physical movement step towards dest, handling ground alignment, deflection, and separation.
///DocStringEnd
*/
model_nav_step_towards(dest, target, separationEnts)
{
	step = spawnstruct();
	step.result = "moving";
	step.yaw_delta = 0;
	step.target_yaw = self.angles[1];

	if (!isDefined(dest))
	{
		step.result = "blocked";
		return step;
	}

	delta = (dest[0] - self.origin[0], dest[1] - self.origin[1], 0);
	distSq = lengthSquared(delta);

	if (distSq <= MODEL_NAV_GOAL_REACHED_SQ)
	{
		step.result = "reached";
		return step;
	}

	speed = isDefined(self.model_nav) && isDefined(self.model_nav.speed) ? self.model_nav.speed : MODEL_NAV_DEFAULT_SPEED;
	tick = isDefined(self.model_nav) && isDefined(self.model_nav.tick) ? self.model_nav.tick : MODEL_NAV_DEFAULT_TICK;

	targetYaw = vectorToYaw(delta);
	yawDelta = angleClamp180(targetYaw - self.angles[1]);

	step.yaw_delta = yawDelta;
	step.target_yaw = targetYaw;

	if (abs(yawDelta) > 135)
	{
		step.result = "turn180";
		return step;
	}

	dir = vectorNormalize(delta);
	stepDist = speed * tick;
	dist = sqrt(distSq);
	if (stepDist > dist) stepDist = dist;

	targetOrigin = isDefined(target) ? target.origin : dest;
	if (isDefined(separationEnts) && separationEnts.size)
		dir = self model_nav_apply_separation(dir, targetOrigin, self.origin, separationEnts, MODEL_NAV_SEPARATION_RADIUS);

	next = self.origin + (dir * stepDist);

	if (!(self model_nav_can_step(self.origin, next, MODEL_NAV_STEP_Z, MODEL_NAV_STEP_SLOP_SQ, self.model_nav.ignore_ent)))
	{
		dir = self model_nav_deflect(dir, stepDist, MODEL_NAV_STEP_Z, MODEL_NAV_STEP_SLOP_SQ, self.model_nav.ignore_ent, MODEL_NAV_DEFLECT_ANGLES);
		if (!isDefined(dir))
		{
			if (!isDefined(self.model_nav.blocked_ticks)) self.model_nav.blocked_ticks = 0;
			self.model_nav.blocked_ticks++;
			self.model_nav.stuck_time += tick;

			if (self.model_nav.blocked_ticks >= MODEL_NAV_BLOCKED_TICKS)
				step.result = "blocked";
			else
				step.result = "waiting";

			return step;
		}

		next = self.origin + (dir * stepDist);
		targetYaw = vectorToYaw(dir);
		step.target_yaw = targetYaw;
	}

	self.model_nav.blocked_ticks = 0;

	ground = self model_nav_get_ground(next, self.model_nav.ignore_ent, MODEL_NAV_MIN_GROUND_NORMAL_Z);
	nextAngles = (0, targetYaw, 0);
	if (isDefined(ground) && isDefined(ground["position"]))
	{
		next = ground["position"];
		nextAngles = model_nav_get_ground_angles(ground, targetYaw, MODEL_NAV_MAX_ORIENT_PITCH, MODEL_NAV_MAX_ORIENT_ROLL, MODEL_NAV_MIN_GROUND_NORMAL_Z);
	}

	moveDuration = tick + 0.04;
	self rotateTo(nextAngles, moveDuration);
	self moveTo(next, moveDuration);

	if (isDefined(self.model_nav.last_origin) && distanceSquared(self.origin, self.model_nav.last_origin) <= MODEL_NAV_STUCK_DIST_SQ)
		self.model_nav.stuck_time += tick;
	else
	{
		self.model_nav.stuck_time = 0;
		self.model_nav.last_origin = self.origin;
	}

	if (self.model_nav.stuck_time > 1.2)
	{
		step.result = "stuck";
		return step;
	}

	return step;
}
