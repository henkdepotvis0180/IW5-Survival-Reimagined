/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : ai_squad         |
|Creator : LastDemon99	   |
|Type : AI / Behavior      |
============================
*/

#include lethalbeats\botActor\navigation;
#include lethalbeats\botActor\utility;
#include lethalbeats\array;

#define SQUAD_REFERENCE 120
#define SQUAD_MOVE_GOAL 121
#define SQUAD_NEXT_MOVE_TIME 122
#define SQUAD_IS_STOPPED 123
#define SQUAD_CHASE_TARGET 124
#define SQUAD_CHASE_MIN_SQ 125
#define SQUAD_CHASE_MAX_SQ 126
#define SQUAD_CHASE_NEXT_ISSUE 127
#define CHASE_TARGET 22
#define SKILL_CHASE_DIST_MIN 76
#define SKILL_CHASE_DIST_MAX 77

/*
///DocStringBegin
detail: bot_squad_create(members?: <Entity[]>): <Struct>
summary: Creates a coordinated tactical squad and starts its runtime loop.
///DocStringEnd
*/
bot_squad_create(members)
{
	squad = spawnstruct();
	squad.members = [];
	squad.leader = undefined;
	squad.target = undefined;
	squad.enabled_targets = [];
	squad.mode = "hold";
	squad.tick = 0.15;
	squad.active = true;
	squad.chase_dist_min = 192;
	squad.chase_dist_max = 700;

	if (isDefined(members) && members.size)
	{
		for (i = 0; i < members.size; i++)
			squad bot_squad_add_member(members[i]);
	}

	if (!isDefined(squad.leader) && squad.members.size)
		squad.leader = squad.members[0];

	squad thread _botSquadRuntime();
	return squad;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_add_member(bot: <Entity>): <Bool>
summary: Adds a bot to the squad and assigns its persistent squad task.
///DocStringEnd
*/
bot_squad_add_member(bot)
{
	if (!isDefined(bot))
		return false;

	if (!isPlayer(bot))
		return false;

	if (!isDefined(self.members))
		self.members = [];

	if (self _botSquadHasMember(bot))
		return true;

	if (isDefined(bot.actor[SQUAD_REFERENCE]) && bot.actor[SQUAD_REFERENCE] != self)
	{
		prev = bot.actor[SQUAD_REFERENCE];
		if (isDefined(prev.members))
			prev.members = lethalbeats\array::array_remove(prev.members, bot);
		if (isDefined(prev.leader) && prev.leader == bot)
			prev.leader = undefined;
	}

	self.members[self.members.size] = bot;
	bot.actor[SQUAD_REFERENCE] = self;
	bot.actor[SQUAD_MOVE_GOAL] = undefined;
	bot.actor[SQUAD_CHASE_TARGET] = undefined;
	bot.actor[SQUAD_IS_STOPPED] = false;

	if (isDefined(self.enabled_targets))
		bot bot_enable_target(self.enabled_targets);
	if (isDefined(self.target))
		bot bot_set_target(self.target);

	if (!isDefined(self.leader))
		self.leader = bot;

	bot lethalbeats\botactor\behavior::bot_do(lethalbeats\botactor\behavior::bot_task_custom(::_botSquadMemberRun, self));

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_remove_member(bot: <Entity>): <Bool>
summary: Removes a bot from the squad and clears its squad state.
///DocStringEnd
*/
bot_squad_remove_member(bot)
{
	if (!isDefined(self.members))
		return false;

	if (!isDefined(bot))
		return false;

	self.members = lethalbeats\array::array_remove(self.members, bot);

	if (isDefined(bot.actor[SQUAD_REFERENCE]) && bot.actor[SQUAD_REFERENCE] == self)
	{
		bot.actor[SQUAD_REFERENCE] = undefined;
		bot lethalbeats\botactor\behavior::bot_clear();
	}

	if (isDefined(self.leader) && self.leader == bot)
	{
		if (self.members.size)
			self.leader = self.members[0];
		else
			self.leader = undefined;
	}

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_set_leader(bot: <Entity>): <Bool>
summary: Sets the squad leader.
///DocStringEnd
*/
bot_squad_set_leader(bot)
{
	if (!isDefined(bot))
		return false;

	self bot_squad_add_member(bot);
	self.leader = bot;
	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_set_target(target: <Entity>): <Bool>
summary: Sets a primary target across all valid squad members.
///DocStringEnd
*/
bot_squad_set_target(target)
{
	if (isDefined(target) && !(self _botSquadTargetIsValid(target)))
		target = undefined;

	self.target = target;

	if (!isDefined(self.members))
		return true;

	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (!(self _botSquadMemberIsValid(bot)))
			continue;

		bot bot_set_target(target);
	}

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_enable_target(targets: <Entity | Entity[]>): <Bool>
summary: Sets enabled target list for squad member target acquisition.
///DocStringEnd
*/
bot_squad_enable_target(targets)
{
	enabled = [];

	if (isDefined(targets))
	{
		if (isArray(targets))
		{
			for (i = 0; i < targets.size; i++)
			{
				target = targets[i];
				if (!(self _botSquadTargetIsValid(target)))
					continue;

				enabled[enabled.size] = target;
			}
		}
		else
		{
			if (self _botSquadTargetIsValid(targets))
				enabled[enabled.size] = targets;
		}
	}

	self.enabled_targets = enabled;

	if (!isDefined(self.members))
		return true;

	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (!(self _botSquadMemberIsValid(bot)))
			continue;

		bot bot_enable_target(enabled);
	}

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_go_to(goal: <Vector3>, stop_dist?: <Float>, wp_timeout?: <Float>, goal_timeout?: <Float>): <Bool>
summary: Dispatches a move order to all members of the squad.
///DocStringEnd
*/
bot_squad_go_to(goal, stop_dist, wp_timeout, goal_timeout)
{
	if (!isDefined(self.members) || !self.members.size)
		return false;

	self.mode = "external";
	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (!(self _botSquadMemberIsValid(bot)))
			continue;

		bot bot_release_melee_charge();
		self _botSquadIssueMove(bot, goal, stop_dist, wp_timeout, goal_timeout);
	}

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_patrol(points: <Vector3[]>, timers?: <Float[]>, angles?: <Vector3[]>, loop?: <Bool>, stop_dist?: <Float>, wp_timeout?: <Float>, goal_timeout?: <Float>): <Bool>
summary: Commands all squad members to patrol the specified route.
///DocStringEnd
*/
bot_squad_patrol(points, timers, angles, loop, stop_dist, wp_timeout, goal_timeout)
{
	if (!isDefined(self.members) || !self.members.size)
		return false;

	self.mode = "external";
	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (!(self _botSquadMemberIsValid(bot)))
			continue;

		bot bot_release_melee_charge();
		bot.actor[SQUAD_MOVE_GOAL] = undefined;
		bot.actor[SQUAD_CHASE_TARGET] = undefined;

		bot lethalbeats\botactor\ai_patrol::bot_patrol(points, timers, angles, loop);
	}

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_melee_charge(target: <Entity>): <Bool>
summary: Orders the squad to execute a melee charge on the target.
///DocStringEnd
*/
bot_squad_melee_charge(target)
{
	if (!isDefined(self.members) || !self.members.size)
		return false;

	self.mode = "external";
	self.target = target;
	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (!(self _botSquadMemberIsValid(bot)))
			continue;

		bot bot_hold_melee_charge();
		self _botSquadIssueChase(bot, target, self.chase_dist_min, self.chase_dist_max);
	}

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_chase(target: <Entity>, dist_min?: <Float>, dist_max?: <Float>): <Bool>
summary: Commands squad members to chase and engage the target.
///DocStringEnd
*/
bot_squad_chase(target, dist_min, dist_max)
{
	if (!isDefined(self.members) || !self.members.size)
		return false;

	if (isDefined(target) && !(self _botSquadTargetIsValid(target)))
		target = undefined;

	self.mode = "chase";
	self.target = target;

	if (isDefined(dist_min))
		self.chase_dist_min = dist_min;
	if (isDefined(dist_max))
		self.chase_dist_max = dist_max;

	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (!(self _botSquadMemberIsValid(bot)))
			continue;

		if (isDefined(dist_min)) bot.actor[SKILL_CHASE_DIST_MIN] = dist_min;
		if (isDefined(dist_max)) bot.actor[SKILL_CHASE_DIST_MAX] = dist_max;
		self _botSquadIssueChase(bot, target, self.chase_dist_min, self.chase_dist_max);
	}

	return true;
}

/*
///DocStringBegin
detail: <Struct> bot_squad_delete(): <Void>
summary: Disbands the squad and clears tasks for all members.
///DocStringEnd
*/
bot_squad_delete()
{
	self.active = false;

	if (!isDefined(self.members))
		return;

	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (!isDefined(bot))
			continue;

		if (isDefined(bot.actor[SQUAD_REFERENCE]) && bot.actor[SQUAD_REFERENCE] == self)
			bot.actor[SQUAD_REFERENCE] = undefined;

		bot bot_set_target(undefined);
		bot bot_enable_target(undefined);
		bot.actor[SQUAD_MOVE_GOAL] = undefined;
		bot.actor[SQUAD_CHASE_TARGET] = undefined;

		bot lethalbeats\botactor\behavior::bot_clear();
	}

	self.members = [];
	self.leader = undefined;
	self.target = undefined;
	self.enabled_targets = [];
}

_botSquadRuntime()
{
	for (;;)
	{
		if (!isDefined(self.active) || !self.active)
			return;

		self _botSquadPruneMembers();
		if (!isDefined(self.members) || !self.members.size)
		{
			self.active = false;
			return;
		}

		if (!(self _botSquadMemberIsValid(self.leader)))
			self.leader = self.members[0];

		forced_target = self.target;
		if (!(self _botSquadTargetIsValid(forced_target)))
			forced_target = undefined;
		self.target = forced_target;

		target = forced_target;
		if (!isDefined(target))
			target = self _botSquadPickEnabledTarget();

		mode = "hold";
		if (isDefined(self.mode))
			mode = self.mode;

		apply_target = true;
		if (mode == "external" && !isDefined(forced_target))
			apply_target = false;

		leader = self.leader;
		if (!(self _botSquadMemberIsValid(leader)))
		{
			wait 0.15;
			continue;
		}

		for (i = 0; i < self.members.size; i++)
		{
			member = self.members[i];
			if (!(self _botSquadMemberIsValid(member)))
				continue;

			if (apply_target)
				self _botSquadApplyTarget(member, target);
		}

		if (mode == "external")
		{
			wait self.tick;
			continue;
		}
		else if (mode == "chase")
		{
			chase_min = 192;
			chase_max = 700;
			if (isDefined(self.chase_dist_min))
				chase_min = self.chase_dist_min;
			if (isDefined(self.chase_dist_max))
				chase_max = self.chase_dist_max;

			for (i = 0; i < self.members.size; i++)
			{
				member = self.members[i];
				if (!(self _botSquadMemberIsValid(member)))
					continue;

				self _botSquadIssueChase(member, target, chase_min, chase_max);
			}

			wait self.tick;
			continue;
		}
		else if (mode == "advance")
		{
			if (isDefined(target) && isDefined(target.origin))
				self _botSquadIssueMove(leader, target.origin, 96, 2.0, 5.0);
			else
				self _botSquadIssueStop(leader);
		}
		else if (mode == "riotstack")
		{
			if (isDefined(target))
			{
				leader bot_hold_melee_charge();
				self _botSquadIssueChase(leader, target, self.chase_dist_min, self.chase_dist_max);
			}
			else
				self _botSquadIssueStop(leader);
		}
		else
			self _botSquadIssueStop(leader);

		followers = lethalbeats\array::array_remove(self.members, leader);
		for (i = 0; i < followers.size; i++)
		{
			follower = followers[i];
			if (!(self _botSquadMemberIsValid(follower)))
				continue;

			goal = self _botSquadGetFollowerGoal(leader, target, i, followers.size, mode);
			stop = 48;
			if (mode == "riotstack")
				stop = 24;

			self _botSquadIssueMove(follower, goal, stop, 2.0, 5.0);
		}

		wait self.tick;
	}
}

_botSquadPruneMembers()
{
	if (!isDefined(self.members))
	{
		self.members = [];
		return;
	}

	new_members = [];
	for (i = 0; i < self.members.size; i++)
	{
		bot = self.members[i];
		if (self _botSquadMemberIsValid(bot))
			new_members[new_members.size] = bot;
	}

	self.members = new_members;
}

_botSquadMemberIsValid(bot)
{
	if (!isDefined(bot))
		return false;

	if (!isPlayer(bot))
		return false;

	return isAlive(bot);
}

_botSquadHasMember(bot)
{
	if (!isDefined(self.members))
		return false;

	for (i = 0; i < self.members.size; i++)
	{
		if (self.members[i] == bot)
			return true;
	}

	return false;
}

_botSquadTargetIsValid(target)
{
	if (!isDefined(target))
		return false;

	if (isPlayer(target))
	{
		if (!isAlive(target))
			return false;

		if (isDefined(target.sessionteam) && target.sessionteam == "spectator")
			return false;
	}
	else if (isDefined(target.health) && target.health <= 0)
		return false;

	return true;
}

_botSquadPickEnabledTarget()
{
	if (!isDefined(self.enabled_targets) || !self.enabled_targets.size)
		return undefined;

	anchor = undefined;
	if (self _botSquadMemberIsValid(self.leader))
		anchor = self.leader;
	else if (isDefined(self.members) && self.members.size)
		anchor = self.members[0];

	best = undefined;
	bestSq = 0;
	haveBestSq = false;
	new_enabled = [];

	for (i = 0; i < self.enabled_targets.size; i++)
	{
		target = self.enabled_targets[i];
		if (isDefined(anchor) && target == anchor)
			continue;
		if (!(self _botSquadTargetIsValid(target)))
			continue;

		new_enabled[new_enabled.size] = target;
		if (!isDefined(target.origin))
		{
			if (!isDefined(best))
				best = target;
			continue;
		}

		if (!isDefined(anchor) || !isDefined(anchor.origin))
		{
			if (!isDefined(best))
				best = target;
			continue;
		}

		sq = distanceSquared(anchor.origin, target.origin);
		if (!haveBestSq || sq < bestSq)
		{
			best = target;
			bestSq = sq;
			haveBestSq = true;
		}
	}

	self.enabled_targets = new_enabled;
	return best;
}

_botSquadApplyTarget(bot, target)
{
	if (!isDefined(bot))
		return;

	current = bot lethalbeats\botactor\targeting::bot_get_current_target();

	if (!isDefined(current) && !isDefined(target))
		return;

	if (isDefined(current) && isDefined(target) && current == target)
		return;

	bot bot_set_targets(target);
}

_botSquadIssueStop(bot)
{
	if (!isDefined(bot))
		return;

	if (isDefined(bot.actor[SQUAD_IS_STOPPED]) && bot.actor[SQUAD_IS_STOPPED])
		return;

	bot.actor[SQUAD_MOVE_GOAL] = undefined;
	bot.actor[SQUAD_CHASE_TARGET] = undefined;
	bot.actor[SQUAD_NEXT_MOVE_TIME] = 0;
	bot.actor[SQUAD_IS_STOPPED] = true;
}

_botSquadIssueMove(bot, goal, stop_dist, wp_timeout, goal_timeout)
{
	if (!isDefined(bot) || !isDefined(goal))
		return;

	now = gettime();
	last_goal = undefined;
	if (isDefined(bot.actor[SQUAD_MOVE_GOAL]))
		last_goal = bot.actor[SQUAD_MOVE_GOAL];

	next_time = 0;
	if (isDefined(bot.actor[SQUAD_NEXT_MOVE_TIME]))
		next_time = bot.actor[SQUAD_NEXT_MOVE_TIME];

	need_issue = false;
	if (!isDefined(last_goal))
		need_issue = true;
	else if (distanceSquared(last_goal, goal) > 64 * 64)
		need_issue = true;
	else if (now >= next_time)
		need_issue = true;

	if (!need_issue)
		return;

	bot.actor[SQUAD_MOVE_GOAL] = goal;
	bot.actor[SQUAD_NEXT_MOVE_TIME] = now + 350;
	bot.actor[SQUAD_IS_STOPPED] = false;
	bot.actor[SQUAD_CHASE_TARGET] = undefined;
	bot.squad_move_stop_dist = stop_dist;
	bot.squad_move_wp_timeout = wp_timeout;
	bot.squad_move_goal_timeout = goal_timeout;
}

_botSquadIssueChase(bot, target, chase_min, chase_max)
{
	if (!isDefined(bot))
		return;

	now = gettime();
	last_target = undefined;
	if (isDefined(bot.actor[SQUAD_CHASE_TARGET]))
		last_target = bot.actor[SQUAD_CHASE_TARGET];

	last_min_sq = -1;
	if (isDefined(bot.actor[SQUAD_CHASE_MIN_SQ]))
		last_min_sq = bot.actor[SQUAD_CHASE_MIN_SQ];

	last_max_sq = -1;
	if (isDefined(bot.actor[SQUAD_CHASE_MAX_SQ]))
		last_max_sq = bot.actor[SQUAD_CHASE_MAX_SQ];

	next_issue = 0;
	if (isDefined(bot.actor[SQUAD_CHASE_NEXT_ISSUE]))
		next_issue = bot.actor[SQUAD_CHASE_NEXT_ISSUE];

	min_sq = int(chase_min * chase_min);
	max_sq = int(chase_max * chase_max);
	if (max_sq < min_sq)
		max_sq = min_sq;

	same_target = (!isDefined(last_target) && !isDefined(target)) || (isDefined(last_target) && isDefined(target) && last_target == target);
	same_dist = (last_min_sq == min_sq && last_max_sq == max_sq);

	if (same_target && same_dist && now < next_issue)
		return;

	bot.actor[SQUAD_CHASE_TARGET] = target;
	bot.actor[SQUAD_CHASE_MIN_SQ] = min_sq;
	bot.actor[SQUAD_CHASE_MAX_SQ] = max_sq;
	bot.actor[SQUAD_CHASE_NEXT_ISSUE] = now + 750;
	bot.actor[SQUAD_MOVE_GOAL] = undefined;
	if (isDefined(chase_min)) bot.actor[SKILL_CHASE_DIST_MIN] = chase_min;
	if (isDefined(chase_max)) bot.actor[SKILL_CHASE_DIST_MAX] = chase_max;
}

_botSquadMemberRun(squad)
{
	for (;;)
	{
		self.ba.runner_beat = gettime();

		if (!isDefined(squad) || !isDefined(squad.active) || !squad.active)
			return true;

		if (!isDefined(self.actor[SQUAD_REFERENCE]) || self.actor[SQUAD_REFERENCE] != squad)
			return true;

		target = self.actor[SQUAD_CHASE_TARGET];
		if (isDefined(target) && isDefined(target.origin))
		{
			self bot_set_target(target);
			self.actor[CHASE_TARGET] = target;
			self lethalbeats\botactor\navigation::_botChaseLoop(target);
			self.ba.runner_beat = gettime();
			continue;
		}

		if (isDefined(self.actor[SQUAD_IS_STOPPED]) && self.actor[SQUAD_IS_STOPPED])
		{
			self bot_stop_move();
			wait 0.1;
			continue;
		}

		goal = self.actor[SQUAD_MOVE_GOAL];
		if (!isDefined(goal))
		{
			wait 0.1;
			continue;
		}

		stopDist = isDefined(self.squad_move_stop_dist) ? self.squad_move_stop_dist : 48;
		wpTimeout = isDefined(self.squad_move_wp_timeout) ? self.squad_move_wp_timeout : 2.0;
		goalTimeout = isDefined(self.squad_move_goal_timeout) ? self.squad_move_goal_timeout : 5.0;

		self lethalbeats\botactor\navigation::bot_go_to(goal, stopDist, wpTimeout, goalTimeout, false, false);
		self.ba.runner_beat = gettime();
	}
}

_botSquadGetFollowerGoal(leader, target, slot_index, follower_count, mode)
{
	if (!isDefined(leader))
		return undefined;

	yaw = leader.angles[1];
	if (isDefined(target) && isDefined(target.origin))
	{
		dir = target.origin - leader.origin;
		if (lengthsquared((dir[0], dir[1], 0)) > 1)
		{
			look = vectorToAngles((dir[0], dir[1], 0));
			yaw = look[1];
		}
	}

	if (mode == "riotstack")
	{
		if (slot_index == 0)
			return self _botSquadGoalFromPolar(leader.origin, yaw - 145, 45);
		if (slot_index == 1)
			return self _botSquadGoalFromPolar(leader.origin, yaw + 145, 45);

		offset_idx = slot_index - 2;
		return self _botSquadGoalFromPolar(leader.origin, yaw + 180 + offset_idx * 25, 70);
	}

	if (follower_count <= 0)
		return leader.origin;

	step = 40;
	start = 180 - ((follower_count - 1) * step * 0.5);
	slot_yaw = yaw + start + slot_index * step;
	return self _botSquadGoalFromPolar(leader.origin, slot_yaw, 96);
}

_botSquadGoalFromPolar(origin, yaw, dist)
{
	dir = anglesToForward((0, yaw, 0));
	goal = origin + dir * dist;
	return (goal[0], goal[1], origin[2]);
}
