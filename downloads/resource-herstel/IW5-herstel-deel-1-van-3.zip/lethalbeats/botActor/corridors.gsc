/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : corridors        |
|Creator : LastDemon99	   |
|Type : AI / Navigation    |
============================
*/

#include lethalbeats\botActor\navigation;
#include lethalbeats\botActor\config;

#define CORRIDOR_MIN_WAYPOINTS 3
#define CORRIDOR_YIELD_EVERY 96

/*
///DocStringBegin
detail: bot_corridor_map(target: <Entity>): <Struct | Undefined>
summary: Returns cached corridor map for target, rebuilding when stale or target moved.
///DocStringEnd
*/
bot_corridor_map(target)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return undefined;

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return undefined;

	if (!isDefined(level.botactor_corridors))
		level.botactor_corridors = [];

	key = target getEntityNumber() + "";
	map = level.botactor_corridors[key];

	now = gettime();
	refreshMs = lethalbeats\botactor\config::bot_config_get("corridor_refresh_ms");
	moveDist = lethalbeats\botactor\config::bot_config_get("corridor_move_dist");

	if (isDefined(map))
	{
		fresh = (now - map.built_at) < refreshMs;
		stillThere = distanceSquared(map.origin, target.origin) < (moveDist * moveDist);

		if (fresh && stillThere)
			return map;

		if (isDefined(map.building) && map.building)
			return map;
	}

	built = _botCorridorBuild(target);
	if (!isDefined(built))
		return map;

	level.botactor_corridors[key] = built;
	return built;
}

_botCorridorBuild(target)
{
	targetWp = lethalbeats\botactor\navigation::_botgetNearestWaypoint(target.origin, true);
	if (!isDefined(targetWp))
		return undefined;

	rootWp = level.waypoints[targetWp];
	if (!isDefined(rootWp) || !isDefined(rootWp.children) || !rootWp.children.size)
		return undefined;

	map = spawnstruct();
	map.built_at = gettime();
	map.origin = target.origin;
	map.target_wp = targetWp;
	map.building = true;
	map.wp_root = [];
	map.wp_dist = [];
	map.roots = [];
	map.sizes = [];

	map.wp_root[targetWp + ""] = -1;
	map.wp_dist[targetWp + ""] = 0;

	queue = [];
	queueRoot = [];
	for (i = 0; i < rootWp.children.size; i++)
	{
		child = rootWp.children[i];
		if (!isDefined(child))
			continue;

		childStr = child + "";
		if (isDefined(map.wp_root[childStr]))
			continue;

		corridorId = map.roots.size;
		map.roots[corridorId] = child;
		map.sizes[corridorId] = 1;
		map.wp_root[childStr] = corridorId;
		map.wp_dist[childStr] = 1;

		queue[queue.size] = child;
		queueRoot[queueRoot.size] = corridorId;
	}

	if (!map.roots.size)
		return undefined;

	head = 0;
	expanded = 0;
	while (head < queue.size)
	{
		wpIdx = queue[head];
		corridorId = queueRoot[head];
		head++;

		wp = level.waypoints[wpIdx];
		if (!isDefined(wp) || !isDefined(wp.children))
			continue;

		myDist = map.wp_dist[wpIdx + ""];

		for (i = 0; i < wp.children.size; i++)
		{
			child = wp.children[i];
			if (!isDefined(child))
				continue;

			childStr = child + "";
			if (isDefined(map.wp_root[childStr]))
				continue;

			map.wp_root[childStr] = corridorId;
			map.wp_dist[childStr] = myDist + 1;
			map.sizes[corridorId] = map.sizes[corridorId] + 1;

			queue[queue.size] = child;
			queueRoot[queueRoot.size] = corridorId;
		}

		expanded++;
		if ((expanded % CORRIDOR_YIELD_EVERY) == 0)
			wait 0.05;
	}

	map.building = false;
	return map;
}

/*
///DocStringBegin
detail: bot_corridor_of_position(map: <Struct>, pos: <Vector3>): <Int>
summary: Returns corridor id for a given world position, or -1 if unreachable.
///DocStringEnd
*/
bot_corridor_of_position(map, pos)
{
	if (!isDefined(map) || !isDefined(pos))
		return -1;

	wpIdx = lethalbeats\botactor\navigation::_botgetNearestWaypoint(pos, true);
	if (!isDefined(wpIdx))
		return -1;

	id = map.wp_root[wpIdx + ""];
	if (!isDefined(id))
		return -1;

	return id;
}

/*
///DocStringBegin
detail: bot_corridor_usable(map: <Struct>): <Int[]>
summary: Returns corridor IDs meeting the minimum waypoint threshold.
///DocStringEnd
*/
bot_corridor_usable(map)
{
	usable = [];
	if (!isDefined(map) || !isDefined(map.roots))
		return usable;

	for (i = 0; i < map.roots.size; i++)
	{
		size = map.sizes[i];
		if (!isDefined(size) || size < CORRIDOR_MIN_WAYPOINTS)
			continue;

		usable[usable.size] = i;
	}

	if (!usable.size)
	{
		for (i = 0; i < map.roots.size; i++)
			usable[usable.size] = i;
	}

	return usable;
}

/*
///DocStringBegin
detail: bot_corridor_gate(map: <Struct>, corridorId: <Int>): <Vector3 | Undefined>
summary: Returns world position of corridor entry root waypoint.
///DocStringEnd
*/
bot_corridor_gate(map, corridorId)
{
	if (!isDefined(map) || !isDefined(corridorId) || corridorId < 0)
		return undefined;

	if (!isDefined(map.roots[corridorId]))
		return undefined;

	return lethalbeats\botactor\navigation::_botGetWaypointOrigin(map.roots[corridorId]);
}

/*
///DocStringBegin
detail: bot_corridor_far_point(map: <Struct>, corridorId: <Int>, minHops: <Int>): <Vector3 | Undefined>
summary: Returns a staging waypoint origin inside the corridor with minimum hops.
///DocStringEnd
*/
bot_corridor_far_point(map, corridorId, minHops)
{
	if (!isDefined(map) || !isDefined(corridorId) || corridorId < 0)
		return undefined;

	if (!isDefined(minHops) || minHops < 1)
		minHops = 2;

	best = undefined;
	bestDist = -1;

	foreach (wpStr in getArrayKeys(map.wp_root))
	{
		if (map.wp_root[wpStr] != corridorId)
			continue;

		d = map.wp_dist[wpStr];
		if (!isDefined(d) || d < minHops)
			continue;

		if (d > bestDist)
		{
			bestDist = d;
			best = wpStr;
		}
	}

	if (!isDefined(best))
		return bot_corridor_gate(map, corridorId);

	return lethalbeats\botactor\navigation::_botGetWaypointOrigin(int(best));
}

/*
///DocStringBegin
detail: bot_corridor_debug(target: <Entity>): <Void>
summary: Prints debug information about current corridor mapping.
///DocStringEnd
*/
bot_corridor_debug(target)
{
	if (getDvarInt("botactor_debug", 0) <= 0) return;
	map = bot_corridor_map(target);
	if (!isDefined(map))
	{
		print("BOTACTOR_CORRIDOR: no map (no waypoints, or target unreachable)");
		return;
	}

	usable = bot_corridor_usable(map);
	print("BOTACTOR_CORRIDOR", "target_wp", map.target_wp, "corridors", map.roots.size, "usable", usable.size, "age_ms", gettime() - map.built_at);

	for (i = 0; i < map.roots.size; i++)
	{
		gate = bot_corridor_gate(map, i);
		gateStr = "none";
		if (isDefined(gate))
			gateStr = int(gate[0]) + "," + int(gate[1]);

		print("BOTACTOR_CORRIDOR", "id", i, "seed_wp", map.roots[i], "waypoints", map.sizes[i], "gate", gateStr);
	}
}
