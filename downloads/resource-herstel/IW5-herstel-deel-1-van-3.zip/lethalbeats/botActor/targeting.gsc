/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : targeting        |
|Creator : LastDemon99	   |
|Type : AI / Targeting     |
============================
*/

#include lethalbeats\botactor\utility;
#include lethalbeats\botactor\combat;

#define LOCK 0
#define SCRIPT_MOVE 3
#define AIM_POS 41
#define MOVE_LOOK_DIR 45
#define AIM_OFFSET_VEC 42
#define AIM_OFFSET_START 43
#define AIM_OFFSET_END 44
#define TARGET_MONITOR 5
#define BEHAVIOR_QUICKSCOPE 105
#define LAST_FIRE_TIME 116
#define ENABLED_TARGETS 40
#define HEARTBEAT_TARGET 6
#define CHASE_NEXT_HANDOVER 25
#define HEARTBEAT_NAV 7
#define HEARTBEAT_MOVE 8
#define PATH_LOCK 4
#define CHASE_TARGET 22

#define SKILL_AIM_TIME 60
#define SKILL_INIT_REACT_TIME 61
#define SKILL_REACTION_TIME 62
#define SKILL_NO_TRACE_ADS_TIME 63
#define SKILL_NO_TRACE_LOOK_TIME 64
#define SKILL_REMEMBER_TIME 65
#define SKILL_LOCATION_REMEMBER_TIME 66
#define SKILL_FOV 67
#define SKILL_DIST_MAX 68
#define SKILL_SHOOT_AFTER_TIME 69
#define SKILL_AIM_OFFSET_TIME 70
#define SKILL_AIM_OFFSET_AMOUNT 71
#define SKILL_BONE_UPDATE_INTERVAL 72
#define SKILL_BONES 73
#define SKILL_ADS_FOV_MULTI 74
#define SKILL_ADS_AIMSPEED_MULTI 75
#define SKILL_DIST_START 170
#define SKILL_CHASE_DIST_MIN 76

_botSkillTimeToMs(value, defaultSeconds)
{
	if (!isDefined(value))
		value = defaultSeconds;

	if (!isDefined(value))
		return 0;

	v = float(value);
	if (v <= 0)
		return 0;

	if (v > 50)
		return int(v);

	return int(v * 1000);
}

_botTargetOpt(name)
{
	return lethalbeats\botactor\config::bot_config_get(name);
}

_botTargetIsLiteGoap()
{
	return isDefined(self.goap) && isDefined(self.goap.full_allowed) && !self.goap.full_allowed;
}

_botGetTargetSightPos(target)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return undefined;

	if (isPlayer(target))
	{
		headPos = target getEye();
		if (isDefined(headPos)) return headPos;
		headPos = target getTagOrigin("j_head");
		if (isDefined(headPos)) return headPos;
		return target.origin + (0, 0, 55);
	}

	return target.origin + (0, 0, 40);
}

/*
///DocStringBegin
detail: bot_update_target(): <Entity | Undefined>
summary: Selects and returns the best valid target for this bot.
///DocStringEnd
*/
bot_update_target()
{
	return self bot_select_target();
}

/*
///DocStringBegin
detail: bot_get_current_target(): <Entity | Undefined>
summary: Returns current active target entity.
///DocStringEnd
*/
bot_get_current_target()
{
	return self bot_select_target();
}

/*
///DocStringBegin
detail: <Player> bot_get_effective_target(): <Entity | Undefined>
summary: Returns active combat target or chase target if valid and alive.
///DocStringEnd
*/
bot_get_effective_target()
{
	target = self bot_get_current_target();
	if (isDefined(target) && isAlive(target))
	{
		if (!isPlayer(target) || ((!isDefined(target.sessionState) || target.sessionState == "playing") && (!isDefined(target.inLastStand) || !target.inLastStand)))
			return target;
	}

	target = self.actor[CHASE_TARGET];
	if (isDefined(target) && isAlive(target))
	{
		if (!isPlayer(target) || ((!isDefined(target.sessionState) || target.sessionState == "playing") && (!isDefined(target.inLastStand) || !target.inLastStand)))
			return target;
	}

	return undefined;
}

/*
///DocStringBegin
detail: <Player> bot_mark_chase_target(target: <Entity>): <Void>
summary: Sets chase target and registers it as the bot's current focus target.
///DocStringEnd
*/
bot_mark_chase_target(target)
{
	self.actor[CHASE_TARGET] = target;
	self bot_set_target(target);
}

/*
///DocStringBegin
detail: <Player> bot_has_target_sight(target: <Entity>, ignoreEnt?: <Entity>): <Bool>
summary: Returns true if the bot has clear sightline to the target's eyes or head.
///DocStringEnd
*/
bot_has_target_sight(target, ignoreEnt)
{
	return self _botHasTargetSight(target, ignoreEnt);
}

_botHasTargetSight(target, ignoreEnt)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return false;

	eye = self getEye();
	if (!isDefined(eye))
		eye = self.origin + (0, 0, 55);

	targetPos = self _botGetTargetSightPos(target);
	if (!isDefined(targetPos))
		return false;

	ign = isDefined(ignoreEnt) ? ignoreEnt : self;

	if (sightTracePassed(eye, targetPos, false, ign))
		return true;

	if (bulletTracePassed(eye, targetPos, false, ign))
		return true;

	trace = bulletTrace(eye, targetPos, false, ign);
	if (isDefined(trace))
		return (trace["fraction"] >= 0.95 || (isDefined(trace["surfacetype"]) && trace["surfacetype"] == "glass"));

	return false;
}

_botTargetTraceForBone(target, eye, bone)
{
	if (!isDefined(target) || !isDefined(eye) || !isDefined(bone) || bone == "")
		return false;

	bonePos = undefined;
	if (bone == "getEye" && isPlayer(target))
		bonePos = target getEye();
	else
		bonePos = target getTagOrigin(bone);

	if (!isDefined(bonePos))
		return false;

	if (sightTracePassed(eye, bonePos, false, self))
		return true;

	if (bulletTracePassed(eye, bonePos, false, self))
		return true;

	trace = bulletTrace(eye, bonePos, false, self);
	if (isDefined(trace))
	{
		if (trace["fraction"] >= 0.95)
			return true;
		if (isDefined(trace["surfacetype"]) && trace["surfacetype"] == "glass")
			return true;
	}

	return false;
}

_botHasTargetSightBones(target, eye)
{
	if (!isDefined(target) || !isPlayer(target) || !isDefined(eye))
		return false;

	eyePos = target getEye();
	if (isDefined(eyePos) && (sightTracePassed(eye, eyePos, false, self) || bulletTracePassed(eye, eyePos, false, self)))
		return true;

	bonesCsv = self bot_get_skill(SKILL_BONES, "j_head,j_neck,j_spine4,j_shoulder_ri,j_shoulder_le,j_ankle_le,j_ankle_ri");
	bones = strTok(bonesCsv, ",");

	for (i = 0; i < bones.size; i++)
	{
		if (self _botTargetTraceForBone(target, eye, bones[i]))
			return true;
	}

	return (self _botTargetTraceForBone(target, eye, "j_head") ||
			self _botTargetTraceForBone(target, eye, "j_neck") ||
			self _botTargetTraceForBone(target, eye, "j_spine4") ||
			self _botTargetTraceForBone(target, eye, "j_ankle_le") ||
			self _botTargetTraceForBone(target, eye, "j_ankle_ri"));
}

_botTargetGetAimPos(target, weaponClass)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return undefined;

	if (!isDefined(weaponClass))
	{
		curWeap = self getCurrentWeapon();
		weaponClass = self _botCombatGetWeaponClass(curWeap);
	}

	aimPos = undefined;
	if (isPlayer(target))
	{
		eye = self getEye();
		if (!isDefined(eye))
			eye = self.origin + (0, 0, 60);

		chestPos = target getTagOrigin("j_spine4");
		if (!isDefined(chestPos)) chestPos = target getTagOrigin("j_spineupper");
		if (!isDefined(chestPos)) chestPos = target.origin + (0, 0, 38);

		headPos = target getEye();
		if (!isDefined(headPos)) headPos = target getTagOrigin("j_head");
		if (!isDefined(headPos)) headPos = target.origin + (0, 0, 56);

		if (weaponClass == "projectile" || weaponClass == "shotgun")
		{
			aimPos = chestPos;
		}
		else
		{
			// Check if chest is clear; if chest is blocked by cover (e.g. ledge/low wall), aim at visible head!
			if (bulletTracePassed(eye, chestPos, false, self))
				aimPos = chestPos;
			else if (bulletTracePassed(eye, headPos, false, self) || sightTracePassed(eye, headPos, false, self))
				aimPos = headPos;
			else
				aimPos = chestPos;
		}

		targetVel = target getVelocity();
		if (isDefined(targetVel) && lengthSquared(targetVel) > 25)
		{
			dist = distance(self.origin, target.origin);
			if (weaponClass == "projectile")
			{
				flightSec = dist / 2000.0;
				if (flightSec > 1.2) flightSec = 1.2;
				aimPos += targetVel * flightSec;
			}
			else
			{
				aimPos += targetVel * 0.08;
			}
		}
	}
	else
	{
		aimPos = target.origin + (0, 0, 40);
	}

	return aimPos;
}

_botTargetCanAdsIw5Style(distSq, weaponClass, conedot)
{
	if (weaponClass == "riot")
		return false;

	adsAmount = self playerAds();
	threshold = 0.75;
	if (adsAmount > 0)
		threshold = 0.70;

	if (conedot < threshold)
		return false;

	shootDist = self bot_get_weapon_shoot_distance();
	if (distSq < shootDist["min"] * shootDist["min"])
		return false;

	return true;
}

_botTargetCanAttackByFov(targetOrig)
{
	skillFov = self bot_get_skill(SKILL_FOV, -1);
	if (skillFov == -1)
		return true;

	if (!isDefined(targetOrig))
		return false;

	return lethalbeats\vector::vector_get_cone_dot(targetOrig, self.origin, self getPlayerAngles()) >= skillFov;
}

/*
///DocStringBegin
detail: <Player> _botTargetCanSenseTarget(targetObj: <Struct>): <Bool>
summary: Returns true if target is within sensory perception (CQC distance, FOV cone, recent tracking, damage, or gunfire).
///DocStringEnd
*/
_botTargetCanSenseTarget(targetObj)
{
	if (!isDefined(targetObj) || !isDefined(targetObj.entity))
		return false;

	// 1. Assigned chase target is always sensed (the bot was specifically tasked to hunt this entity)
	if (isDefined(self.actor[CHASE_TARGET]) && self.actor[CHASE_TARGET] == targetObj.entity)
		return true;

	// 2. Point-blank / CQC proximity awareness (senses any threat within close quarters)
	cqcDist = _botTargetOpt("sense_cqc_spot_dist");
	if (cqcDist < 384) cqcDist = 384;
	if (targetObj.distSq <= cqcDist * cqcDist)
		return true;

	// 3. Already actively tracked and maintained in sight
	if (targetObj.trace_time > 0)
		return true;

	// 4. Reacting to recent damage alert from this attacker (within 3.0s)
	if (isDefined(self.bot_damaged_by) && self.bot_damaged_by == targetObj.entity && gettime() < self.bot_damaged_time + 3000)
		return true;

	// 5. Reacting to heard unsuppressed gunfire (within 2.5s)
	if (isDefined(self.bot_heard_target) && self.bot_heard_target == targetObj.entity && gettime() < self.bot_heard_time + 2500)
		return true;

	// 6. Forward vision cone (FOV)
	if (!_botTargetOpt("sense_fov_enabled"))
		return true;

	skillFov = self bot_get_skill(SKILL_FOV, -1);
	if (skillFov <= 0)
		return true;

	myAngles = self getPlayerAngles();
	dot = lethalbeats\vector::vector_get_cone_dot(targetObj.entity.origin, self.origin, myAngles);
	return dot >= skillFov;
}

/*
///DocStringBegin
detail: bot_target_on_damage(eAttacker: <Entity>, iDamage: <Int>, sWeapon: <String>): <Void>
summary: Senses and alerts the bot when taking damage from an attacker.
///DocStringEnd
*/
bot_target_on_damage(eAttacker, iDamage, sWeapon)
{
	if (!isDefined(eAttacker) || !isPlayer(eAttacker) || eAttacker == self)
		return;

	if (!lethalbeats\botactor\config::bot_config_get("damage_alert_enabled"))
		return;

	self.bot_damaged_by = eAttacker;
	self.bot_damaged_time = gettime();

	// Auto-preservation check on critical health
	critPct = lethalbeats\botactor\config::bot_config_get("health_critical_pct");
	if (critPct > 0 && self.health < (self.maxHealth * float(critPct) / 100.0))
	{
		self notify("bot_health_critical", eAttacker);
		if (!isDefined(self.actor["strafe_active"]) && randomint(100) < 60)
		{
			strafeDir = (randomint(2) * 2 - 1) * 127;
			self thread lethalbeats\botactor\combat::_botCombatDoStrafe(strafeDir);
		}
	}
}

_botTargetApplyAimOffset(now, aimPos)
{
	if (!isDefined(aimPos))
		return undefined;

	if (isDefined(self.actor[AIM_OFFSET_VEC]) && isDefined(self.actor[AIM_OFFSET_END]) && now < self.actor[AIM_OFFSET_END])
	{
		offsetScale = 1.0;
		if (isDefined(self.actor[AIM_OFFSET_START]))
		{
			totalMs = self.actor[AIM_OFFSET_END] - self.actor[AIM_OFFSET_START];
			if (totalMs > 0) offsetScale = float(self.actor[AIM_OFFSET_END] - now) / float(totalMs);
		}

		if (offsetScale < 0) offsetScale = 0;
		return aimPos + (self.actor[AIM_OFFSET_VEC] * offsetScale);
	}

	self.actor[AIM_OFFSET_VEC] = undefined;
	self.actor[AIM_OFFSET_START] = 0;
	self.actor[AIM_OFFSET_END] = 0;

	return aimPos;
}

_botTargetRuntimeReset(state, stopAttack)
{
	if (stopAttack)
		self bot_stop_attack();

	self.actor[AIM_POS] = undefined;
	self.actor[AIM_OFFSET_VEC] = undefined;
	self.actor[AIM_OFFSET_START] = 0;
	self.actor[AIM_OFFSET_END] = 0;

	state.nextFireTime = 0;
	state.nextMeleeTime = 0;
	state.nextReactTime = 0;
	state.fireShotsRemaining = 0;
	state.firePauseUntil = 0;
	state.fireWindUpUntil = 0;
	state.nextBehaviorStrafe = 0;
	state.nextBehaviorNade = 0;
	state.nextBehaviorSprint = 0;
	state.nextBehaviorCrouch = 0;
	state.nextBehaviorJump = 0;
	state.currentTargetEntNum = -1;
}

_botTargetOfferChase(target)
{
	if (!isDefined(target) || !isDefined(target.origin))
		return;

	if (isDefined(self.goap))
		return;

	if (self lethalbeats\botactor\utility::bot_is_reacting())
		return;

	if (!self lethalbeats\botactor\behavior::bot_engagement_allows_chase())
		return;

	if (isDefined(self.actor[PATH_LOCK]) && self.actor[PATH_LOCK])
		return;

	kind = self lethalbeats\botactor\behavior::bot_task_kind();
	if (isDefined(kind))
	{
		if (kind == "hunt")
		{
			current = self.ba.task;
			if (isDefined(current) && isDefined(current.ent) && current.ent == target)
				return;
		}
		else if (kind == "custom")
			return;
	}

	self lethalbeats\botactor\behavior::bot_do(lethalbeats\botactor\behavior::bot_task_hunt(target));
}

_botCreateTargetObj(entity, now)
{
	obj = spawnStruct();
	obj.entity = entity;
	obj.last_seen_pos = (0, 0, 0);
	obj.distSq = 0;
	obj.time = now;
	obj.trace_time = 0;
	obj.no_trace_time = 0;
	obj.trace_time_time = 0;
	obj.didlook = false;
	obj.aimPos = undefined;
	obj.hasSight = false;
	obj.hasLos = false;
	return obj;
}

_botTargetNotifyChanged(state, newTargetObj, now)
{
    newEntNum = -1;
	if (isDefined(newTargetObj) && isDefined(newTargetObj.entity))
		newEntNum = newTargetObj.entity getEntityNumber();

	if (state.currentTargetEntNum == newEntNum)
		return;

	if (state.currentTargetEntNum != -1)
	{
		prevEnt = undefined;
		if (isDefined(self.bot.targets[state.currentTargetEntNum]))
			prevEnt = self.bot.targets[state.currentTargetEntNum].entity;

		if (newEntNum == -1)
		{
			self notify("bot_lost_target", prevEnt);
			self.actor[CHASE_TARGET] = undefined;
		}
		else
		{
			self notify("bot_target_switched", prevEnt, newTargetObj.entity);
			self notify("bot_new_target", newTargetObj.entity);
			self.actor[CHASE_TARGET] = newTargetObj.entity;
			self _botTargetOfferChase(newTargetObj.entity);
		}
	}
	else if (newEntNum != -1)
	{
		self notify("bot_new_target", newTargetObj.entity);
		self.actor[CHASE_TARGET] = newTargetObj.entity;
		self _botTargetOfferChase(newTargetObj.entity);
	}

	state.currentTargetEntNum = newEntNum;

	if (newEntNum != -1)
	{
		initReactMs = self _botSkillTimeToMs(self bot_get_skill(SKILL_INIT_REACT_TIME, 0), 0);
		state.nextReactTime = now + max(initReactMs, 0);
		state.nextFireTime = now;

		aimOffsetTimeMs = self _botSkillTimeToMs(self bot_get_skill(SKILL_AIM_OFFSET_TIME, 0), 0);
		aimOffsetAmount = self bot_get_skill(SKILL_AIM_OFFSET_AMOUNT, 0);

		state.fireShotsRemaining = 1;
		state.firePauseUntil = now;
		state.fireWindUpUntil = now;

		if (aimOffsetTimeMs > 0 && aimOffsetAmount > 0)
		{
			rx = randomFloatRange(-1.0, 1.0);
			ry = randomFloatRange(-1.0, 1.0);
			rz = randomFloatRange(-0.45, 0.45);
			randDir = vectorNormalize((rx, ry, rz));
			offsetMax = float(aimOffsetAmount) * 18.0;
			self.actor[AIM_OFFSET_VEC] = randDir * offsetMax;
			self.actor[AIM_OFFSET_START] = now;
			self.actor[AIM_OFFSET_END] = now + aimOffsetTimeMs;
		}
	}
}

_botTargetLoop()
{
	self notify("bot_target_loop");
	self endon("bot_target_loop");
	self endon("disconnect");
	self endon("death");

	if (!isDefined(self.bot))
		self.bot = spawnStruct();

	if (!isDefined(self.bot.targets))
		self.bot.targets = [];

	state = spawnStruct();
	self _botTargetRuntimeReset(state, false);
	self thread lethalbeats\botactor\combat::bot_combat_init_reload_watcher();

	for (;;)
	{
		liteGoap = self _botTargetIsLiteGoap();
		loopMs = 50;
		if (liteGoap)
			loopMs = _botTargetOpt("lite_target_ms");
		loopWait = float(loopMs) * 0.001;

		wait loopWait;
		now = gettime();
		self.actor[TARGET_MONITOR] = now;
		self.actor[HEARTBEAT_TARGET] = now;
		eye = self getEye();

		if (!self lethalbeats\botactor\behavior::bot_engagement_allows_targets())
		{
			if (isDefined(self.actor[AIM_POS]))
			{
				self bot_stop_attack();
				self.actor[AIM_POS] = undefined;
				self.bot.targets = [];
				state.currentTargetEntNum = -1;
			}
			continue;
		}

		validEntities = self bot_get_valid_targets(self.actor[ENABLED_TARGETS]);

		activeEntNums = [];
		foreach (ent in validEntities)
		{
			if (!isDefined(ent) || !isDefined(ent.origin)) continue;

			entNum = ent getEntityNumber();
			activeEntNums[entNum] = true;

			if (!isDefined(self.bot.targets[entNum]))
				self.bot.targets[entNum] = self _botCreateTargetObj(ent, now);
		}

		rememberTime = self bot_get_skill(SKILL_REMEMBER_TIME);
		rememberMs = 9999999;
		if (isDefined(rememberTime))
			rememberMs = self _botSkillTimeToMs(rememberTime, 2.5);
		foreach (entNum, targetObj in self.bot.targets)
		{
			if (!isDefined(activeEntNums[entNum]))
			{
				if (isDefined(self.actor[CHASE_TARGET]) && isDefined(targetObj) && isDefined(targetObj.entity) && self.actor[CHASE_TARGET] == targetObj.entity)
				{
					self.actor[CHASE_TARGET] = undefined;
					self notify("bot_chase_end");
				}
				self.bot.targets[entNum] = undefined;
				continue;
			}

			targetObj.distSq = distanceSquared(self.origin, targetObj.entity.origin);

			aimPos = self _botTargetGetAimPos(targetObj.entity);
			if (isDefined(aimPos))
			{
				canSense = self _botTargetCanSenseTarget(targetObj);
				if (!canSense)
				{
					hasSight = false;
					hasLos = false;
				}
				else
				{
					simpleSight = liteGoap && _botTargetOpt("lite_simple_sight") != 0;
					if (simpleSight)
					{
						hasSight = self _botHasTargetSight(targetObj.entity);
						hasLos = hasSight;
					}
					else
					{
						hasLos = bulletTracePassed(eye, aimPos, false, self);
						hasSight = self _botHasTargetSightBones(targetObj.entity, eye) || self _botHasTargetSight(targetObj.entity);

						if (!hasLos && hasSight && isPlayer(targetObj.entity))
						{
							headPos = targetObj.entity getEye();
							if (isDefined(headPos) && (bulletTracePassed(eye, headPos, false, self) || sightTracePassed(eye, headPos, false, self)))
							{
								aimPos = headPos;
								hasLos = true;
							}
						}
					}
				}

				targetObj.hasLos = hasLos;
				targetObj.hasSight = hasSight;

				if (hasLos || hasSight)
				{
					targetObj.last_seen_pos = aimPos;
					targetObj.trace_time += loopMs;
					targetObj.no_trace_time = 0;
					targetObj.trace_time_time = now;
					targetObj.didlook = false;
					targetObj.aimPos = aimPos;
				}
				else
				{
					targetObj.no_trace_time += loopMs;
					targetObj.trace_time = 0;

					noTraceLookMs = self _botSkillTimeToMs(self bot_get_skill(SKILL_NO_TRACE_LOOK_TIME, 0.5), 0.5);
					shootAfterMs = self _botSkillTimeToMs(self bot_get_skill(SKILL_SHOOT_AFTER_TIME, 0.2), 0.2);
					suppressMs = max(noTraceLookMs, shootAfterMs);
					if (suppressMs > 0 && targetObj.no_trace_time <= suppressMs)
						targetObj.aimPos = targetObj.last_seen_pos;
					else
						targetObj.aimPos = undefined;
				}
			}
			else
			{
				targetObj.no_trace_time += loopMs;
				targetObj.trace_time = 0;
				targetObj.aimPos = undefined;
			}

			if (targetObj.no_trace_time > rememberMs)
			{
				if (isDefined(self.actor[CHASE_TARGET]) && self.actor[CHASE_TARGET] == targetObj.entity)
					self notify("bot_chase_end");

				self.bot.targets[entNum] = undefined;
			}
		}

		bestTarget = undefined;
		bestScore = 999999999;

		foreach (entNum, targetObj in self.bot.targets)
		{
			distMax = self bot_get_skill(SKILL_DIST_MAX, 0);
			isCurrent = (state.currentTargetEntNum == entNum);
			if (distMax > 0 && targetObj.distSq > distMax * distMax && !isCurrent)
				continue;

			score = targetObj.distSq;
			if (targetObj.trace_time > 0)
				score -= 1000000;

			if (score < bestScore)
			{
				bestScore = score;
				bestTarget = targetObj;
			}
		}

		self _botTargetNotifyChanged(state, bestTarget, now);

		// Offer chase only when the bot has no active task to avoid overriding current work
		if (isDefined(bestTarget) && isDefined(bestTarget.entity) && !self lethalbeats\botactor\behavior::bot_task_active())
			self _botTargetOfferChase(bestTarget.entity);

		if (!isDefined(bestTarget))
		{
			self bot_stop_attack();
			self.actor[AIM_POS] = undefined;
			self lethalbeats\botactor\combat::bot_combat_check_tactical_reload();
			continue;
		}

		if (isPlayer(bestTarget.entity) && (!isAlive(bestTarget.entity) || (isDefined(bestTarget.entity.sessionState) && bestTarget.entity.sessionState != "playing") || (isDefined(bestTarget.entity.inLastStand) && bestTarget.entity.inLastStand)))
		{
			self bot_stop_attack();
			self.actor[AIM_POS] = undefined;
			continue;
		}

		if (self lethalbeats\botactor\utility::bot_is_stunned())
		{
			self bot_release_ads();
			self lethalbeats\botactor\movement::bot_set_aim_pos(undefined);
			sprayChance = _botTargetOpt("stun_spray_chance");
			if (sprayChance > 0 && randomint(100) < sprayChance)
				self bot_press_fire(0.1);
			else
				self bot_stop_attack();
			continue;
		}

		aimPos = self _botTargetApplyAimOffset(now, bestTarget.aimPos);
		self lethalbeats\botactor\movement::bot_set_aim_pos(aimPos);

		currentWeapon = self getCurrentWeapon();
		weaponClass = self _botCombatGetWeaponClass(currentWeapon);
		conedot = 0;
		if (isDefined(aimPos))
			conedot = lethalbeats\vector::vector_get_cone_dot(aimPos, eye, self getPlayerAngles());

		self _botCombatTryBehaviors(state, now, bestTarget.entity, bestTarget.hasLos);

		canAttackByFov = self _botTargetCanAttackByFov(bestTarget.entity.origin);
		if (self _botCombatTryMelee(state, now, bestTarget.entity, bestTarget.distSq, weaponClass, canAttackByFov))
			continue;

		if (self lethalbeats\botactor\utility::bot_is_reacting())
		{
			self bot_release_ads();
			self bot_stop_attack();
			continue;
		}

		if (weaponClass == "riot")
		{
			self bot_release_ads();
			self bot_stop_attack();
			continue;
		}

		noTraceAdsMs = self _botSkillTimeToMs(self bot_get_skill(SKILL_NO_TRACE_ADS_TIME, 0), 0);
		canADS = self _botTargetCanAdsIw5Style(bestTarget.distSq, weaponClass, conedot);
		shouldAds = canADS && (bestTarget.hasLos || (noTraceAdsMs > 0 && bestTarget.no_trace_time <= noTraceAdsMs));

		if (weaponClass == "sniper" && self.actor[BEHAVIOR_QUICKSCOPE] && isDefined(self.actor[LAST_FIRE_TIME]) && now - self.actor[LAST_FIRE_TIME] < 1000)
			shouldAds = false;

		goapAttackAction = false;
		if (isDefined(self.goap) && isDefined(self.goap.current_action) && isDefined(self.goap.current_action.name))
		{
			if (self.goap.current_action.name == "attack_target" || self.goap.current_action.name == "attack_from_cover")
				goapAttackAction = true;
		}

		if (self.actor[SCRIPT_MOVE] && !goapAttackAction && !bestTarget.hasLos)
			shouldAds = false;

		if (self lethalbeats\botactor\utility::bot_is_reloading())
			shouldAds = false;

		if (shouldAds) self bot_hold_ads();
		else self bot_release_ads();

		shootAfterMs = self _botSkillTimeToMs(self bot_get_skill(SKILL_SHOOT_AFTER_TIME, 0.2), 0.2);
		lastSeenClear = false;
		if (shootAfterMs > 0 && bestTarget.no_trace_time > 0 && bestTarget.no_trace_time <= shootAfterMs)
			lastSeenClear = true;

		if ((bestTarget.hasLos && bestTarget.hasSight) || lastSeenClear)
		{
			aimTimeMs = self _botSkillTimeToMs(self bot_get_skill(SKILL_AIM_TIME, 0.1), 0.1);
			if (bestTarget.trace_time < aimTimeMs && !lastSeenClear)
			{
				self bot_stop_attack();
				continue;
			}

			realTargetPos = self _botTargetGetAimPos(bestTarget.entity, weaponClass);
			if (lastSeenClear && isDefined(bestTarget.last_seen_pos) && lengthSquared(bestTarget.last_seen_pos) > 1)
				realTargetPos = bestTarget.last_seen_pos;

			if (isDefined(realTargetPos))
			{
				realConedot = lethalbeats\vector::vector_get_cone_dot(realTargetPos, eye, self getPlayerAngles());
				minAimDot = (weaponClass == "projectile") ? 0.88 : 0.94;
				if (realConedot < minAimDot)
				{
					self bot_stop_attack();
					continue;
				}
				conedot = realConedot;
			}

			distMax = self bot_get_skill(SKILL_DIST_MAX, 0);
			if (distMax > 0 && bestTarget.distSq > distMax * distMax)
			{
				self bot_stop_attack();
				continue;
			}

			self _botCombatTryFire(state, now, bestTarget.entity, bestTarget.distSq, weaponClass, conedot, canAttackByFov);
		}
		else
		{
			self bot_stop_attack();
		}
	}
}
