/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : stuckzones       |
|Creator : LastDemon99	   |
|Type : AI / Navigation    |
============================
*/

#include lethalbeats\botactor\utility;
#include lethalbeats\botactor\movement;

#define HEARTBEAT_NAV 7

#define SZ_Z_BAND 140
#define SZ_3D_HEIGHT 30
#define SZ_POINT_TIMEOUT 3000
#define SZ_POINT_REACHED_SQ 48 * 48
#define SZ_TICK 0.1

/*
///DocStringBegin
detail: stuckzone_init(): <Void>
summary: Initializes stuck zones and ignored zones tables for authored volumes.
///DocStringEnd
*/
stuckzone_init()
{
	level.stuckzones = [];
	level.stuckzones_ignored = [];

	// ---- PASTE FROM !stuckzonedump BELOW ----
	stuckzone_add("mp_dome", (342, 1597, -254), (562, 1913, -236));
	stuckzone_route("mp_dome", (440, 1875, -254), (447, 1966, -253));
	stuckzone_route("mp_dome", (506, 1740, -254), (606, 1729, -251));
	// ---- PASTE ABOVE ----
}

/*
///DocStringBegin
detail: stuckzone_add(map: <String>, a: <Vector3>, b: <Vector3>, mode?: <String>): <Void>
summary: Defines a bounding box volume for stuck escape handling.
///DocStringEnd
*/
stuckzone_add(map, a, b, mode)
{
	if (!isDefined(level.stuckzones))
		level.stuckzones = [];

	if (!isDefined(level.stuckzones[map]))
		level.stuckzones[map] = [];

	zone = spawnstruct();
	zone.min = (min(a[0], b[0]), min(a[1], b[1]), min(a[2], b[2]));
	zone.max = (max(a[0], b[0]), max(a[1], b[1]), max(a[2], b[2]));
	zone.mode = "2d";
	zone.routes = [];

	if (isDefined(mode) && toLower(mode) == "3d")
		zone.mode = "3d";

	if (zone.mode == "3d")
	{
		zone.zmin = zone.min[2];
		zone.zmax = zone.max[2] + SZ_3D_HEIGHT;
	}
	else
	{
		zone.zmin = zone.min[2] - SZ_Z_BAND;
		zone.zmax = zone.max[2] + SZ_Z_BAND;
	}

	level.stuckzones[map][level.stuckzones[map].size] = zone;
}

/*
///DocStringBegin
detail: stuckzone_route(map: <String>, a: <Vector3>, b: <Vector3>): <Void>
summary: Adds an exit route (doorway to outside) to the most recent zone.
///DocStringEnd
*/
stuckzone_route(map, a, b)
{
	if (!isDefined(level.stuckzones) || !isDefined(level.stuckzones[map]) || !level.stuckzones[map].size)
		return;

	zone = level.stuckzones[map][level.stuckzones[map].size - 1];

	route = spawnstruct();
	route.a = _stuckZoneSnapToGround(a);
	route.b = _stuckZoneSnapToGround(b);

	zone.routes[zone.routes.size] = route;
}

/*
///DocStringBegin
detail: stuckzone_ignore(map: <String>, a: <Vector3>, b: <Vector3>, mode?: <String>): <Void>
summary: Marks a bounding box volume as non-traversable/ignored by bots (e.g. jump spots, narrow ledges).
///DocStringEnd
*/
stuckzone_ignore(map, a, b, mode)
{
	if (!isDefined(level.stuckzones_ignored))
		level.stuckzones_ignored = [];

	if (!isDefined(level.stuckzones_ignored[map]))
		level.stuckzones_ignored[map] = [];

	zone = spawnstruct();
	zone.min = (min(a[0], b[0]), min(a[1], b[1]), min(a[2], b[2]));
	zone.max = (max(a[0], b[0]), max(a[1], b[1]), max(a[2], b[2]));
	zone.mode = "2d";

	if (isDefined(mode) && toLower(mode) == "3d")
		zone.mode = "3d";

	if (zone.mode == "3d")
	{
		zone.zmin = zone.min[2];
		zone.zmax = zone.max[2] + SZ_3D_HEIGHT;
	}
	else
	{
		zone.zmin = zone.min[2] - SZ_Z_BAND;
		zone.zmax = zone.max[2] + SZ_Z_BAND;
	}

	level.stuckzones_ignored[map][level.stuckzones_ignored[map].size] = zone;
}

/*
///DocStringBegin
detail: stuckzone_is_ignored(origin: <Vector3>): <Bool>
summary: Checks if a 3D point falls inside any registered ignored/blocked zone for the current map.
///DocStringEnd
*/
stuckzone_is_ignored(origin)
{
	if (!isDefined(origin) || !isDefined(level.stuckzones_ignored))
		return false;

	map = getDvar("mapname");
	if (!isDefined(level.stuckzones_ignored[map]))
		return false;

	zones = level.stuckzones_ignored[map];
	for (i = 0; i < zones.size; i++)
	{
		zone = zones[i];
		if (origin[0] < zone.min[0] || origin[0] > zone.max[0])
			continue;
		if (origin[1] < zone.min[1] || origin[1] > zone.max[1])
			continue;
		if (origin[2] < zone.zmin || origin[2] > zone.zmax)
			continue;

		return true;
	}

	return false;
}

/*
///DocStringBegin
detail: stuckzone_find(origin: <Vector3>): <Struct | Undefined>
summary: Finds the active stuck zone containing the given origin.
///DocStringEnd
*/
stuckzone_find(origin)
{
	if (!isDefined(level.stuckzones))
		return undefined;

	map = getDvar("mapname");
	if (!isDefined(level.stuckzones[map]))
		return undefined;

	zones = level.stuckzones[map];
	for (i = 0; i < zones.size; i++)
	{
		zone = zones[i];
		if (!zone.routes.size)
			continue;

		if (origin[0] < zone.min[0] || origin[0] > zone.max[0])
			continue;
		if (origin[1] < zone.min[1] || origin[1] > zone.max[1])
			continue;
		if (origin[2] < zone.zmin || origin[2] > zone.zmax)
			continue;

		return zone;
	}

	return undefined;
}

/*
///DocStringBegin
detail: <Player> stuckzone_exit(zone: <Struct>): <Bool>
summary: Executes a scripted exit route out of the given stuck zone using physical capsule corridors.
///DocStringEnd
*/
stuckzone_exit(zone)
{
	if (!isDefined(zone) || !zone.routes.size)
		return true;

	route = self _stuckZonePick(zone);
	if (!isDefined(route))
		return true;

	distToA = distanceSquared(self.origin, route.a);
	distToB = distanceSquared(self.origin, route.b);

	if (distToB < distToA && self _stuckZoneHasCorridor(self.origin, route.b, self))
	{
		return self _stuckZoneWalk(route.b);
	}

	if (!(self _stuckZoneWalk(route.a)))
		return false;

	return self _stuckZoneWalk(route.b);
}

/*
///DocStringBegin
detail: <Player> _stuckZonePick(zone: <Struct>): <Struct>
summary: Selects the exit route whose entry corridor has full player physics clearance.
///DocStringEnd
*/
_stuckZonePick(zone)
{
	if (!isDefined(zone.routes) || !zone.routes.size)
		return undefined;

	best = zone.routes[0];
	bestDist = distanceSquared(self.origin, best.a);
	bestHasCorridor = self _stuckZoneHasCorridor(self.origin, best.a, self);

	for (i = 1; i < zone.routes.size; i++)
	{
		cand = zone.routes[i];
		distSq = distanceSquared(self.origin, cand.a);
		hasCorridor = self _stuckZoneHasCorridor(self.origin, cand.a, self);

		if (hasCorridor && !bestHasCorridor)
		{
			best = cand;
			bestDist = distSq;
			bestHasCorridor = true;
		}
		else if (hasCorridor == bestHasCorridor && distSq < bestDist)
		{
			best = cand;
			bestDist = distSq;
		}
	}

	return best;
}

_stuckZoneSnapToGround(pos)
{
	if (!isDefined(pos) || !lethalbeats\utility::is_vector(pos))
		return pos;

	ground = playerPhysicsTrace(pos + (0, 0, 24), pos - (0, 0, 256), false, undefined);
	if (isDefined(ground))
		return ground;

	tr = bulletTrace(pos + (0, 0, 24), pos - (0, 0, 256), false, undefined);
	if (tr["fraction"] < 1.0)
		return tr["position"];

	return pos;
}

_stuckZoneHasCorridor(from, to, ignoreEnt)
{
	if (!isDefined(from) || !isDefined(to))
		return false;

	if (!sightTracePassed(from + (0, 0, 30), to + (0, 0, 30), false, ignoreEnt))
		return false;

	lift = (0, 0, 18);
	start = playerPhysicsTrace(from, from + lift, false, ignoreEnt);
	if (!isDefined(start)) start = from + lift;

	end = playerPhysicsTrace(to, to + lift, false, ignoreEnt);
	if (!isDefined(end)) end = to + lift;

	hit = playerPhysicsTrace(start, end, false, ignoreEnt);
	if (!isDefined(hit))
		return false;

	return distanceSquared(hit, end) <= 24 * 24;
}

_stuckZoneWalk(point)
{
	deadline = gettime() + SZ_POINT_TIMEOUT;
	lastPos = self.origin;
	lastMoveTime = gettime();

	for (;;)
	{
		if (!isAlive(self))
			return false;

		now = gettime();
		self.ba.runner_beat = now;
		if (isDefined(self.actor))
			self.actor[HEARTBEAT_NAV] = now;

		self.bot.stop_move = false;
		self.bot.moveto = point;

		toPoint = point - self.origin;
		if (lengthSquared(toPoint) > 1)
			self lethalbeats\botactor\movement::bot_look_at_angles(vectorToAngles(toPoint), 300);

		if (distance2d(self.origin, point) <= 36 || distanceSquared(self.origin, point) <= SZ_POINT_REACHED_SQ)
			return true;

		if (distanceSquared(self.origin, lastPos) > 16 * 16)
		{
			lastPos = self.origin;
			lastMoveTime = now;
		}
		else if (now - lastMoveTime >= 350)
		{
			self lethalbeats\botactor\utility::bot_press_jump(0.18);
			lastMoveTime = now;
		}

		if (now >= deadline)
			return false;

		wait SZ_TICK;
	}
}
