/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : zones            |
|Creator : LastDemon99	   |
|Type : AI / Spatial Cells |
============================
*/

#include lethalbeats\botactor\config;

#define UNION_MERGE_DIST_SQ 25600   // 160 * 160

/*
///DocStringBegin
detail: bot_zones_init(): <Void>
summary: Automatically clusters map waypoints into spatial zones and discovers boundary portals/unions.
///DocStringEnd
*/
bot_zones_init()
{
	if (isDefined(level.bot_zones_initialized) && level.bot_zones_initialized)
		return;

	lethalbeats\botactor\navigation::_botactorEnsureWaypoints();

	if (!isDefined(level.waypoints) || !level.waypoints.size)
		return;

	clusterSize = lethalbeats\botactor\config::bot_config_get("zone_cluster_size");
	if (clusterSize <= 0) clusterSize = 800;

	level.bot_zones = [];
	level.zone_unions = [];
	level.zone_all_unions = [];

	// Step 1: Assign each waypoint to a spatial zone cluster
	for (i = 0; i < level.waypoints.size; i++)
	{
		wp = level.waypoints[i];
		if (!isDefined(wp) || !isDefined(wp.origin))
			continue;

		zoneKey = bot_zone_key(wp.origin, clusterSize);
		wp.zone_id = zoneKey;

		if (!isDefined(level.bot_zones[zoneKey]))
			level.bot_zones[zoneKey] = [];

		list = level.bot_zones[zoneKey];
		list[list.size] = i;
		level.bot_zones[zoneKey] = list;
	}

	// Step 2: Identify boundary portals (unions) connecting distinct zones
	for (i = 0; i < level.waypoints.size; i++)
	{
		wp = level.waypoints[i];
		if (!isDefined(wp) || !isDefined(wp.children) || !wp.children.size)
			continue;

		zoneA = wp.zone_id;
		if (!isDefined(zoneA))
			continue;

		for (c = 0; c < wp.children.size; c++)
		{
			childIdx = wp.children[c];
			if (!isDefined(childIdx) || !isDefined(level.waypoints[childIdx]))
				continue;

			childWp = level.waypoints[childIdx];
			zoneB = childWp.zone_id;
			if (!isDefined(zoneB) || zoneA == zoneB)
				continue;

			portalPos = (wp.origin + childWp.origin) * 0.5;

			// Deduplicate near-identical portals at the same door/opening
			if (_botZoneUnionExists(zoneA, portalPos))
				continue;

			unionObj = spawnStruct();
			unionObj.origin = portalPos;
			unionObj.zoneA = zoneA;
			unionObj.zoneB = zoneB;
			unionObj.wpA = i;
			unionObj.wpB = childIdx;
			unionObj.id = level.zone_all_unions.size;
			unionObj.assigned_count = 0;
			unionObj.assigned_stamp = 0;

			level.zone_all_unions[level.zone_all_unions.size] = unionObj;

			_botZoneAddUnion(zoneA, unionObj);
			_botZoneAddUnion(zoneB, unionObj);
		}
	}

	level.bot_zones_initialized = true;
}

_botZoneAddUnion(zoneKey, unionObj)
{
	if (!isDefined(level.zone_unions[zoneKey]))
		level.zone_unions[zoneKey] = [];

	list = level.zone_unions[zoneKey];
	list[list.size] = unionObj;
	level.zone_unions[zoneKey] = list;
}

_botZoneUnionExists(zoneKey, pos)
{
	if (!isDefined(level.zone_unions[zoneKey]))
		return false;

	list = level.zone_unions[zoneKey];
	for (i = 0; i < list.size; i++)
	{
		if (distanceSquared(list[i].origin, pos) <= UNION_MERGE_DIST_SQ)
			return true;
	}

	return false;
}

/*
///DocStringBegin
detail: bot_zone_key(pos: <Vector3>, clusterSize?: <Int>): <String>
summary: Computes macro-zone string hash key from world position.
///DocStringEnd
*/
bot_zone_key(pos, clusterSize)
{
	if (!isDefined(clusterSize) || clusterSize <= 0)
		clusterSize = lethalbeats\botactor\config::bot_config_get("zone_cluster_size");
	if (clusterSize <= 0) clusterSize = 800;

	zx = int(floor(pos[0] / clusterSize));
	zy = int(floor(pos[1] / clusterSize));
	zz = int(floor(pos[2] / 120));
	return zx + "_" + zy + "_" + zz;
}

/*
///DocStringBegin
detail: bot_zone_get_player_zone(ent: <Entity>): <String | Undefined>
summary: Returns the zone key containing the given entity.
///DocStringEnd
*/
bot_zone_get_player_zone(ent)
{
	if (!isDefined(ent) || !isDefined(ent.origin))
		return undefined;

	return bot_zone_key(ent.origin);
}

/*
///DocStringBegin
detail: bot_zone_get_unions(zoneId: <String>): <Struct[]>
summary: Returns all entrance/exit portals registered for the given zone.
///DocStringEnd
*/
bot_zone_get_unions(zoneId)
{
	if (!isDefined(zoneId) || !isDefined(level.zone_unions) || !isDefined(level.zone_unions[zoneId]))
		return [];

	return level.zone_unions[zoneId];
}

/*
///DocStringBegin
detail: bot_zone_pick_approach_union(bot: <Player>, target: <Entity>, targetZone: <String>): <Struct | Undefined>
summary: Selects a balanced entrance portal into the target's zone, factoring in traffic quotas and flank variety.
///DocStringEnd
*/
bot_zone_pick_approach_union(bot, target, targetZone)
{
	unions = bot_zone_get_unions(targetZone);
	if (!isDefined(unions) || !unions.size)
		return undefined;

	if (unions.size == 1)
		return unions[0];

	maxPerUnion = lethalbeats\botactor\config::bot_config_get("zone_union_max_bots");
	flankPct = lethalbeats\botactor\config::bot_config_get("zone_flank_random_pct");
	now = gettime();

	// Clean expired assignment stamps (older than 8 seconds)
	for (i = 0; i < unions.size; i++)
	{
		if (now - unions[i].assigned_stamp > 8000)
			unions[i].assigned_count = 0;
	}

	available = [];
	for (i = 0; i < unions.size; i++)
	{
		if (unions[i].assigned_count < maxPerUnion)
			available[available.size] = unions[i];
	}

	pool = available.size ? available : unions;

	// Flank variety roulette: randomly pick among candidates to prevent identical clustering
	if (randomint(100) < flankPct && pool.size > 1)
	{
		pick = pool[randomint(pool.size)];
		pick.assigned_count++;
		pick.assigned_stamp = now;
		return pick;
	}

	// Least-congested union nearest to the bot
	best = pool[0];
	bestScore = 999999999;

	for (i = 0; i < pool.size; i++)
	{
		u = pool[i];
		distSq = distanceSquared(bot.origin, u.origin);
		score = distSq + (u.assigned_count * 500 * 500);

		if (score < bestScore)
		{
			bestScore = score;
			best = u;
		}
	}

	best.assigned_count++;
	best.assigned_stamp = now;
	return best;
}

/*
///DocStringBegin
detail: bot_cell_key(pos: <Vector3>, gridSize?: <Int>): <String>
summary: Returns spatial hash key for dynamic A* traffic cells.
///DocStringEnd
*/
bot_cell_key(pos, gridSize)
{
	if (!isDefined(gridSize) || gridSize <= 0)
		gridSize = lethalbeats\botactor\config::bot_config_get("cell_grid_size");
	if (gridSize <= 0) gridSize = 400;

	cx = int(floor(pos[0] / gridSize));
	cy = int(floor(pos[1] / gridSize));
	cz = int(floor(pos[2] / 100));
	return cx + "_" + cy + "_" + cz;
}

/*
///DocStringBegin
detail: bot_cells_traffic_monitor(): <Void>
summary: Lightweight background thread that updates real-time bot population per spatial cell.
///DocStringEnd
*/
bot_cells_traffic_monitor()
{
	level endon("game_ended");
	level notify("bot_cells_traffic_monitor");
	level endon("bot_cells_traffic_monitor");

	for (;;)
	{
		wait 0.2;

		if (!lethalbeats\botactor\config::bot_config_get("cell_rules_enabled"))
			continue;

		gridSize = lethalbeats\botactor\config::bot_config_get("cell_grid_size");
		traffic = [];

		foreach (player in level.players)
		{
			if (!isDefined(player) || !isAlive(player))
				continue;

			if (!isDefined(player.actor))
				continue;

			key = bot_cell_key(player.origin, gridSize);
			if (!isDefined(traffic[key]))
				traffic[key] = 0;

			traffic[key]++;
		}

		level.bot_cell_traffic = traffic;
	}
}

/*
///DocStringBegin
detail: bot_cell_get_penalty(pos: <Vector3>): <Float>
summary: Returns dynamic cost multiplier for A* edge evaluation based on cell congestion.
///DocStringEnd
*/
bot_cell_get_penalty(pos)
{
	if (!isDefined(pos) || !isDefined(level.bot_cell_traffic))
		return 0;

	gridSize = lethalbeats\botactor\config::bot_config_get("cell_grid_size");
	key = bot_cell_key(pos, gridSize);

	count = level.bot_cell_traffic[key];
	if (!isDefined(count) || count <= 0)
		return 0;

	maxBots = lethalbeats\botactor\config::bot_config_get("cell_max_bots_per_cell");
	effectiveCount = count;
	if (maxBots > 0 && effectiveCount > maxBots)
		effectiveCount = maxBots + (effectiveCount - maxBots) * 2;

	weightPct = lethalbeats\botactor\config::bot_config_get("cell_congestion_penalty");
	return float(effectiveCount * weightPct) / 100.0;
}
