/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : movement         |
|Creator : LastDemon99	   |
|Type : AI / Movement      |
============================
*/

#include lethalbeats\botActor\utility;
#include lethalbeats\botActor\navigation;

#define LOCK 0
#define SPRINT_STATE 1
#define HOLD_SPRINT 2
#define SCRIPT_MOVE 3
#define PATROL_ACTIVE 20
#define PATROL_LOOP 21
#define CHASE_TARGET 22
#define AIM_POS 41
#define MOVE_LOOK_DIR 45
#define MOVE_LOOK_MODE 46

#define AIM_POS_STALE_MS 1000
#define HEARTBEAT_MOVE 8
#define QUADRUPED_MODE 130

#define TURN_PATH 18
#define TURN_AIM 45
#define TURN_FORCED 45
#define TURN_ADS_SCALE 0.70

_botMovementOpt(name)
{
	return lethalbeats\botactor\config::bot_config_get(name);
}

_botMovementIsLiteGoap()
{
	return isDefined(self.goap) && isDefined(self.goap.full_allowed) && !self.goap.full_allowed;
}

/*
///DocStringBegin
detail: bot_drive_init(): <Void>
summary: Initializes the drive controller struct with safe defaults.
///DocStringEnd
*/
bot_drive_init()
{
	if (!isDefined(self.ba))
		self.ba = spawnstruct();

	self.ba.look_angles = undefined;
	self.ba.look_angles_until = 0;
	self.ba.strafe = 0;
	self.ba.strafe_until = 0;
	self.ba.stance = "stand";
	self.ba.stance_applied = undefined;
	self.ba.stance_next_check = 0;
	self.ba.move_stop_dist = 16;
	self.ba.blocked = false;
	self.ba.arrived = false;
	self.ba.stuck_count = 0;
	self.ba.speed_sq = 0;
}

/*
///DocStringBegin
detail: bot_look_at_angles(angles: <Vector3>, hold_ms?: <Int>): <Void>
summary: Requests facing explicit angles for the given duration (default 500ms).
///DocStringEnd
*/
bot_look_at_angles(angles, hold_ms)
{
	if (!isDefined(self.ba) || !isDefined(angles))
		return;

	if (!isDefined(hold_ms))
		hold_ms = 500;

	self.ba.look_angles = angles;
	self.ba.look_angles_until = gettime() + hold_ms;
}

/*
///DocStringBegin
detail: <Player> bot_set_aim_pos(pos: <Vector3>): <Void>
summary: Publishes and timestamps a target aim position.
///DocStringEnd
*/
bot_set_aim_pos(pos)
{
	if (!isDefined(self.actor))
		return;

	self.actor[AIM_POS] = pos;

	if (isDefined(self.ba))
		self.ba.aim_pos_time = gettime();
}

/*
///DocStringBegin
detail: <Player> bot_set_look_dir(dir: <Vector3>): <Void>
summary: Publishes and timestamps a look direction vector.
///DocStringEnd
*/
bot_set_look_dir(dir)
{
	if (!isDefined(self.actor))
		return;

	self.actor[MOVE_LOOK_DIR] = dir;

	if (isDefined(self.ba))
		self.ba.look_dir_time = gettime();
}

/*
///DocStringBegin
detail: <Player> bot_clear_aim_pos(): <Void>
summary: Clears published aim position.
///DocStringEnd
*/
bot_clear_aim_pos()
{
	if (isDefined(self.actor))
		self.actor[AIM_POS] = undefined;

	if (isDefined(self.ba))
		self.ba.aim_pos_time = 0;
}

/*
///DocStringBegin
detail: bot_look_clear(): <Void>
summary: Clears explicit facing override.
///DocStringEnd
*/
bot_look_clear()
{
	if (!isDefined(self.ba))
		return;

	self.ba.look_angles = undefined;
	self.ba.look_angles_until = 0;
}

/*
///DocStringBegin
detail: bot_strafe(dir: <Int>, hold_ms?: <Int>): <Void>
summary: Publishes lateral movement bias (-1 left, 1 right, 0 none) for hold_ms.
///DocStringEnd
*/
bot_strafe(dir, hold_ms)
{
	if (!isDefined(self.ba))
		return;

	if (!isDefined(dir))
		dir = 0;

	if (!isDefined(hold_ms))
		hold_ms = 300;

	self.ba.strafe = dir;
	self.ba.strafe_until = gettime() + hold_ms;
}

/*
///DocStringBegin
detail: bot_set_stance(stance: <String>): <Void>
summary: Requests stance ("stand", "crouch", "prone").
///DocStringEnd
*/
bot_set_stance(stance)
{
	if (!isDefined(self.ba) || !isDefined(stance))
		return;

	self.ba.stance = stance;
}

_botApplyStance()
{
	wanted = self.ba.stance;
	if (!isDefined(wanted))
		wanted = "stand";

	changed = !isDefined(self.ba.stance_applied) || self.ba.stance_applied != wanted;

	if (!changed)
	{
		now = gettime();
		if (isDefined(self.ba.stance_next_check) && now < self.ba.stance_next_check)
			return;

		self.ba.stance_next_check = now + 500;

		actual = self getStance();
		if (isDefined(actual) && actual == wanted)
			return;
	}

	self.ba.stance_applied = wanted;

	switch (wanted)
	{
		case "crouch":
			self botaction("+gocrouch");
			self botaction("-goprone");
			break;

		case "prone":
			self botaction("-gocrouch");
			self botaction("+goprone");
			break;

		default:
			self botaction("-gocrouch");
			self botaction("-goprone");
			break;
	}
}

_botResolveLook(world_dir, unstuck_active, now)
{
	res = spawnstruct();
	res.forced = false;
	res.angles = undefined;
	res.turn = TURN_PATH;

	// Unstuck maneuver forces head orientation
	if (unstuck_active)
	{
		if (lengthsquared(world_dir) > 1)
		{
			res.angles = vectortoangles(world_dir);
			res.forced = true;
			res.turn = TURN_FORCED;
			return res;
		}
	}

	// Aim at published target (highest priority during combat)
	moveLookMode = self.actor[MOVE_LOOK_MODE];
	if (!isDefined(moveLookMode) || moveLookMode)
	{
		aimFresh = isDefined(self.ba.aim_pos_time) && (now - self.ba.aim_pos_time) < AIM_POS_STALE_MS;

		if (isDefined(self.actor[AIM_POS]) && aimFresh)
		{
			eye = self getEye();
			if (!isDefined(eye))
				eye = self.origin + (0, 0, 60);

			aim_dir = self.actor[AIM_POS] - eye;
			if (lengthsquared(aim_dir) > 1)
			{
				res.angles = vectortoangles(aim_dir);
				res.turn = TURN_AIM;
				if (self playerAds() > 0.5)
					res.turn = int(TURN_AIM * TURN_ADS_SCALE);
				return res;
			}
		}

		dirFresh = isDefined(self.ba.look_dir_time) && (now - self.ba.look_dir_time) < AIM_POS_STALE_MS;

		if (isDefined(self.actor[MOVE_LOOK_DIR]) && dirFresh && lengthsquared(self.actor[MOVE_LOOK_DIR]) > 1)
		{
			res.angles = vectortoangles(self.actor[MOVE_LOOK_DIR]);
			return res;
		}

		chaseTarget = self.actor[CHASE_TARGET];
		if (isDefined(chaseTarget) && isPlayer(chaseTarget) && isAlive(chaseTarget))
		{
			if (lengthsquared(world_dir) <= 1 || distanceSquared(self.origin, chaseTarget.origin) <= 450 * 450)
			{
				tEye = chaseTarget getEye();
				if (!isDefined(tEye))
					tEye = chaseTarget.origin + (0, 0, 50);
				myEye = self getEye();
				if (!isDefined(myEye))
					myEye = self.origin + (0, 0, 60);
				tDir = tEye - myEye;
				if (lengthsquared(tDir) > 1)
				{
					res.angles = vectortoangles(tDir);
					res.turn = TURN_AIM;
					return res;
				}
			}
		}
	}

	// Explicit angles request (only when not actively aiming at an enemy)
	if (isDefined(self.ba.look_angles) && now < self.ba.look_angles_until)
	{
		res.angles = self.ba.look_angles;
		res.turn = TURN_PATH;
		return res;
	}

	// Default: face travel direction
	if (lengthsquared(world_dir) > 1)
	{
		res.angles = vectortoangles(world_dir);
		res.forced = true;
	}

	return res;
}

_botApplyLook(look)
{
	if (!isDefined(look.angles))
		return undefined;

	want_pitch = angleClamp180(look.angles[0]);
	want_yaw = angleClamp180(look.angles[1]);

	curr = self getplayerangles();
	if (!isDefined(curr) || !isDefined(curr[0]) || !isDefined(curr[1]))
	{
		self botangles(want_pitch, want_yaw, 0);
		return (want_pitch, want_yaw, 0);
	}

	curr_pitch = angleClamp180(curr[0]);
	curr_yaw = angleClamp180(curr[1]);

	max_turn = look.turn;
	if (!isDefined(max_turn) || max_turn <= 0)
		max_turn = TURN_PATH;

	delta_pitch = angleClamp180(want_pitch - curr_pitch);
	delta_yaw = angleClamp180(want_yaw - curr_yaw);

	if (delta_pitch > max_turn) delta_pitch = max_turn;
	else if (delta_pitch < 0 - max_turn) delta_pitch = 0 - max_turn;

	if (delta_yaw > max_turn) delta_yaw = max_turn;
	else if (delta_yaw < 0 - max_turn) delta_yaw = 0 - max_turn;

	new_pitch = angleClamp180(curr_pitch + delta_pitch);
	new_yaw = angleClamp180(curr_yaw + delta_yaw);

	self botangles(new_pitch, new_yaw, 0);
	return (new_pitch, new_yaw, 0);
}

_botProbeObstacles(data, yaw)
{
	if (self ismantling())
	{
		data.wasmantling = true;
		self bot_set_stance("crouch");
		return;
	}
	else if (data.wasmantling)
	{
		data.wasmantling = false;
		self bot_set_stance("stand");
	}

	startPos = self.origin + (0, 0, 50);
	startPosForward = startPos + anglestoforward((0, yaw, 0)) * 25;
	bt = bullettrace(startPos, startPosForward, false, self);

	if (bt["fraction"] >= 1)
	{
		bt = bullettrace(startPosForward, startPosForward - (0, 0, 40), false, self);

		if (bt["fraction"] < 1 && isDefined(bt["normal"]) && bt["normal"][2] > 0.9 && data.probe_age > 1.5 && !self isonladder())
		{
			data.probe_age = 0;
			self bot_press_jump();
		}

		if (data.crouched_by_probe)
		{
			data.crouched_by_probe = false;
			self bot_set_stance("stand");
		}
		return;
	}

	if (isDefined(bt["surfacetype"]) && bt["surfacetype"] == "glass")
	{
		if (data.probe_age > 1.5)
		{
			data.probe_age = 0;
			self bot_press_melee();
		}
		return;
	}

	if (bullettracepassed(startPos - (0, 0, 25), startPosForward - (0, 0, 25), false, self))
	{
		data.crouched_by_probe = true;
		self bot_set_stance("crouch");
	}
	else if (data.crouched_by_probe)
	{
		data.crouched_by_probe = false;
		self bot_set_stance("stand");
	}
}

_botDriveQuadruped(world_dir)
{
	target_yaw = vectorToYaw(world_dir);
	curr_angles = self getPlayerAngles();
	curr_yaw = 0;
	if (isDefined(curr_angles) && isDefined(curr_angles[1]))
		curr_yaw = angleClamp180(curr_angles[1]);

	yaw_delta = angleClamp180(target_yaw - curr_yaw);
	abs_yaw_delta = abs(yaw_delta);

	if (abs_yaw_delta > 45)
	{
		quad_turn_speed = 15;
		if (yaw_delta > quad_turn_speed) yaw_delta = quad_turn_speed;
		else if (yaw_delta < (0 - quad_turn_speed)) yaw_delta = 0 - quad_turn_speed;

		self botangles(0, angleClamp180(curr_yaw + yaw_delta), 0);
		self botmovement(0, 0);
		return;
	}

	quad_turn_speed = 8;
	if (yaw_delta > quad_turn_speed) yaw_delta = quad_turn_speed;
	else if (yaw_delta < (0 - quad_turn_speed)) yaw_delta = 0 - quad_turn_speed;

	self botangles(0, angleClamp180(curr_yaw + yaw_delta), 0);
	self botmovement(127, 0);
}

_botMovementLoop()
{
	self notify("_botMovementLoop");
	self endon("_botMovementLoop");
	self endon("disconnect");
	self endon("death");

	if (!isDefined(self.bot))
		self.bot = spawnstruct();

	if (!isDefined(self.ba))
		self bot_drive_init();

	self.bot.moveorigin = self.origin;
	self.bot.stop_move = false;
	self.bot.moveto = undefined;

	data = spawnstruct();
	data.wasmantling = false;
	data.crouched_by_probe = false;
	data.probe_age = 0;

	lastOri = self.origin;
	stuckTime = 0;
	stucks = 0;

	unstuck_goal = undefined;
	unstuck_end = 0;
	unstuck_backstep_end = 0;
	unstuck_need_backstep = true;
	preempt_next_time = 0;

	blocked_cache_time = 0;
	blocked_cache_point = undefined;

	for (;;)
	{
		if (!isDefined(self))
			return;
		if (!isPlayer(self))
			return;
		alive = isAlive(self);
		if (!isDefined(alive) || !alive)
			return;
		if (!isDefined(self.actor) || !isDefined(self.bot) || !isDefined(self.ba))
			return;

		loopMs = 50;
		if (self _botMovementIsLiteGoap())
			loopMs = _botMovementOpt("lite_move_ms");
		loopWait = float(loopMs) * 0.001;

		now = gettime();
		self.actor[HEARTBEAT_MOVE] = now;
		self.bot.moveorigin = self.origin;

		if (isDefined(self.bot.anim_lock) && self.bot.anim_lock)
		{
			self botmovement(0, 0);
			wait loopWait;
			continue;
		}

		self _botApplyStance();

		if (self.bot.stop_move)
		{
			self botmovement(0, 0);
			self.ba.arrived = true;
			lastOri = self.origin;
			stuckTime = 0;
			wait loopWait;
			continue;
		}

		if (!isDefined(self.bot.moveto))
		{
			look = self _botResolveLook((0, 0, 0), false, now);
			self _botApplyLook(look);
			self botmovement(0, 0);
			self.ba.arrived = true;
			self.ba.blocked = false;
			unstuck_goal = undefined;
			stucks = 0;
			self.ba.stuck_count = 0;
			lastOri = self.origin;
			stuckTime = 0;
			wait loopWait;
			continue;
		}

		active_point = self.bot.moveto;
		unstuck_active = false;
		if (isDefined(unstuck_goal))
		{
			if (now < unstuck_end)
			{
				active_point = unstuck_goal;
				unstuck_active = true;
			}
			else
				unstuck_goal = undefined;
		}

		if (!isDefined(active_point))
			active_point = self.origin;

		if (now < unstuck_backstep_end)
		{
			self bot_release_sprint();
			self botmovement(-127, 0);
			wait loopWait;
			stuckTime += loopMs;
			continue;
		}

		world_dir = (active_point[0] - self.origin[0], active_point[1] - self.origin[1], 0);
		goal_dist_sq = distancesquared(self.origin, self.bot.moveto);
		goal_dist_2d = distance2d(self.origin, self.bot.moveto);
		z_delta = abs(self.origin[2] - self.bot.moveto[2]);

		stop_dist = self.ba.move_stop_dist;
		if (!isDefined(stop_dist) || stop_dist < 0)
			stop_dist = 16;
		self.ba.arrived = (goal_dist_2d <= stop_dist && z_delta <= 48);

		if (now >= blocked_cache_time || !isDefined(blocked_cache_point) || distanceSquared(blocked_cache_point, active_point) > 64 * 64)
		{
			if (abs(active_point[2] - self.origin[2]) > 24)
				self.ba.blocked = false;
			else
				self.ba.blocked = !bullettracepassed(self.origin + (0, 0, 45), active_point + (0, 0, 45), false, self);

			blocked_cache_point = active_point;
			blocked_cache_time = now + _botMovementOpt("move_block_trace_ms");
		}

		if (self.ba.blocked && !unstuck_active && now >= preempt_next_time && !self.ba.arrived && self.ba.speed_sq < 35 * 35 && abs(active_point[2] - self.origin[2]) <= 24)
		{
			preempt = self _botGetPreemptCornerBypass(active_point, 1 + stucks);
			if (isDefined(preempt))
			{
				unstuck_goal = preempt;
				unstuck_end = now + 600;
				preempt_next_time = now + 500;
				active_point = preempt;
				unstuck_active = true;
				world_dir = (active_point[0] - self.origin[0], active_point[1] - self.origin[1], 0);
			}
			else
				preempt_next_time = now + 250;
		}

		if (self.ba.arrived && !unstuck_active)
		{
			look = self _botResolveLook(world_dir, false, now);
			self _botApplyLook(look);
			self botmovement(0, 0);
			wait loopWait;
			data.probe_age += loopWait;
			continue;
		}

		if (isDefined(self.actor[QUADRUPED_MODE]) && self.actor[QUADRUPED_MODE])
		{
			self _botDriveQuadruped(world_dir);
			wait loopWait;
			data.probe_age += loopWait;
			continue;
		}

		look = self _botResolveLook(world_dir, unstuck_active, now);
		self _botApplyLook(look);

		angles = self getplayerangles();
		yaw = 0;
		if (isDefined(angles) && isDefined(angles[1]))
			yaw = angles[1];

		self _botProbeObstacles(data, yaw);

		dir = (0, 0, 0);
		if (lengthsquared(world_dir) >= 49)
		{
			cosa = cos(0 - yaw);
			sina = sin(0 - yaw);

			dir = (world_dir[0] * cosa - world_dir[1] * sina,
			       world_dir[0] * sina + world_dir[1] * cosa,
			       0);

			dir = vectornormalize(dir) * 127;
			dir = (dir[0], 0 - dir[1], 0);
		}

		if (isDefined(self.ba.strafe) && self.ba.strafe != 0 && now < self.ba.strafe_until)
		{
			side = 127 * self.ba.strafe;
			if (lengthsquared(world_dir) < 49)
				dir = (0, side, 0);
			else
				dir = (dir[0] * 0.4, side, 0);
		}

		wantSprint = isDefined(self.actor[HOLD_SPRINT]) && self.actor[HOLD_SPRINT];
		if (wantSprint)
		{
			if (dir[0] >= 60)
				dir = (127, dir[1], 0);
			else
				self bot_release_sprint();
		}

		if (isDefined(self.actor[PATROL_ACTIVE]) && self.actor[PATROL_ACTIVE] && goal_dist_sq <= 45 * 45)
			dir = (dir[0] * 0.82, dir[1] * 0.82, 0);

		self botmovement(int(dir[0]), int(dir[1]));

		wait loopWait;
		data.probe_age += loopWait;

		vel = self getvelocity();
		self.ba.speed_sq = lengthsquared(vel);
		stuckTime += loopMs;

		if (stuckTime >= 3000)
		{
			movedSq = distancesquared(self.origin, lastOri);
			if (movedSq < 32 * 32)
			{
				stucks++;
				self.ba.stuck_count = stucks;
				self notify("bot_actor_stuck");

				failWp = _botgetNearestWaypoint(active_point, true);
				if (isDefined(failWp))
					self _botWPMemoryMarkFail(failWp, 6500);

				planned = false;

				if (unstuck_need_backstep)
				{
					backstep = self _botGetBackstepGoal(active_point, stucks);
					if (isDefined(backstep))
					{
						extra = stucks * 220;
						if (extra > 750) extra = 750;
						unstuck_goal = undefined;
						unstuck_backstep_end = gettime() + 280 + extra;
						unstuck_need_backstep = false;
						planned = true;
					}
				}

				if (!planned)
				{
					bypass = self _botGetWaypointBypass(active_point, stucks);
					if (!isDefined(bypass))
						bypass = self _botGetAxisCornerBypass(active_point, stucks);
					if (!isDefined(bypass))
						bypass = self _botGetRandomLargetsStrage(stucks);

					if (isDefined(bypass))
					{
						extra = stucks * 350;
						if (extra > 1200) extra = 1200;
						unstuck_goal = bypass;
						unstuck_end = gettime() + 450 + extra;
						planned = true;
					}

					unstuck_need_backstep = true;
				}

				if (stucks >= 2)
					self bot_press_jump();
			}
			else
			{
				stucks = 0;
				self.ba.stuck_count = 0;
				unstuck_need_backstep = true;
			}

			lastOri = self.origin;
			stuckTime = 0;
		}
	}
}
