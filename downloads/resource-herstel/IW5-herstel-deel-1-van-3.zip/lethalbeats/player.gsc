/*
============================
|   Lethal Beats Team	   |
============================
|Game : IW5                |
|Script : player           |
|Creator : LastDemon99	   |
|Type : Utility            |
============================
*/

#include lethalbeats\string;
#include lethalbeats\array;
#include lethalbeats\weapon;

#define PLAYERS_FILTER_ALL 0
#define PLAYERS_FILTER_REAL 1
#define PLAYERS_FILTER_BOTS 2

/*
///DocStringBegin
detail: player_suicide(): <Void>
summary: Engine functions cannot be sent as a pointer so this wrapper is used to ::suicide
///DocStringEnd
*/
player_suicide()
{
	self suicide();
}

player_count(team, alives)
{
	count = 0;
	foreach (player in level.players)
	{
		if (isDefined(alives) && isAlive(player) != alives) continue;
		if (isDefined(team) && player.team != team) continue;
		count++;
	}
	return count;
}

player_give_weapon(weapon, switchInmmediate, maxAmmo, spawnWeapon)
{
	if (!isDefined(switchInmmediate)) switchInmmediate = 0;
	if (!isDefined(maxAmmo)) maxAmmo = 0;
	if (!isDefined(spawnWeapon)) spawnWeapon = 0;

	if (!string_contains(weapon, "_mp_") && !string_ends_with(weapon, "_mp"))
		weapon = weapon + "_mp";
	
	self giveWeapon(weapon);

	if (self player_is_weapon_primary(weapon)) 
	{
		self.pers["primaryWeapon"] = weapon;
		self.primaryweapon = weapon;
	}
    else self.secondaryweapon = weapon;

	if (switchInmmediate) self switchToWeaponImmediate(weapon);	
	if (maxAmmo) self giveMaxAmmo(weapon);
	if (spawnWeapon) self setSpawnWeapon(weapon);
}

_switchToWeapon(weapon)
{
	waittillframeend;
	self switchToWeaponImmediate(weapon);
}

player_give_spawn_weapon(weapon, switch_to_weapon)
{
	self takeAllWeapons();
	self player_give_weapon(weapon);
	self.primaryWeapon = weapon;
	self.pers["primaryWeapon"] = weapon;
	
	if (isDefined(switch_to_weapon) && switch_to_weapon)
		self switchToWeaponImmediate(weapon);
	else
		self setSpawnWeapon(weapon);
}

player_give_start_ammo(perkName)
{
	self giveStartAmmo(perkName);
}

player_give_max_ammo(weapon)
{
	if (!isDefined(weapon)) weapon = self getCurrentWeapon();
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);
	self giveMaxAmmo(weapon);
	self setWeaponAmmoClip(weapon, weaponClipSize(weapon));
	if (weapon_has_attach_akimbo(weapon)) self setWeaponAmmoClip(weapon, weaponClipSize(weapon), "left");
	if (weapon_has_attach_alt(weapon))
	{
		altWeapon = "alt_" + weapon;
		self giveMaxAmmo(altWeapon);
		self setWeaponAmmoClip(altWeapon, weaponClipSize(altWeapon));
	}
}

player_give_random_ammo(weapon, minPercent, maxPercent)
{
	if (!isDefined(weapon)) weapon = self getCurrentWeapon();
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);
	if (!isDefined(minPercent)) minPercent = 15;
	if (!isDefined(maxPercent)) maxPercent = 35;

	minPercent = int(max(0, min(100, minPercent)));
	maxPercent = int(max(0, min(100, maxPercent)));
	if (minPercent > maxPercent) minPercent = maxPercent;

	maxStock = weaponMaxAmmo(weapon);
	clipSize = weaponClipSize(weapon);

	if (maxStock <= 0 || clipSize <= 0)
	{
		self player_give_max_ammo(weapon);
		return;
	}

	currentStock = self getWeaponAmmoStock(weapon);
	percent = randomIntRange(minPercent, maxPercent + 1);
	ammoToGive = int((maxStock * percent) / 100);
	newStock = currentStock + ammoToGive;
	if (newStock > maxStock) newStock = maxStock;

	self setWeaponAmmoStock(weapon, int(newStock));
	self setWeaponAmmoClip(weapon, clipSize);

	if (weapon_has_attach_akimbo(weapon))
		self setWeaponAmmoClip(weapon, clipSize, "left");

	if (weapon_has_attach_alt(weapon))
	{
		altWeapon = "alt_" + weapon;

		currentStock = self getWeaponAmmoStock(altWeapon);
		maxStock = weaponMaxAmmo(altWeapon);
		clipSize = weaponClipSize(altWeapon);

		ammoToGive = int((maxStock * percent) / 100);
		if (ammoToGive < 1) ammoToGive = 1;
		newStock = int(min(currentStock + ammoToGive, maxStock));

		self setWeaponAmmoStock(altWeapon, newStock);
		self setWeaponAmmoClip(altWeapon, clipSize);
	}
}

player_set_offhand_primary_class(class)
{
	self setOffhandPrimaryClass(class);
}

player_set_offhand_secondary_class(class)
{
	self setOffhandPrimaryClass(class);
}

player_give_perk(perkName, useSlot, pro)
{
	if (!isDefined(useSlot)) useSlot = false;
	if (!isDefined(pro)) pro = true;

	if (string_contains(perkName, "_mp"))
	{
		switch(perkName)
		{
			case "frag_grenade_mp":
				self setOffhandPrimaryClass("frag");
				break;
			case "throwingknife_mp":
				self setOffhandPrimaryClass("throwingknife");
				break;
			case "trophy_mp":
				self setOffhandSecondaryClass("flash");
				break;
		}

		self player_give_weapon(perkName, 0);
		self giveStartAmmo(perkName);
		self player_set_perk(perkName, useSlot);
		return;
	}

	if(string_contains(perkName, "specialty_weapon_"))
	{
		self player_set_perk(perkName, useSlot);
		return;
	}

	self player_set_perk(perkName, useSlot);
	self player_set_extra_perk(perkName);

	if (pro)
	{
		perkUpgrade = maps\mp\gametypes\_class::getPerkUpgrade(perkName);
		if (perkUpgrade != "specialty_null") player_give_perk(perkUpgrade, false);
	}
}

player_give_all_perks()
{
	foreach(perk in lethalbeats\perk::perk_get_list())
	{
		if (perk == "specialty_overkill" || perk == "specialty_assassin")
			continue;
		
		if (isDefined(level.infiniteStock) && level.infiniteStock && perk == "specialty_scavenger")
			continue;

		self player_give_perk(perk);
	}
}

player_set_extra_perk(perkName)
{
	if(perkName == "specialty_coldblooded")
		self player_give_perk("specialty_heartbreaker", false);
	if(perkName == "specialty_fasterlockon")
		self player_give_perk("specialty_armorpiercing", false);
	if(perkName == "specialty_spygame")
		self player_give_perk("specialty_empimmune", false);
	if(perkName == "specialty_rollover")
		self player_give_perk("specialty_assists", false);
}

player_set_perk(perkName, useSlot)
{
	self.perks[perkName] = true;

	if (isDefined(level.perkSetFuncs[perkName]))
		self thread [[level.perkSetFuncs[perkName]]]();
	
	self setPerk(perkName, !isDefined(level.scriptPerks[perkName]), useSlot);
}

player_unset_extra_perk(perkName)
{
	if(perkName == "specialty_coldblooded")
		self player_unset_Perk("specialty_heartbreaker");
	if(perkName == "specialty_fasterlockon")
		self player_unset_Perk("specialty_armorpiercing");
	if(perkName == "specialty_spygame")
		self player_unset_Perk("specialty_empimmune");
	if(perkName == "specialty_rollover")
		self player_unset_Perk("specialty_assists");
}

player_unset_Perk(perkName)
{
	self.perks[perkName] = undefined;
	if (isDefined(level.perkUnsetFuncs[perkName]))
		self thread [[level.perkUnsetFuncs[perkName]]]();
	self unsetPerk(perkName, !isDefined(level.scriptPerks[perkName]));
}

player_has_perk(perkName)
{
	if (isDefined(self.perks[perkName]))
		return true;	
	return false;
}

player_refill_ammo(endonOnDeath)
{
    level endon("game_ended");
    self endon("disconnect");
	if (isDefined(endonOnDeath) && endonOnDeath) self endon("death");

    for (;;)
    {
        self waittill("reload");
		if(self player_is_infect()) break;
		weapon = self getCurrentWeapon();
		if(!isDefined(weapon) || weapon_get_class(weapon) == "riot") continue;
		self player_give_max_ammo(weapon);
    }
}

player_refill_single_count_ammo(endonOnDeath)
{
    level endon("game_ended");
    self endon("disconnect");
	if (isDefined(endonOnDeath) && endonOnDeath) self endon("death");

    for (;;)
    {
		wait 0.5;
		if(self player_is_infect()) break;
		weapon = self getCurrentWeapon();
		if (!isDefined(weapon) || weapon_get_class(weapon) != "riot" && self getammocount(weapon) == 0)
        {
            wait 2;
            self notify("reload");
            wait 1;
            continue;
        }
        wait 0.05;
	}
}

player_nades_refill(endonOnDeath)
{
    level endon("game_ended");
    self endon("disconnect");
	if (isDefined(endonOnDeath) && endonOnDeath) self endon("death");
	
	for (;;)
    {
		self waittill("grenade_fire", grenade, weaponName);
		
		if(self player_is_infect()) break;
		
		if(array_contains(level.weapons["lethal"], weaponName))
		{
			if(weaponName != "c4_mp") wait(1);
			else wait(3);
		}
		else if(array_contains(level.weapons["tactical"], weaponName)) wait(4);
		
		if(weaponName == "scrambler_mp") self thread maps\mp\gametypes\_scrambler::setScrambler();
		else if (weaponName == "portable_radar_mp") self thread maps\mp\gametypes\_portable_radar::setPortableRadar();
		else if (weaponName == "flare_mp") self maps\mp\perks\_perkfunctions::setTacticalInsertion();
		else self giveStartAmmo(weaponName);
		
		self playLocalSound("scavenger_pack_pickup");
	}
}

/*
///DocStringBegin
detail: player_stinger_fire(endonOnDeath: <Bool>): <Void>
summary: Allows aiming and firing with the stinger. Requires a thread to avoid interrupting the code.
///DocStringEnd
*/
player_stinger_fire(endonOnDeath)
{
	level endon("game_ended");
	self endon("disconnect");
	if (isDefined(endonOnDeath) && endonOnDeath) self endon("death");

	self notifyOnPlayerCommand("attack", "+attack");
	
	for(;;)
	{
		self waittill("attack");
		
		if (self getCurrentWeapon() == "stinger_mp" && self playerAds() >= 1)
			if (self getWeaponAmmoClip(self getCurrentWeapon()) != 0)
			{
				vector = anglesToForward(self getPlayerAngles());
				dsa = (vector[0] * 1000000, vector[1] * 1000000, vector[2] * 1000000);
				magicBullet("stinger_mp", self getTagOrigin("tag_weapon_left"), dsa, self);
				self setWeaponAmmoClip("stinger_mp", 0);
			}	
		wait 0.3;
	}
}

player_give_nade(grenade, slot)
{
	if (!isDefined(slot)) slot = 0;
	else if (isString(slot)) slot = slot == "lethal" ? 0 : 1;

	if (slot) self setOffhandSecondaryClass(weapon_get_equipment_class(grenade));
	else self setOffhandPrimaryClass(weapon_get_equipment_class(grenade));
	
	self player_give_weapon(grenade);
	if (grenade != "emp_grenade_mp") self player_set_perk(grenade, false);
}

player_is_infect()
{
	return getDvar("g_gametype") == "infect" && self.sessionTeam == "axis";
}

player_is_flashed()
{
	if (!isdefined(self.flashEndTime))
		return false;

	return gettime() < self.flashEndTime;
}

player_is_really_alive()
{
	return isAlive(self) && !isDefined(self.fauxdead);
}

/*
///DocStringBegin
detail: players_get_list(team?: <String | Undefined>, alives?: <Boolean | Undefined>, bot_filter?: <Int | Undefined>): <Entity[]>
summary: Returns an array of players optionally filtered by team, alive and bot (0 = all, 1 = real players, 2 = bots).
///DocStringEnd
*/
players_get_list(team, alives, bot_filter)
{
	if (!isDefined(bot_filter)) bot_filter = PLAYERS_FILTER_ALL;

    players = [];
	foreach (player in level.players)
	{
		if (bot_filter)
		{
			if (player isTestClient())
				if (bot_filter == PLAYERS_FILTER_REAL) continue;
			else
				if (bot_filter == PLAYERS_FILTER_BOTS) continue;
		}

		if (bot_filter == PLAYERS_FILTER_REAL && player isTestClient()) continue;
		if (bot_filter == PLAYERS_FILTER_REAL && player isTestClient()) continue;

		if (isDefined(team) && player.team != team) continue;
		if (isDefined(alives) && (alives != player player_is_really_alive())) continue;
		players[players.size] = player;
	}
	return players;
}

players_by_string(target)
{
    switch(target)
    {
        case "allies":
        case "axis":
        case "spectator":
            return players_get_list(target);
        case "alives":
            return players_get_list(undefined, true);
        case "allies_alive":
        case "axis_alive":
            return players_get_list(strTok(target, "_")[0], true);
        case "allies_death":
        case "axis_death":
            return players_get_list(strTok(target, "_")[0], false);
        default:
            if (target[0] == "@")
            {
                foreach(player in level.players)
                    if (lethalbeats\string::string_starts_with(player.name, "@" + target))
                        return player;
            }
			else return level.players;
            break;
    }
}

player_get_perks()
{
	if (!isDefined(self.perks)) return [];
	return array_get_keys(self.perks);
}

player_get_weapons_buffs()
{
	buffs = [];
	perks = self player_get_perks();
	for (i = 0; i < perks.size; i++)
		if (lethalbeats\perk::perk_is_weapon_buff(perks[i]))
			buffs[buffs.size] = perks[i];
	return buffs;
}

/*
///DocStringBegin
detail: <Player> player_get_weapons(returnsAltWeapon: <Bool | Undefined>): <Bool>
summary: Returns a player weapons list.
///DocStringEnd
*/
player_get_weapons(returnsAltWeapon)
{
	if (!isDefined(returnsAltWeapon)) returnsAltWeapon = false;
	weapons = array_remove_undefined(self getWeaponsList("primary"));
	return returnsAltWeapon ? weapons : array_filter(weapons, ::filter_not_starts_with, "alt_");
}

player_get_primary()
{
	primary = self getWeaponsListPrimaries()[0];
	if (!isDefined(primary) || primary == "none") return undefined;
	return primary;
}

player_get_secondary()
{
	secondary = self getWeaponsListPrimaries()[1];
	if (!isDefined(secondary) || secondary == "none") return undefined;
	return secondary;
}

player_get_weapon_index(weapon, baseNameFormat)
{
	if (!isDefined(weapon)) return undefined;
	if (!isDefined(baseNameFormat)) baseNameFormat = false;
	
	isPrimary = self player_is_weapon_primary(weapon, baseNameFormat);
	if (isPrimary) return 0;

	isSecondary = self player_is_weapon_secondary(weapon, baseNameFormat);
	if (isSecondary) return 1;

	return undefined;
}

player_is_weapon_primary(weapon, baseNameFormat)
{
	if (self getWeaponsListPrimaries().size < 1) return false;
	if (!isDefined(baseNameFormat)) baseNameFormat = false;
	weaponTarget = self getWeaponsListPrimaries()[0];
	if (!isDefined(weaponTarget)) return false;
	if (!baseNameFormat) return weapon == weaponTarget;
	return weapon_get_baseName(weapon) == weapon_get_baseName(weaponTarget);
}

player_is_weapon_secondary(weapon, baseNameFormat)
{
	if (self getWeaponsListPrimaries().size < 2) return false;
	if (!isDefined(baseNameFormat)) baseNameFormat = false;
	weaponTarget = self getWeaponsListPrimaries()[1];
	if (!isDefined(weaponTarget)) return false;
	if (!baseNameFormat) return weapon == weaponTarget;
	return weapon_get_baseName(weapon) == weapon_get_baseName(weaponTarget);
}

/*
///DocStringBegin
detail: <Player> player_get_build_weapon(baseName: <String>): <String | Undefined>
summary: Returns a weapon owned by the player if it matches the given base name, ignoring attachments, or returns undefined if the weapon is not found.
///DocStringEnd
*/
player_get_build_weapon(baseName)
{
	weapons = self player_get_weapons();
	baseName = weapon_get_baseName(baseName);
	for (i = 0; i < weapons.size; i++)
	{
		if (weapon_get_baseName(weapons[i]) == baseName)
			return weapons[i];
	}
	return undefined;
}

player_get_fraction_ammo(weapon, ignoreClip)
{
	if (!isDefined(ignoreClip)) ignoreClip = false;
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);
	if (weapon_has_attach_akimbo(weapon))
	{
		weaponLeftFraction = (self getFractionMaxAmmo(weapon) * 0.475);
		weaponRightFraction = (self getFractionMaxAmmo(weapon) * 0.475);
		if (!ignoreClip)
		{
			weaponLeftFraction += ((self getWeaponAmmoClip(weapon) / weaponClipSize(weapon)) * 0.025);
			weaponRightFraction += ((self getWeaponAmmoClip(weapon, "left") / weaponClipSize(weapon)) * 0.025);
		}
		return weaponLeftFraction + weaponRightFraction;
	}
	else if (weapon_has_attach_alt(weapon))
	{
		weaponFraction = (self getFractionMaxAmmo(weapon) * 0.75);
		if (!ignoreClip) weaponFraction += ((self getWeaponAmmoClip(weapon) / weaponClipSize(weapon)) * 0.05);
		altWeapon = "alt_" + weapon;
		if (weapon_has_attach_gl(weapon))
		{
			weaponAltFraction = (self getFractionMaxAmmo(altWeapon) * 0.1);
			if (!ignoreClip) weaponAltFraction += ((self getWeaponAmmoClip(altWeapon) / weaponClipSize(altWeapon)) * 0.1);
		}
		else
		{
			weaponAltFraction = (self getFractionMaxAmmo(altWeapon) * 0.15);
			if (!ignoreClip) weaponAltFraction += ((self getWeaponAmmoClip(altWeapon) / weaponClipSize(altWeapon)) * 0.05);
		}
		return weaponFraction + weaponAltFraction;
	}

	fraction = (self getFractionMaxAmmo(weapon) * 0.95);
	if (!ignoreClip) fraction += ((self getWeaponAmmoClip(weapon) / weaponClipSize(weapon)) * 0.05);
	else if (self getWeaponAmmoStock(weapon) == weaponMaxAmmo(weapon)) fraction = 1;
	return fraction;
}

/*
///DocStringBegin
detail: <Player> player_has_weapon(weapon: <String>, relative: <Boolean | Undefined>): <Boolean>
summary: Checks if the player possesses a specific weapon. If `relative` is true, it determines possession based on the base name of the weapon, ignoring attachments.
///DocStringEnd
*/
player_has_weapon(weapon, relative)
{
	if (isDefined(relative) && relative)
	{
		weapon = weapon_get_baseName(weapon);
		return isDefined(self player_get_build_weapon(weapon));
	}
	return self hasWeapon(weapon);
}

player_has_max_ammo(weapon, ignoreClip)
{
	if (!isDefined(ignoreClip)) ignoreClip = false;
	return self player_get_fraction_ammo(weapon, ignoreClip) == 1;
}

player_has_killstreak()
{
	return self.pers["killstreaks"].size >= 6;
}

player_save_ammo(weapon, key)
{
	if (!isDefined(key)) key = weapon;
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);
	if (!isDefined(self.restoreAmmo)) self.restoreAmmo = [];
	self.restoreAmmo[key] = self player_get_ammo_data(weapon);
}

player_restore_ammo(weapon, key, clear)
{
	if (!isDefined(clear)) clear = false;
	if (!isDefined(key)) key = weapon;
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);
	if (!isDefined(self.restoreAmmo) || !isDefined(self.restoreAmmo[key])) return;	
	ammoDataToRestore = self.restoreAmmo[key];
	self player_set_ammo_data(weapon, ammoDataToRestore);
	if (clear) self.restoreAmmo = array_remove_key(self.restoreAmmo, key);
}

player_get_ammo_data(weapon)
{
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);
	ammoData = [];
	if (weapon_has_attach_alt(weapon))
	{
		ammoData["type"] = "alt";
		ammoData["clip"] = self getWeaponAmmoClip(weapon);
		ammoData["stock"] = self getWeaponAmmoStock(weapon);
		ammoData["alt_clip"] = self getWeaponAmmoClip("alt_" + weapon);
		ammoData["alt_stock"] = self getWeaponAmmoStock("alt_" + weapon);
	}
	else if (weapon_has_attach_akimbo(weapon))
	{
		ammoData["type"] = "akimbo";
		ammoData["left_clip"] = self getWeaponAmmoClip(weapon, "left");
		ammoData["right_clip"] = self getWeaponAmmoClip(weapon, "right");
		ammoData["stock"] = self getWeaponAmmoStock(weapon);
	}
	else
	{
		ammoData["type"] = "standard";
		ammoData["clip"] = self getWeaponAmmoClip(weapon);
		ammoData["stock"] = self getWeaponAmmoStock(weapon);
	}
	return ammoData;
}

player_set_ammo_data(weapon, ammoData)
{
	if (!isDefined(ammoData) || !isDefined(ammoData["type"])) return;
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);
	switch(ammoData["type"])
	{
		case "alt":
			self setWeaponAmmoClip(weapon, ammoData["clip"]);
			self setWeaponAmmoStock(weapon, ammoData["stock"]);
			self setWeaponAmmoClip("alt_" + weapon, ammoData["alt_clip"]);
			self setWeaponAmmoStock("alt_" + weapon, ammoData["alt_stock"]);
			break;

		case "akimbo":
			self setWeaponAmmoClip(weapon, ammoData["left_clip"], "left");
			self setWeaponAmmoClip(weapon, ammoData["right_clip"], "right");
			self setWeaponAmmoStock(weapon, ammoData["stock"]);
			break;

		case "standard":
		default:
			self setWeaponAmmoClip(weapon, ammoData["clip"]);
			self setWeaponAmmoStock(weapon, ammoData["stock"]);
			break;
	}
}

player_add_ammo_from_data(weapon, ammoData)
{
	if (!isDefined(ammoData) || !isDefined(ammoData["type"])) return;
	if (string_starts_with(weapon, "alt_")) weapon = getSubStr(weapon, 4);

	switch(ammoData["type"])
	{
		case "alt":
			currentStock = self getWeaponAmmoStock(weapon);
			ammoToAdd = ammoData["clip"] + ammoData["stock"];
			maxStock = weaponMaxAmmo(weapon);
			newStock = int(min(currentStock + ammoToAdd, maxStock));
			self setWeaponAmmoStock(weapon, newStock);
			
			altWeapon = "alt_" + weapon;
			currentAltStock = self getWeaponAmmoStock(altWeapon);
			altAmmoToAdd = ammoData["alt_clip"] + ammoData["alt_stock"];
			maxAltStock = weaponMaxAmmo(altWeapon);
			newAltStock = int(min(currentAltStock + altAmmoToAdd, maxAltStock));
			self setWeaponAmmoStock(altWeapon, newAltStock);
			break;

		case "akimbo":
			currentStock = self getWeaponAmmoStock(weapon);
			ammoToAdd = ammoData["left_clip"] + ammoData["right_clip"] + ammoData["stock"];
			maxStock = weaponMaxAmmo(weapon);
			newStock = int(min(currentStock + ammoToAdd, maxStock));
			self setWeaponAmmoStock(weapon, newStock);
			break;

		case "standard":
		default:
			currentStock = self getWeaponAmmoStock(weapon);
			ammoToAdd = ammoData["clip"] + ammoData["stock"];
			maxStock = weaponMaxAmmo(weapon);
			newStock = int(min(currentStock + ammoToAdd, maxStock));
			self setWeaponAmmoStock(weapon, newStock);
			break;
	}
}

/*
///DocStringBegin
detail: Player player_get_current_weapon_class(): <String>
summary: Get player current weapon class name.
///DocStringEnd
*/
player_get_current_weapon_class()
{
	currentWeapon = self getCurrentWeapon();
	if (!isDefined(currentWeapon) || currentWeapon == "none")
		return "";

	baseName = lethalbeats\weapon::weapon_get_baseName(currentWeapon);
	return lethalbeats\weapon::weapon_get_class(baseName);
}

/*
///DocStringBegin
detail: Player player_get_primary_weapon_class(): <String>
summary: Get player primary weapon class name.
///DocStringEnd
*/
player_get_primary_weapon_class()
{
	primary = self player_get_primary();
	if (!isDefined(primary) || primary == "none")
		return "";

	baseName = lethalbeats\weapon::weapon_get_baseName(primary);
	return lethalbeats\weapon::weapon_get_class(baseName);
}

/*
///DocStringBegin
detail: Player player_get_secondary_weapon_class(): <String>
summary: Get player secondary weapon class name.
///DocStringEnd
*/
player_get_secondary_weapon_class()
{
	secondary = self player_get_secondary();
	if (!isDefined(secondary) || secondary == "none")
		return "";

	baseName = lethalbeats\weapon::weapon_get_baseName(secondary);
	return lethalbeats\weapon::weapon_get_class(baseName);
}

/*
///DocStringBegin
detail: players_play_sound(sound: <String>, team?: <String>, excludeTargets?: <Player[]>): <Void>
summary: Play local sounds on players. You can optionally specify the equipment or exclude players based on array.
///DocStringEnd
*/
players_play_sound(sound, team, excludeTargets)
{	
	if (isDefined(team)) targets = players_get_list(team);
	else targets = level.players;
	if (isDefined(excludeTargets)) targets = array_difference(targets, excludeTargets);
	foreach(player in targets)
		player playLocalSound(sound);
}

player_take_weapon(weapon)
{
	if (!isDefined(weapon)) weapon = self getCurrentWeapon();
	self takeWeapon(weapon);
}

player_take_all_weapons(onlyPrimaries)
{
	if (!isDefined(onlyPrimaries)) onlyPrimaries = false;
	if (onlyPrimaries)
	{
		foreach(weapon in self getWeaponsListPrimaries())
			self takeWeapon(weapon);
	}
	else self takeAllWeapons();
}

player_take_all_weapon_buffs()
{
	foreach(buff in self player_get_weapons_buffs())
		self player_unset_Perk(buff);
}

player_is_usability_enabled()
{
    return !self.disabledusability;
}

player_disable_usability()
{
    self.disabledusability = true;
    self disableusability();
}

player_enable_usability()
{
    self.disabledusability = false;
	self enableusability();
}

player_is_weapon_enabled()
{
    return !self.disabledweapon;
}

player_disable_weapons()
{
    self.disabledweapon = true;
    self disableweapons();
}

player_enable_weapons()
{
    self.disabledweapon = false;
	self enableweapons();
}

player_is_weapon_switch_enabled()
{
    return !self.disabledweaponswitch;
}

player_disable_weapon_switch()
{
    self.disabledweaponswitch = true;
    self disableweaponswitch();
}

player_enable_weapon_switch()
{
    self.disabledweaponswitch = false;
	self enableweaponswitch();
}

player_is_offhand_weapon_enabled()
{
    return !self.disabledoffhandweapons;
}

player_disable_offhand_weapons()
{
    self.disabledoffhandweapons = true;
    self disableoffhandweapons();
}

player_enable_offhand_weapons()
{
    self.disabledoffhandweapons = false;
	self enableoffhandweapons();
}

player_is_weapon_pickup_enabled()
{
    return !self.disabledWeaponPickup;
}

player_disable_weapon_pickup()
{
    self.disabledWeaponPickup = true;
    self disableWeaponPickup();
}

player_enable_weapon_pickup()
{
    self.disabledWeaponPickup = false;
	self enableWeaponPickup();
}

player_give_laststand_weapon(weapon)
{
	self thread _player_enable_laststand_weapon();

	self.lastStandWeapon = weapon;
	self.removeLastStandWeapon = !self hasWeapon(weapon);
	if (self.removeLastStandWeapon) self player_give_weapon(weapon);
	else self player_save_ammo(weapon, "onlaststand");

	self player_give_max_ammo(weapon);
	self switchtoweapon(weapon);

	self player_disable_usability();
	self player_disable_weapon_switch();
	self player_disable_offhand_weapons();
	self player_disable_weapon_pickup();
}

_player_enable_laststand_weapon()
{
	self endon("death");
    self endon("disconnect");
	self endon("revive");
    level endon("game_ended");

	self maps\mp\_utility::freezeControlsWrapper(true);
    wait 0.3;
    self maps\mp\_utility::freezeControlsWrapper(false);
}

player_set_action_slot(slotID, type, item)
{
	self.saved_actionslotdata[slotID].type = type;
    self.saved_actionslotdata[slotID].item = item;
    self setActionSlot(slotID, type, item);
}

player_black_screen(time)
{
	if (!isDefined(time)) time = 0.5;
	self visionSetNakedForPlayer("blacktest", 0);
	wait time;
	self visionSetNakedForPlayer("", 2);
}

player_can_see(targetOrigin, cos)
{
	if (!isDefined(cos)) cos = 0.7;
	eyePos = self getEye();
	toTargetDir = vectorNormalize(targetOrigin - eyePos);
	forward = anglesToForward(self.angles);
	return vectorDot(toTargetDir, forward) > cos;
}

/*
///DocStringBegin
detail: player_custom_specialist_KillStreak(): <Void>
summary: Requiere definir los array `level.gametypeKillStreak` y `level.gametypeKillStreakSplash`
///DocStringEnd
*/
player_give_gametype_KillStreak()
{
	if(!getDvarInt("scr_" + level.gameType +"_killstreak") || self isTestClient()) return;
	if (!isDefined(self.killstreak)) self.killstreak = 0;
	if(self.killstreak >= level.gametypeKillStreak.size) return;
	
	perk = level.gametypeKillStreak[self.killstreak];
	if(perk == "all_perks")
	{
		self player_give_all_perks();
		self lethalbeats\hud::hud_splash_killstreak("all_perks_bonus", self.killstreak);
	}
	else
	{
		self player_give_perk(perk);
		self lethalbeats\hud::hud_splash_killstreak(level.gametypeKillStreakSplash[self.killstreak], self.killstreak, "pro");	
	}
}

player_give_loadout(team, class, allowCopycat, setPrimarySpawnWeapon) 
{
	self maps\mp\gametypes\_class::giveLoadout(team, class, allowCopycat, setPrimarySpawnWeapon);
}

player_clear_killstreak()
{
	self maps\mp\killstreaks\_killstreaks::clearKillstreaks();
}

player_clear_perks()
{
	self maps\mp\_utility::_clearperks();
}

player_get_enemy_team()
{
	return lethalbeats\utility::get_enemy_team(self.team);
}

player_hide() // `playerHide` func is only reversible after respawn... there is no playerShow func, what the hell? ⊂(´•﹏•`⊂)?
{
	hideData = [];
	hideData["head"] = self.headmodel;
	hideData["body"] = self.model;

	primary = self player_get_primary();
	if (isDefined(primary))
	{
		hideData["weapon"][0] = primary;
		hideData["ammo"][0] = self player_get_ammo_data(primary);
		self takeWeapon(primary);
	}

	secondary = self player_get_secondary();
	if (isDefined(secondary))
	{
		hideData["weapon"][1] = secondary;
		hideData["ammo"][1] = self player_get_ammo_data(secondary);
		self takeWeapon(secondary);
	}

	//hideData["nade"] = [];

	self.hideData = hideData;

	// require null model mod
	self detachall();
	self attach("null_head", "", true);
	self setmodel("null_body");
}

player_show()
{
	hideData = self.hideData;

	self attach(hideData["head"], "", true);
	self setmodel(hideData["body"]);

	for(i = 0; i < 2; i++)
	{
		if (!isDefined(hideData["weapon"][i])) continue;
		weapon = hideData["weapon"][i];
		self player_give_weapon(weapon, false, false, true);
		self player_set_ammo_data(weapon, hideData["ammo"][i]);
	}
}

player_is_entity_near(entity, min_distance)
{
    return lethalbeats\utility::is_entity_near(entity, self.origin, min_distance);
}

player_get_nearest_entity(entities)
{
	return lethalbeats\utility::get_nearest_entity(entities, self.origin);
}

player_is_bot()
{
	return isDefined(self) && self isTestClient();
}

player_is_not_bot()
{
	return isDefined(self) && !self isTestClient(); 
}
