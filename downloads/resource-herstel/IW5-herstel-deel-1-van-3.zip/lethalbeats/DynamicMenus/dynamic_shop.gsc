// OPTION TYPES
#define OPTION_BUY -5
#define OPTION_DISABLE -4
#define OPTION_OWNED -3
#define OPTION_UPGRADE -2
#define OPTION_SCRIPTRESPONSE -1
// OPTION >= 0 -> item_price

// MENU INDICES
#define MENU_ID 0
#define MENU_PAGES 1

// PAGE INDICES
#define PAGE_ID 0
#define PAGE_DISPLAY 1
#define PAGE_DISPLAY_NAME 1
#define PAGE_DESC 2
#define PAGE_ITEMS 3
#define PAGE_MENU 4

// ITEM INDICES
#define ITEM_VALUE 0
#define ITEM_PRICE 1
#define ITEM_LABEL 2
#define ITEM_DESC 3
#define ITEM_IMAGE_RECT 4
#define ITEM_IMAGE_SQUARE 5
#define ITEM_UNLOCK_LEVEL 6

//////////////////////////////////////////
//	            API METHODS             //
//////////////////////////////////////////

/*
///DocStringBegin
detail: shop_create_menu(menu_id: <String>): <Struct>
summary: Creates and registers a new shop menu in level.dynamicShop and returns its builder struct.
///DocStringEnd
*/
shop_create_menu(menu_id)
{
    menuData = [];
    menuData[MENU_ID] = menu_id;
    menuData[MENU_PAGES] = [];

    if (!isDefined(level.dynamicShop)) level.dynamicShop = [];
    level.dynamicShop[menu_id] = menuData;

    builder = spawnStruct();
    builder.id = menu_id;
    builder.menu_id = menu_id;

    return builder;
}

/*
///DocStringBegin
detail: <Struct> shop_create_page(page_id: <String>, display_name?: <String>, desc?: <String>): <Struct>
summary: Creates and registers a page associated with a menu, then returns its builder struct.
///DocStringEnd
*/
shop_create_page(page_id, display_name, desc)
{
    menu_id = self.id;

    if (!isDefined(display_name)) display_name = "";
    if (!isDefined(desc)) desc = "";

    pageData = [];
    pageData[PAGE_ID] = page_id;
    pageData[PAGE_DISPLAY] = display_name;
    pageData[PAGE_DESC] = desc;
    pageData[PAGE_ITEMS] = [];
    pageData[PAGE_MENU] = menu_id;

    if (isDefined(level.dynamicShop) && isDefined(level.dynamicShop[menu_id]))
        level.dynamicShop[menu_id][MENU_PAGES][page_id] = pageData;

    if (!isDefined(level.dynamicShopPages)) level.dynamicShopPages = [];
    level.dynamicShopPages[page_id] = pageData;

    builder = spawnStruct();
    builder.id = page_id;
    builder.page_id = page_id;
    builder.menu_id = menu_id;

    return builder;
}

/*
///DocStringBegin
detail: <Struct> shop_create_item(value: <String>, price?: <Int>, label?: <String>, desc?: <String>, image_rect?: <String>, image_square?: <String>, unlock_level?: <Int>): <Struct>
summary: Adds an item to the page in the global array using the builder struct.
///DocStringEnd
*/
shop_create_item(value, price, label, desc, image_rect, image_square, unlock_level)
{
    page_id = self.id;

    item = [];
    item[ITEM_VALUE] = value;
    item[ITEM_PRICE] = price;
    item[ITEM_LABEL] = label;
    item[ITEM_DESC] = desc;
    item[ITEM_IMAGE_RECT] = image_rect;
    item[ITEM_IMAGE_SQUARE] = image_square;
    item[ITEM_UNLOCK_LEVEL] = unlock_level;
    
    if (isDefined(level.dynamicShopPages) && isDefined(level.dynamicShopPages[page_id]))
    {
        pageData = level.dynamicShopPages[page_id];
        pageData[PAGE_ITEMS][pageData[PAGE_ITEMS].size] = item;
        level.dynamicShopPages[page_id] = pageData;

        menu_id = pageData[PAGE_MENU];
        if (isDefined(menu_id) && isDefined(level.dynamicShop) && isDefined(level.dynamicShop[menu_id]))
            level.dynamicShop[menu_id][MENU_PAGES][page_id] = pageData;
    }

    if (isDefined(label))
    {
        if (!isDefined(level.dynamicShopItemLabels)) level.dynamicShopItemLabels = [];
        level.dynamicShopItemLabels[value] = label;
    }

    if (isDefined(price) && price > 0 && getDvar("price_" + value) == "")
        setDvar("price_" + value, price);

    return self;
}

/*
///DocStringBegin
detail: shop_get_page(page_id: <String>): <Array | Undefined>
summary: Retrieves a registered page data array by its page identifier.
///DocStringEnd
*/
shop_get_page(page_id)
{
    if (isDefined(level.dynamicShopPages) && isDefined(level.dynamicShopPages[page_id]))
        return level.dynamicShopPages[page_id];

    if (isDefined(level.dynamicShop))
    {
        foreach(menu in level.dynamicShop)
        {
            if (isDefined(menu[MENU_PAGES]) && isDefined(menu[MENU_PAGES][page_id]))
                return menu[MENU_PAGES][page_id];
        }
    }
    return undefined;
}

/*
///DocStringBegin
detail: shop_get_menu(menu_id: <String>): <Array | Undefined>
summary: Retrieves a registered menu data array by its menu identifier.
///DocStringEnd
*/
shop_get_menu(menu_id)
{
    if (isDefined(level.dynamicShop) && isDefined(level.dynamicShop[menu_id]))
        return level.dynamicShop[menu_id];
    return undefined;
}

/*
///DocStringBegin
detail: shop_get_item_label(value: <String>): <String>
summary: Retrieves the cached display label string for a given item value.
///DocStringEnd
*/
shop_get_item_label(value)
{
    if (isDefined(level.dynamicShopItemLabels) && isDefined(level.dynamicShopItemLabels[value]))
        return level.dynamicShopItemLabels[value];
    return "";
}

shop_localize(key)
{
    if (!isDefined(key) || key == "") return "";
    lang = (getDvarInt("ui_language") == 1) ? 1 : 0;
    if (!isDefined(level.shop_loc_cache))
    {
        level.shop_loc_cache = [];
        level.shop_loc_cache[0] = [];
        level.shop_loc_cache[1] = [];
    }
    if (isDefined(level.shop_loc_cache[lang][key]))
        return level.shop_loc_cache[lang][key];

    col = (lang == 1) ? 2 : 1;
    localized = tablelookup("mp/languageLocalize.csv", 0, key, col);
    if (!isDefined(localized) || localized == "")
        localized = isSubStr(key, "@") ? key : "@" + key;

    level.shop_loc_cache[lang][key] = localized;
    return localized;
}

//////////////////////////////////////////
//	            CORE HANDLERS           //
//////////////////////////////////////////

/*
///DocStringBegin
detail: init(): <Void>
summary: Precache shop menus and initializes player connection listeners.
///DocStringEnd
*/
init()
{
	precachemenu("ui_shop_display");
	precachemenu("dynamic_shop");

    level endon("game_ended");
	
	for (;;)
	{
		level waittill("connected", player);
		if(player isTestClient()) continue;
		
        player.menuPages = [];
        player.isMenuBusy = false;        
		player thread onMenuResponse();
	}
}

/*
///DocStringBegin
detail: <Player> onMenuResponse(): <Void>
summary: Listens for UI scriptmenuresponse events and handles shop navigation and selection.
///DocStringEnd
*/
onMenuResponse()
{
	level endon("game_ended");
    self endon("disconnect");

    for (;;)
    {
        self waittill("menuresponse",  menu, response);

        if (isDefined(self.isMenuBusy) && self.isMenuBusy) continue;
        self.isMenuBusy = true;

		if ((menu == "class" || menu == "custom_options") && response == "back")
		{
			if (self isShopOpen()) self closeShop();
			else
			{
				self closepopupMenu();
				self closeInGameMenu();
				self.isMenuBusy = false;
			}
			continue;
		}
		
		if (menu != "dynamic_shop")
        {
            if (isDefined(self.shop) && response == "back") self closeShop();
            else self.isMenuBusy = false;
            continue;
        }

		if (response == "close_self" || response == "back")
		{
			self closeShop();
			continue;
		}
		
        if (response == "prev_menu")
        {
            if (isDefined(self.menuPages) && self.menuPages.size > 1)
            {
                self.menuPages[self.menuPages.size - 1] = undefined; 
                self openShop(self getPage(), true);
            }
            else self closeShop();
            continue;
        }

		page = self getPage();

        if (!isDefined(page) || page == "")
        {
            self closeShop();
            continue;
        }
        
		index = getIndex(page, response);
        if (!isDefined(index) || index < 0)
        {
            self closeShop();
            continue;
        }

		option_type = getOptionType(page, response, index);
        if (isDefined(level.onSelectOption))
            self [[level.onSelectOption]](page, response, getPrice(response), option_type, index);

        if (isDefined(self.isMenuBusy) && self.isMenuBusy) self.isMenuBusy = false;
	}
}

/*
///DocStringBegin
detail: <Player> _openMenu(menu_id: <String>): <Void>
summary: Opens the specified shop menu for the player.
///DocStringEnd
*/
_openMenu(menu_id)
{
    self openShop(menu_id);
}

/*
///DocStringBegin
detail: <Player> openShop(page: <String>, is_back?: <Bool>): <Void>
summary: Opens a shop page and updates the UI for the player.
///DocStringEnd
*/
openShop(page, is_back)
{
	self endon("close_shop");

    if (!isDefined(page) || page == "")
    {
        self closeShop();
        return;
    }

	if (!isDefined(is_back)) is_back = false;

    // Check if the target page is a root menu or top-level page
    isMainPage = isDefined(level.dynamicShop) && isDefined(level.dynamicShop[page]);
    if (!isMainPage)
    {
        p = shop_get_page(page);
        if (isDefined(p) && isDefined(p[PAGE_MENU]) && p[PAGE_ID] == p[PAGE_MENU])
            isMainPage = true;
    }

	if (isMainPage && !is_back) self.menuPages = [];	
	if (!is_back) self.menuPages[self.menuPages.size] = page;
	
    if (isDefined(level.onOpenPage)) self [[level.onOpenPage]](page);
    
	self updateLabels(page);
    if (isMainPage)
    {
        self openpopupmenu("dynamic_shop");
        self playLocalSound("nav_hover");
    }

    self.isMenuBusy = false;
}

/*
///DocStringBegin
detail: <Player> set_cached_client_dvar(dvar_name: <String>, val: <Any>): <Void>
summary: Sets a client Dvar only if its value has changed since the last update for this player.
///DocStringEnd
*/
set_cached_client_dvar(dvar_name, val)
{
    if (!isDefined(self.shop_dvar_cache)) self.shop_dvar_cache = [];
    val_str = "" + val;
    if (isDefined(self.shop_dvar_cache[dvar_name]) && self.shop_dvar_cache[dvar_name] == val_str)
        return false;
    self.shop_dvar_cache[dvar_name] = val_str;
    self setClientDvar(dvar_name, val);
    return true;
}

/*
///DocStringBegin
detail: <Player> closeShop(): <Void>
summary: Closes the dynamic shop menu for the player and resets state variables.
///DocStringEnd
*/
closeShop()
{
	self notify("close_shop");
	self.shop = undefined;
    self.menuPages = [];
    self.shop_dvar_cache = undefined;
    self.shop_open_logged = undefined;
	self closeMenu("dynamic_shop");
    if(isDefined(self)) self.isMenuBusy = false;
}

/*
///DocStringBegin
detail: <Player> getOptionType(page: <String>, item: <String>, index: <Int>): <Int>
summary: Determines the option type for the given item (e.g. OPTION_BUY, OPTION_OWNED, OPTION_DISABLE, etc.).
///DocStringEnd
*/
getOptionType(page, item, index)
{
	// get item price or set a value for price_label
	if (isDefined(level.isOwnedOption) && self [[level.isOwnedOption]](page, item, index)) return OPTION_OWNED; // price_label: "Owned", forecolor (1, 0.5, 0)
	if (isDefined(level.isDisabledOption) && self [[level.isDisabledOption]](page, item, index)) return OPTION_DISABLE; // price_label: "", disabled option, forecolor (0, 0, 0)
	if (isDefined(level.isUpgradeOption) && self [[level.isUpgradeOption]](page, item, index)) return OPTION_UPGRADE; // price_label: "Upgrade", forecolor (1, 0.5, 0)
	if (getDvar("price_" + item) == "") return OPTION_SCRIPTRESPONSE; // price_label: "", forecolor (1, 1, 1)
	return OPTION_BUY; // price_label: {price}, {current_price} >= {price} forecolor (1, 1, 1), {current_price} < {price} forecolor (1, 0, 0)
}

/*
///DocStringBegin
detail: <Player> updateLabels(page?: <String>): <Void>
summary: Updates client Dvars for all options and prices on the current page and refreshes the UI display.
///DocStringEnd
*/
updateLabels(page)
{
	self endon("disconnect");
	self endon("close_shop");

	if (!isDefined(page)) page = self getPage();
    p = shop_get_page(page);
    if (!isDefined(p)) return;

    items = p[PAGE_ITEMS];
    if (!isDefined(items)) items = [];

    self set_cached_client_dvar("ui_shop_title", shop_localize(isDefined(p[PAGE_DISPLAY]) ? p[PAGE_DISPLAY] : ""));
    self set_cached_client_dvar("ui_shop_desc", shop_localize(isDefined(p[PAGE_DESC]) ? p[PAGE_DESC] : ""));
    self set_cached_client_dvar("ui_shop_items_count", items.size);
    self set_cached_client_dvar("ui_shop_is_root", (isDefined(self.menuPages) && self.menuPages.size <= 1) ? 1 : 0);
    self set_cached_client_dvar("ui_shop_txt_owned", shop_localize("SO_SURVIVAL_ARMORY_OWNED"));
    self set_cached_client_dvar("ui_shop_txt_upgrade", shop_localize("SO_SURVIVAL_ARMORY_UPGRADE"));

    dvars_sent = 0;

	for(i = 0; i < 15; i++)
	{
        if (dvars_sent >= 30)
        {
            wait 0.05;
            dvars_sent = 0;
        }

        if (i >= items.size)
        {
            if (self setOption(i, "")) dvars_sent++;
            if (self setPrice(i, OPTION_DISABLE)) dvars_sent++;
            if (self set_cached_client_dvar("armory_ref_" + i, "")) dvars_sent++;
            if (self set_cached_client_dvar("armory_desc_" + i, "")) dvars_sent++;
            if (self set_cached_client_dvar("armory_icon_rect_" + i, "")) dvars_sent++;
            if (self set_cached_client_dvar("armory_icon_sq_" + i, "")) dvars_sent++;
            if (self set_cached_client_dvar("armory_lvl_" + i, 0)) dvars_sent++;
            continue;
        }

        item = items[i];
        item_val = item[ITEM_VALUE];
        option_label = isDefined(item[ITEM_LABEL]) ? item[ITEM_LABEL] : "";
        price_label = getOptionType(page, item_val, i);
		
		if (isDefined(level.onUpdateOption)) [[level.onUpdateOption]](i, item_val, option_label, price_label);
		else updateOption(i, item_val, option_label, price_label);

        if (self set_cached_client_dvar("armory_ref_" + i, item_val)) dvars_sent++;
        if (self set_cached_client_dvar("armory_desc_" + i, isDefined(item[ITEM_DESC]) ? shop_localize(item[ITEM_DESC]) : "")) dvars_sent++;
        if (self set_cached_client_dvar("armory_icon_rect_" + i, isDefined(item[ITEM_IMAGE_RECT]) ? item[ITEM_IMAGE_RECT] : "")) dvars_sent++;
        if (self set_cached_client_dvar("armory_icon_sq_" + i, isDefined(item[ITEM_IMAGE_SQUARE]) ? item[ITEM_IMAGE_SQUARE] : "")) dvars_sent++;

        req_lvl = 0;
        item_unlock_lvl = item[ITEM_UNLOCK_LEVEL];
        if (getDvarInt("survival_ladder") && price_label == OPTION_DISABLE && isDefined(item_unlock_lvl))
        {
            player_lvl = isDefined(self.survival_level) ? self.survival_level : 1;
            if (player_lvl < item_unlock_lvl)
                req_lvl = item_unlock_lvl;
        }
        if (self set_cached_client_dvar("armory_lvl_" + i, req_lvl)) dvars_sent++;
	}
	
	extra_items = 0;
	if (items.size > 11) extra_items = items.size - 11;
	self set_cached_client_dvar("ui_shop_extra_items", extra_items);
	
	self set_cached_client_dvar("ui_shop_display", page);
    self openMenu("ui_shop_display");
}

/*
///DocStringBegin
detail: <Player> updateOption(index: <Int>, item: <String>, option_label: <String>, price_label: <Int>): <Void>
summary: Sets the label and price Dvars for a specific option slot.
///DocStringEnd
*/
updateOption(index, item, option_label, price_label)
{
    if (price_label == OPTION_BUY) price_label = getPrice(item);    
    self setOption(index, option_label);
    self setPrice(index, price_label);
}

/*
///DocStringBegin
detail: <Player> setPrice(index: <Int>, price: <Int>): <Void>
summary: Sets the client Dvar armory_price_<index> to the given price value.
///DocStringEnd
*/
setPrice(index, price)
{
	return self set_cached_client_dvar("armory_price_" + index, price);
}

/*
///DocStringBegin
detail: <Player> setOption(index: <Int>, label: <String>): <Void>
summary: Sets the client Dvar armory_option_<index> to the given label string.
///DocStringEnd
*/
setOption(index, label)
{
	return self set_cached_client_dvar("armory_option_" + index, shop_localize(label));
}

/*
///DocStringBegin
detail: <Player> getPage(index?: <Int>): <String | Undefined>
summary: Returns the page identifier at the specified stack index for the player.
///DocStringEnd
*/
getPage(index)
{
	if (!isDefined(index)) index = 1;
	if (index < 0) index = index * -1;
    
    if (!isDefined(self.menuPages) || self.menuPages.size == 0) return undefined;

    real_index = self.menuPages.size - index;

    if (real_index < 0 || real_index >= self.menuPages.size) return undefined;

	page = self.menuPages[real_index];
	return page;
}

/*
///DocStringBegin
detail: getPrice(item: <String>): <Float>
summary: Returns the price of an item from its price_<item> Dvar.
///DocStringEnd
*/
getPrice(item)
{
	return getDvarFloat("price_" + item);
}

/*
///DocStringBegin
detail: getIndex(page: <String>, item: <String>): <Int>
summary: Returns the zero-based index of an item within the specified page, or -1 if not found.
///DocStringEnd
*/
getIndex(page, item)
{
    if (!isDefined(page) || page == "" || !isDefined(item) || item == "") return -1;

    p = shop_get_page(page);
    if (!isDefined(p)) return -1;

    items = p[PAGE_ITEMS];
    item_clean = isSubStr(item, " ") ? strtok(item, " ")[0] : item;

    for (i = 0; i < items.size; i++)
    {
        row_item = items[i][ITEM_VALUE];
        row_item_clean = isSubStr(row_item, " ") ? strtok(row_item, " ")[0] : row_item;
        if (row_item == item || row_item_clean == item_clean) return i;
    }

	return -1;
}

/*
///DocStringBegin
detail: <Player> buyItem(price: <Int>): <Void>
summary: Deducts the price from player score, plays a sound, and refreshes option labels.
///DocStringEnd
*/
buyItem(price)
{
	if (isDefined(level.setMoney)) [[level.setMoney]](self.score - int(price));
    self playLocalSound("arcademode_checkpoint");
    self updateLabels();
}

/*
///DocStringBegin
detail: <Player> shopInit(menu: <String>): <Void>
summary: Initializes the shop session struct on the player.
///DocStringEnd
*/
shopInit(menu)
{
    self.shop = spawnstruct();
    self.shop.menu = menu;
    self.shop.page = -1;
    self.shop.owner = self;
}

/*
///DocStringBegin
detail: <Player> isShopOpen(): <Bool>
summary: Returns true if the player currently has an active shop struct initialized.
///DocStringEnd
*/
isShopOpen()
{
	return isDefined(self.shop);
}
