
_openMenu(menu)
{
	self closepopupmenu();
    self closeingamemenu();
	if (menu != "") self openpopupmenu(menu);
}

menuInit()
{
	self setClientDvar("ui_startIndex", -1);
	self setClientDvar("menu_title", "");
	self.pers["menu_pages"] = [];
}

getMenu(count)
{
	if (!isDefined(self.pers["menu_pages"])) self.pers["menu_pages"] = [];
	count = isDefined(count) ? count + 1 : 1;
	return self.pers["menu_pages"][self.pers["menu_pages"].size - count];
}

pushMenu(title, table, startIndex, range)
{
	menu = [];
	menu["title"] = title;
	menu["table"] = table;
	menu["startIndex"] = startIndex;
	menu["range"] = range;

	if (!isDefined(self.pers["menu_pages"])) self.pers["menu_pages"] = [];
	self.pers["menu_pages"][self.pers["menu_pages"].size] = menu;
	self openDynamicMenu();
}

popMenu()
{
	if (!isDefined(self.pers["menu_pages"]) || self.pers["menu_pages"].size < 1) return;
	
	newMenuPages = [];	
	for (i = 0; i < self.pers["menu_pages"].size - 1; i++)
		newMenuPages[i] = self.pers["menu_pages"][i];
	
	self.pers["menu_pages"] = newMenuPages;	
	self openDynamicMenu();
}

openDynamicMenu()
{
	menu = self getMenu();
    self setClientDvar("menu_title", "@" + menu["title"]);
	
	for(i = 0; i < 20; i++)
	{
		self setClientDvar("optionType" + i, 1);
		if(i < menu["range"]) self setClientDvar("menu_option" + i, "@" + tableLookup("mp/" + menu["table"] + ".csv", 0, i + menu["startIndex"], 2));
		else self setClientDvar("menu_option" + i, "");
	}	
	self _openMenu("dynamic_options");
}

setOptionType(type, table, startIndex, range, target)
{
	for(i = 0; i < range; i++)
		if(target == tableLookup("mp/"+ table + ".csv", 0, i + startIndex, 1))
		{
			self setClientDvar("optionType" + i, type);
			break;
		}
}

setOptionsType(type, table, startIndex, range, targets)
{
	for(i = 0; i < range; i++)
	{
		val = tableLookup("mp/"+ table + ".csv", 0, i + startIndex, 1);
		if(contains(targets, val)) self setClientDvar("optionType" + i, type);
	}
}

setCurrentOption(target, startIndex, range, type)
{
	menu = self getMenu();
	startIndex = isDefined(startIndex) ? startIndex : menu["startIndex"];
	range = isDefined(range) ? range : menu["range"];
	type = isDefined(type) ? type : 4;
	self setOptionType(type, menu["table"], startIndex, range, target);
}

setCurrentOptions(targets, startIndex, range, type)
{
	menu = self getMenu();
	startIndex = isDefined(startIndex) ? startIndex : menu["startIndex"];
	range = isDefined(range) ? range : menu["range"];
	type = isDefined(type) ? type : 4;
	self setOptionsType(type, menu["table"], startIndex, range, targets);
}

setMenuDecoration(indices, type)
{
	foreach(index in indices)
		self setClientDvar("optionType" + index, type);
}

contains(arr, value)
{
	foreach(val in arr)
		if(val == value) return true;
	return false;
}